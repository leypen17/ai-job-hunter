# AI Job Hunter

A personal web app that finds remote jobs that fit your real experience, scores them, checks them for scams, writes tailored applications with Claude, and tracks everything through interviews and follow-ups. Nothing is ever sent without your approval unless you deliberately arm Mode 3, and even then only email applications that pass every safety rule.

Built for Smiley Pencirga's profile (reconciled from the three CVs in `config/profile.json`), but any profile works.

---

## Quick start (about 10 minutes)

1. **Install Node.js 22.13 or newer** from https://nodejs.org (LTS is fine). Check with `node -v`.
2. **Unzip** this folder somewhere, open a terminal in it, and run:
   ```bash
   npm install
   cp .env.example .env        # Windows: copy .env.example .env
   npm start
   ```
3. Open **http://localhost:3000**, create a password, and you're in.
4. Go to **Settings → Integrations** and paste your **Anthropic API key** (get one at https://console.anthropic.com). Press *Test connection*.
5. Press **Search now**. Jobs appear within a minute or two.

Keep the terminal open: searches run on schedule (every 4 hours by default, Manila time) while the app is running. To run it in the background permanently, use `pm2` (`npm i -g pm2 && pm2 start npm --name jobhunter -- start`) or a Windows Task Scheduler entry for `npm start`.

### Optional extras

| Feature | Setup |
|---|---|
| Email applications, follow-ups and alerts | Settings → Integrations → SMTP. For Gmail: turn on 2-step verification, create an App Password at https://myaccount.google.com/apppasswords, host `smtp.gmail.com`, port `587`. |
| Attach your CV to emails / upload it on forms | Settings → Integrations → CV file path (absolute path to your PDF). |
| Assisted apply (opens the employer's form with your details pre-filled) | `npm i playwright && npx playwright install chromium` |
| Company career pages | Settings → Sources → add Greenhouse / Lever / Ashby board slugs of remote-first companies you like. |

---

## How it works

**Daily workflow (all automatic):** search sources → collect → normalize (salary to USD/month, hours, employment type, eligibility) → remove duplicates across sites → verify remote/Philippines eligibility → rules score every job → scam check → drop irrelevant/low scorers → Claude analyzes the promising ones → company research → tailored proposal + answers → apply per mode → record → follow-up reminders → weekly analytics.

### Application modes (Settings → Mode & schedule)

| Mode | What happens |
|---|---|
| **1. Search only** | Finds, scores and organizes jobs. Proposals only when you click. |
| **2. Draft & approve** (default) | Also researches the company and drafts a proposal + question answers for every 80+ job, then waits in *Awaiting Approval*. You edit, approve, then send. |
| **3. Autonomous** | Same as Mode 2, and also *sends* applications automatically, but only when **all** of these are true: score ≥ 85 (Claude-scored), genuinely remote, Philippines eligible (confirmed by both the parser and Claude), scam risk Low, not a duplicate, not already applied, salary not below your minimum, no `[YOUR INPUT]` placeholders, no questions needing your input, none of the approval triggers (video interview, assessment, personality/technical test, contract/NDA, legal declaration, background check, sensitive data, payment details, salary questions), and the posting accepts **email** applications. You must also tick "Arm automatic sending". Every job it doesn't send shows exactly which rule blocked it. |

A job is only marked **Applied** when the mail server accepted the email, or when you press *Mark as Applied* yourself.

### Scoring

Rules engine (free, instant) scores every job; Claude re-scores the promising ones. The final score is always computed in code from the spec weights: skills 30%, experience 20%, automation/AI 15%, compensation 10%, remote eligibility 10%, hours 5%, long-term 5%, growth 5%. 90+ Excellent, 80–89 Strong, 70–79 Good, 60–69 Possible, below 60 deprioritized. Jobs restricted to other countries or on-site are capped at 45 no matter what. Interview likelihood is shown as an AI estimate only.

### Honesty guardrails

- Claude only sees and may only use `config/profile.json`. It's told never to invent employers, clients, certifications, metrics, results or projects, and to respect the `doNotClaim` list.
- Skills that are in your brief but on none of your CVs (Zapier, n8n, webhooks, APIs, Google Analytics/Search Console, Agile) are marked **self-reported**: Claude may name them but can't attach made-up projects to them. Add them to your CV if you have them.
- Questions that need facts not in your profile come back with `[YOUR INPUT: …]` placeholders, and the app refuses to approve until you fill them.
- Job postings and company pages are treated as untrusted text (prompt-injection safe instructions).

### Profile reconciliation (from your 3 CVs)

| Item | CVs said | Used |
|---|---|---|
| Years of experience | 13 / 14+ / 15+ | **14+** |
| Clients | 100+ / 200+ | **200+** |
| "Fortune 500-level clients" | not on any CV | not claimed; uses "SaaS organizations such as Qubole and Metadata.io" |
| Zapier, n8n, webhooks, APIs, GA, Search Console, Agile | only in your brief | marked self-reported |
| Top Rated Plus on Upwork | only in your brief | kept as self-reported fact |

Edit any of this in **Settings → Profile**, then press **Re-score** on Job Search.

---

## Sources

| Source | Method | Needs |
|---|---|---|
| Remotive | Official public API (pulled at most every 6 h, per their request) | nothing |
| Remote OK | Official public API | nothing |
| We Work Remotely | Official RSS feeds | nothing |
| Working Nomads | Public JSON feed | nothing |
| Jobicy | Public API | nothing |
| Himalayas | Public API | nothing |
| Company career pages | Greenhouse, Lever, Ashby public job-board APIs | board slugs you add |
| **LinkedIn, Indeed, Glassdoor, OnlineJobs.ph, Wellfound, Remote.co, FlexJobs, Dynamite Jobs** | No permitted automation for job seekers. The app gives you ready-made search links (Job Search → *LinkedIn, Indeed, Upwork & other sites*) and an **Import job** form: paste a posting and it gets scored, scam-checked and a tailored proposal like everything else. | your own account |
| **Upwork** | Same assisted flow. Upwork's API needs an approved developer key. You can also ask Claude (with the Upwork connector) to search and draft proposals in chat, with your approval. | your account |

All requests identify themselves, are spaced 1.5 s apart per host, retry politely, and never log in, bypass CAPTCHAs or scrape behind logins. Every job links to its original posting (attribution required by these sources).

---

## Integrations that need keys or your authorization

| Integration | Needs | Without it |
|---|---|---|
| Claude (analysis, research, proposals, answers, follow-ups, weekly insights) | `ANTHROPIC_API_KEY` (paid, usage-based) | Rules scoring and clearly-labeled offline drafts only |
| Email applications, follow-up sending, email alerts | SMTP login (e.g. Gmail App Password) | Dashboard notifications; apply via form/manual |
| Assisted form fill | Playwright installed locally | Copy proposal + apply manually |
| Upwork API | Approved Upwork developer key (not implemented yet) | Assisted search + import |
| LinkedIn / Indeed / Glassdoor / OnlineJobs.ph | Not available (ToS) | Assisted search + import |

Secrets entered in the app are stored AES-256-GCM encrypted in the local database (key in `APP_SECRET` or auto-generated `data/.secret.key`). Environment variables override them.

**Cost:** the default model is `claude-opus-5-5` at medium effort. Each analyzed job is one request; each proposal one more. "Max jobs Claude analyzes per search" (default 40) caps spend per run. You can change the model in Settings → Integrations.

---

## Using it day to day

1. **Dashboard**: today's numbers, top matches, last searches (per-source counts and errors).
2. **Top Matches**: 80+ jobs open to the Philippines. Open one to see the score breakdown, why it fits, missing qualifications, compensation fit, eligibility, scam signals.
3. **Proposal & apply** tab: edit the proposal and answers → **Approve** → **Send by email** (if the posting takes email) or **Open form & pre-fill** (you press Submit on the employer's site) → **Mark as applied** if you applied another way.
4. **Applications**: kanban of your pipeline. When an employer replies, set the status to Interview / Assessment / Offer / Rejected so analytics stay accurate.
5. **Follow-ups**: day 3 reminder, day 5 a drafted follow-up (never auto-sent; one per application), day 14 flagged inactive.
6. **Analytics**: weekly discovered / qualified / applied / interviews, conversion, best categories, proposal styles and platforms, most-requested and missing skills, companies that responded, and recommendations (Claude-written if you click *with AI*). A weekly report is also saved every Sunday 6 PM.

Command line: `npm run search` (one search now), `node src/cli.js followups`, `node src/cli.js report`.

---

## Project layout

```
src/
  server.js            Express API + auth + static dashboard
  db.js                SQLite schema (built-in node:sqlite, no native builds)
  config.js            settings, profile, encrypted secrets
  sources/             Remotive, Remote OK, WWR, Working Nomads, Jobicy, Himalayas, Greenhouse/Lever/Ashby, assisted links
  engine/
    normalize.js       cleaning, salary→USD/month, eligibility, hours, dedupe fingerprint, skills
    scoring.js         rules scorer + spec weights + classification
    scam.js            scam rules (Low/Moderate/High)
    ai.js              Claude: analysis, research, proposals, answers, follow-ups, insights
    research.js        company site fetch + summary
    pipeline.js        the daily workflow, modes, import
    submit.js          approval triggers, Mode 3 gate, email send, assisted apply, mark applied
    followups.js       day 3 / 5–7 / 14 follow-up automation
    analytics.js       dashboard stats + weekly report
    notify.js          dashboard + email notifications
    scheduler.js       every 4 h / daily / custom cron
public/                dashboard (vanilla JS, no build step, light/dark, mobile friendly)
config/profile.json    your profile: the only facts Claude may use
test/                  automated tests (npm test)
data/                  your database (created on first run; back it up)
```

Architecture note: the spec suggested Next.js + Supabase + n8n. This uses Node + Express + SQLite + node-cron instead because it runs with one `npm start` on your laptop, has no hosted services to pay for or secure, and keeps your data local. The engines are separate modules, so moving to Postgres/Supabase or triggering searches from n8n (`npm run search`, or `POST /api/search/run`) is straightforward later.

## Security

- Binds to `127.0.0.1` by default. To reach it from other devices, set `HOST=0.0.0.0` and put it behind HTTPS (and set `COOKIE_SECURE=true`).
- Password login (scrypt hash), HMAC-signed HttpOnly SameSite=Strict session cookie, login rate limiting, JSON-only writes.

## Tests

`npm test` runs 12 tests: salary/eligibility/hours parsing, scoring weights and hard rules, scam detection, secret encryption, a full search run over sample feed payloads (dedupe across sites, irrelevant-job elimination, scam flagging, Mode 2 drafts with nothing submitted, source rate limits), the Mode 3 gate, the follow-up schedule, analytics counting, manual import, and the Claude request/response flow against a stubbed API. Test data lives only in a temporary folder and never touches your database.

## Known limits

- Feed formats change. Each search shows per-source results on the Dashboard (green with a count, red with the error). If a source turns red repeatedly, disable it in Settings → Sources and tell me which one.
- The Himalayas search endpoint is used when available, with the plain feed as fallback.
- Assisted apply recognizes common form fields (name, email, phone, LinkedIn, cover letter, CV upload). Custom questions on employer forms are answered by copying from the app.

## Put it online (Render)

The repo includes `render.yaml`, so Render sets almost everything up for you.

1. Keep the GitHub repo **private**: `config/profile.json` holds your CV details.
2. In Render, choose **New > Blueprint** and pick the repo.
3. Render asks for two values. Type them there, never in a chat:
   - `ANTHROPIC_API_KEY`: your Claude API key from console.anthropic.com
   - `APP_PASSWORD`: the password you will log in with (8+ characters)
4. Click **Apply**. After a few minutes you get a link like `https://ai-job-hunter-xxxx.onrender.com`.

It uses Render's Starter plan (about $7/month plus about $0.25/month for the 1 GB disk) because the free plan has no lasting storage and goes to sleep, which would wipe your jobs and stop the scheduled search.
Your database and profile live on the disk at `/var/data`. Editing your profile in the app changes the copy on the disk; `config/profile.json` in the repo is only the starting copy.
Online, the app refuses to create a password from the login page, so a stranger can't claim it: it only accepts `APP_PASSWORD`.
