'use strict';
// Company career pages via public ATS job-board APIs (no key needed to READ postings):
//   Greenhouse: https://boards-api.greenhouse.io/v1/boards/{token}/jobs?content=true
//   Lever:      https://api.lever.co/v0/postings/{company}?mode=json
//   Ashby:      https://api.ashbyhq.com/posting-api/job-board/{name}?includeCompensation=true
// Add board tokens in Settings → Sources (e.g. the slug in boards.greenhouse.io/<token>).
const { fetchJSON } = require('./http');

const decode = (s) => String(s || '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&');

async function greenhouse(token) {
  const d = await fetchJSON(`https://boards-api.greenhouse.io/v1/boards/${encodeURIComponent(token)}/jobs?content=true`);
  return (d.jobs || []).map((j) => ({
    source: 'greenhouse', source_id: `${token}:${j.id}`, platform: 'Company site (Greenhouse)',
    title: j.title, company: j.company_name || token, url: j.absolute_url, apply_url: j.absolute_url,
    date_posted: j.first_published || j.updated_at, location_text: j.location?.name || '', description: decode(j.content), tags: [],
  }));
}
async function lever(company) {
  const d = await fetchJSON(`https://api.lever.co/v0/postings/${encodeURIComponent(company)}?mode=json`);
  return (d || []).map((j) => ({
    source: 'lever', source_id: `${company}:${j.id}`, platform: 'Company site (Lever)',
    title: j.text, company, url: j.hostedUrl, apply_url: j.applyUrl || j.hostedUrl,
    date_posted: j.createdAt ? new Date(j.createdAt).toISOString() : null,
    employment_type: j.categories?.commitment, location_text: [j.categories?.location, ...(j.categories?.allLocations || []), j.workplaceType].filter(Boolean).join(', '),
    salary_min: j.salaryRange?.min || null, salary_max: j.salaryRange?.max || null, salary_currency: j.salaryRange?.currency || 'USD',
    salary_period: (j.salaryRange?.interval || 'per-year-salary').includes('hour') ? 'hour' : (j.salaryRange?.interval || '').includes('month') ? 'month' : 'year',
    description: [j.descriptionPlain, ...(j.lists || []).map((l) => `${l.text}\n${String(l.content || '').replace(/<[^>]+>/g, ' ')}`), j.additionalPlain].filter(Boolean).join('\n\n'), tags: [],
  }));
}
async function ashby(name) {
  const d = await fetchJSON(`https://api.ashbyhq.com/posting-api/job-board/${encodeURIComponent(name)}?includeCompensation=true`);
  return (d.jobs || []).filter((j) => j.isListed !== false).map((j) => ({
    source: 'ashby', source_id: `${name}:${j.id}`, platform: 'Company site (Ashby)',
    title: j.title, company: name, url: j.jobUrl, apply_url: j.applyUrl || j.jobUrl, date_posted: j.publishedAt,
    employment_type: j.employmentType, location_text: [j.location, j.isRemote ? 'Remote' : '', j.workplaceType, ...(j.secondaryLocations || []).map((l) => l.location)].filter(Boolean).join(', '),
    salary_text: j.compensation?.compensationTierSummary || null, description: j.descriptionPlain || j.descriptionHtml, tags: [],
  }));
}

function makeSource(id, name, fn) {
  return { id, name, fetchJobs: async ({ settings }) => {
    const tokens = settings.atsBoards?.[id] || [];
    const all = []; const errors = [];
    for (const t of tokens) { try { all.push(...await fn(t)); } catch (e) { errors.push(`${t}: ${e.message}`); } }
    if (errors.length && !all.length && tokens.length) throw new Error(errors.join('; '));
    all.partialErrors = errors;
    return all;
  } };
}
module.exports = {
  greenhouse: makeSource('greenhouse', 'Greenhouse boards', greenhouse),
  lever: makeSource('lever', 'Lever boards', lever),
  ashby: makeSource('ashby', 'Ashby boards', ashby),
};
