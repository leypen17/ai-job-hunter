'use strict';
// Jobicy public remote jobs API: https://jobicy.com/jobs-rss-feed (API v2). Attribution required.
const { fetchJSON } = require('./http');
const INDUSTRIES = ['marketing', 'admin', 'supporting', 'management', 'seller', 'smm'];
async function fetchJobs() {
  const out = new Map();
  for (const ind of INDUSTRIES) {
    try {
      const d = await fetchJSON(`https://jobicy.com/api/v2/remote-jobs?count=50&industry=${ind}`);
      for (const j of d.jobs || []) out.set(j.id, j);
    } catch (e) { if (!/HTTP 4/.test(e.message)) throw e; }
  }
  return [...out.values()].map((j) => ({
    source: 'jobicy', source_id: String(j.id), platform: 'Jobicy',
    title: j.jobTitle, company: j.companyName, url: j.url, apply_url: j.url, date_posted: j.pubDate,
    salary_min: j.annualSalaryMin || j.salaryMin || null, salary_max: j.annualSalaryMax || j.salaryMax || null,
    salary_currency: j.salaryCurrency || 'USD', salary_period: (j.salaryPeriod || 'year').toLowerCase(),
    employment_type: Array.isArray(j.jobType) ? j.jobType.join(', ') : j.jobType,
    location_text: j.jobGeo || '', description: j.jobDescription || j.jobExcerpt,
    category: Array.isArray(j.jobIndustry) ? j.jobIndustry.join(', ') : j.jobIndustry, experience_level: j.jobLevel, tags: [],
  }));
}
module.exports = { id: 'jobicy', name: 'Jobicy', fetchJobs };
