'use strict';
// Himalayas public jobs API: https://himalayas.app/jobs/api  (attribution + link back required).
const { fetchJSON } = require('./http');
async function fetchJobs({ keywords }) {
  const out = new Map();
  const terms = ['automation', 'operations', 'virtual assistant', 'marketing', 'project manager', 'crm', 'social media'];
  for (const q of terms) {
    try {
      const d = await fetchJSON(`https://himalayas.app/jobs/api/search?q=${encodeURIComponent(q)}&limit=20`);
      for (const j of d.jobs || []) out.set(j.guid || j.applicationLink, j);
    } catch (e) {
      // older endpoint without search
      if (out.size === 0) { const d = await fetchJSON('https://himalayas.app/jobs/api?limit=20'); for (const j of d.jobs || []) out.set(j.guid || j.applicationLink, j); }
      break;
    }
  }
  return [...out.values()].map((j) => ({
    source: 'himalayas', source_id: String(j.guid || j.applicationLink), platform: 'Himalayas',
    title: j.title, company: j.companyName, url: j.applicationLink || j.guid, apply_url: j.applicationLink,
    date_posted: j.pubDate ? new Date(typeof j.pubDate === 'number' ? j.pubDate * 1000 : j.pubDate).toISOString() : null,
    salary_min: j.minSalary || null, salary_max: j.maxSalary || null, salary_currency: j.currency || 'USD', salary_period: 'year',
    employment_type: j.employmentType, location_text: (j.locationRestrictions || []).join(', ') || 'Worldwide',
    description: j.description || j.excerpt, category: (j.categories || []).join(', '), experience_level: (j.seniority || []).join(', '), tags: j.categories || [],
  }));
}
module.exports = { id: 'himalayas', name: 'Himalayas', fetchJobs };
