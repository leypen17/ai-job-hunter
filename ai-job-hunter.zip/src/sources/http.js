'use strict';
// Polite HTTP helper: identifies itself, times out, retries once, and spaces requests per host.
const UA = process.env.HTTP_USER_AGENT || 'AIJobHunter/1.0 (personal job search tool; respects robots and rate limits)';
const lastHit = new Map();
const MIN_GAP_MS = 1500;

async function politeWait(url) {
  const host = new URL(url).host;
  const prev = lastHit.get(host) || 0;
  const wait = prev + MIN_GAP_MS - Date.now();
  if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  lastHit.set(host, Date.now());
}

async function fetchText(url, { timeoutMs = 20000, headers = {}, retries = 1 } = {}) {
  await politeWait(url);
  for (let attempt = 0; ; attempt++) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), timeoutMs);
    try {
      const res = await fetch(url, { headers: { 'User-Agent': UA, Accept: '*/*', ...headers }, signal: ctl.signal, redirect: 'follow' });
      if (res.status === 429 || res.status >= 500) throw Object.assign(new Error(`HTTP ${res.status}`), { retryable: true });
      if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
      return await res.text();
    } catch (e) {
      if (attempt < retries && (e.retryable || e.name === 'AbortError' || e.cause)) { await new Promise((r) => setTimeout(r, 3000 * (attempt + 1))); continue; }
      throw e;
    } finally { clearTimeout(t); }
  }
}
async function fetchJSON(url, opts) { return JSON.parse(await fetchText(url, { ...opts, headers: { Accept: 'application/json', ...(opts?.headers || {}) } })); }

module.exports = { fetchText, fetchJSON, UA };
