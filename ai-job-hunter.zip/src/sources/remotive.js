'use strict';
// Remotive public API: https://remotive.com/api/remote-jobs  (docs: github.com/remotive-com/remote-jobs-api)
// Terms: link back to Remotive and credit them; keep calls to a few per day.
const { fetchJSON } = require('./http');

// One call returns every live job; the app also enforces a minimum 6h gap between pulls.
async function fetchJobs() {
  const data = await fetchJSON('https://remotive.com/api/remote-jobs');
  const out = new Map((data.jobs || []).map((j) => [j.id, j]));
  return [...out.values()].map((j) => ({
    source: 'remotive', source_id: String(j.id), platform: 'Remotive',
    title: j.title, company: j.company_name, url: j.url, apply_url: j.url,
    date_posted: j.publication_date, salary_text: j.salary || null,
    employment_type: j.job_type, location_text: j.candidate_required_location,
    description: j.description, tags: j.tags || [], category: j.category,
  }));
}
module.exports = { id: 'remotive', name: 'Remotive', fetchJobs, minIntervalHours: 6 };
