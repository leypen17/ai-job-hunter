'use strict';
// We Work Remotely public RSS feeds.
const { XMLParser } = require('fast-xml-parser');
const { fetchText } = require('./http');

const FEEDS = [
  'https://weworkremotely.com/categories/remote-customer-support-jobs.rss',
  'https://weworkremotely.com/categories/remote-sales-and-marketing-jobs.rss',
  'https://weworkremotely.com/categories/remote-management-and-finance-jobs.rss',
  'https://weworkremotely.com/categories/all-other-remote-jobs.rss',
  'https://weworkremotely.com/categories/remote-product-jobs.rss',
];
const parser = new XMLParser({ ignoreAttributes: false });

function parseFeed(xml) {
  const doc = parser.parse(xml);
  let items = doc?.rss?.channel?.item || [];
  if (!Array.isArray(items)) items = [items];
  return items.map((it) => {
    const raw = String(it.title || '');
    const idx = raw.indexOf(':');
    const company = idx > 0 ? raw.slice(0, idx).trim() : null;
    const title = idx > 0 ? raw.slice(idx + 1).trim() : raw;
    const link = typeof it.link === 'string' ? it.link : it.guid?.['#text'] || it.guid;
    return {
      source: 'wwr', source_id: String(typeof it.guid === 'object' ? it.guid['#text'] : it.guid || link), platform: 'We Work Remotely',
      title, company, url: link, apply_url: link, date_posted: it.pubDate ? new Date(it.pubDate).toISOString() : null,
      employment_type: it.type || null, location_text: it.region || '', description: it.description || '',
      category: it.category || null, tags: [],
    };
  });
}
async function fetchJobs() {
  const all = [];
  for (const f of FEEDS) {
    try { all.push(...parseFeed(await fetchText(f))); } catch (e) { if (!/404/.test(e.message)) throw e; }
  }
  return all;
}
module.exports = { id: 'wwr', name: 'We Work Remotely', fetchJobs, parseFeed };
