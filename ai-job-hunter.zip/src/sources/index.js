'use strict';
const ats = require('./ats');
const SOURCES = [require('./remotive'), require('./remoteok'), require('./wwr'), require('./workingnomads'), require('./jobicy'), require('./himalayas'), ats.greenhouse, ats.lever, ats.ashby];
module.exports = { SOURCES, ...require('./assisted') };
