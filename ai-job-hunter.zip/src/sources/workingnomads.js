'use strict';
// Working Nomads public JSON feed.
const { fetchJSON } = require('./http');
async function fetchJobs() {
  const data = await fetchJSON('https://www.workingnomads.com/api/exposed_jobs/');
  return (data || []).map((j) => ({
    source: 'workingnomads', source_id: j.url, platform: 'Working Nomads',
    title: j.title, company: j.company_name, url: j.url, apply_url: j.url, date_posted: j.pub_date,
    location_text: j.location || '', description: j.description, category: j.category_name,
    tags: typeof j.tags === 'string' ? j.tags.split(',').map((s) => s.trim()).filter(Boolean) : (j.tags || []),
  }));
}
module.exports = { id: 'workingnomads', name: 'Working Nomads', fetchJobs };
