'use strict';
// Platforms without permitted automated search/apply for individuals. The app builds saved-search
// links you open yourself, then you paste interesting jobs into "Import job" so they get scored,
// scam-checked and a tailored proposal like everything else.
const enc = encodeURIComponent;
const ASSISTED = [
  { id: 'linkedin', name: 'LinkedIn Jobs', why: 'LinkedIn prohibits scraping and automated applying.', url: (q) => `https://www.linkedin.com/jobs/search/?keywords=${enc(q)}&f_WT=2&f_TPR=r86400` },
  { id: 'indeed', name: 'Indeed', why: 'No public job search API for job seekers; automation is against ToS.', url: (q) => `https://www.indeed.com/jobs?q=${enc(q)}&l=Remote&fromage=3` },
  { id: 'upwork', name: 'Upwork', why: 'Upwork API needs an approved developer key. Claude’s Upwork connector can search and draft proposals in chat with your approval.', url: (q) => `https://www.upwork.com/nx/search/jobs/?q=${enc(q)}&sort=recency` },
  { id: 'onlinejobs', name: 'OnlineJobs.ph', why: 'No public API; applying requires your logged-in account.', url: (q) => `https://www.onlinejobs.ph/jobseekers/jobsearch?jobkeyword=${enc(q)}` },
  { id: 'wellfound', name: 'Wellfound', why: 'No public API; login required.', url: (q) => `https://wellfound.com/role/r/${enc(q.toLowerCase().replace(/\s+/g, '-'))}` },
  { id: 'remoteco', name: 'Remote.co', why: 'No public API.', url: (q) => `https://remote.co/remote-jobs/search/?search_keywords=${enc(q)}` },
  { id: 'flexjobs', name: 'FlexJobs', why: 'Paid membership, no API.', url: (q) => `https://www.flexjobs.com/search?search=${enc(q)}` },
  { id: 'dynamite', name: 'Dynamite Jobs', why: 'No public API.', url: (q) => `https://dynamitejobs.com/remote-jobs?q=${enc(q)}` },
  { id: 'glassdoor', name: 'Glassdoor', why: 'No public API; automation against ToS.', url: (q) => `https://www.glassdoor.com/Job/remote-${enc(q.toLowerCase().replace(/\s+/g, '-'))}-jobs-SRCH_IL.0,6_IS11047_KO7,${7 + q.length}.htm` },
];
function assistedLinks(keywords) {
  return ASSISTED.map((p) => ({ id: p.id, name: p.name, why: p.why, links: keywords.slice(0, 8).map((k) => ({ keyword: k, url: p.url(k) })) }));
}
module.exports = { ASSISTED, assistedLinks };
