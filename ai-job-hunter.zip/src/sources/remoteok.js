'use strict';
// Remote OK public API: https://remoteok.com/api  (first element is a legal notice).
// Terms: you must link back to Remote OK and mention it as the source.
const { fetchJSON } = require('./http');

async function fetchJobs() {
  const data = await fetchJSON('https://remoteok.com/api');
  return data.filter((j) => j && j.id && j.position).map((j) => ({
    source: 'remoteok', source_id: String(j.id), platform: 'Remote OK',
    title: j.position, company: j.company, url: j.url || `https://remoteok.com/remote-jobs/${j.id}`,
    apply_url: j.apply_url || j.url, date_posted: j.date || (j.epoch ? new Date(j.epoch * 1000).toISOString() : null),
    salary_min: j.salary_min || null, salary_max: j.salary_max || null, salary_currency: 'USD', salary_period: 'year',
    location_text: j.location || '', description: j.description, tags: j.tags || [],
  }));
}
module.exports = { id: 'remoteok', name: 'Remote OK', fetchJobs };
