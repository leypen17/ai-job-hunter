'use strict';
// CLI: `npm run search` runs one full search now (useful for cron/Task Scheduler without the server).
require('./env').load();
const cmd = process.argv[2];
(async () => {
  if (cmd === 'search') {
    const r = await require('./engine/pipeline').runSearch({ trigger: 'cli' });
    console.log(JSON.stringify(r, null, 2));
  } else if (cmd === 'followups') {
    console.log(await require('./engine/followups').processFollowUps());
  } else if (cmd === 'report') {
    console.log(JSON.stringify(await require('./engine/analytics').weeklyReport(), null, 2));
  } else {
    console.log('Usage: node src/cli.js search | followups | report');
  }
})().catch((e) => { console.error(e); process.exit(1); });
