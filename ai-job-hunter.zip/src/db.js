'use strict';
// SQLite storage using Node's built-in node:sqlite (Node >= 22.13). No native build step.
const path = require('node:path');
const fs = require('node:fs');
const { DatabaseSync } = require('node:sqlite');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'jobhunter.db');

const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');

const STATUSES = [
  'New', 'Analyzing', 'Qualified', 'Proposal Generated', 'Awaiting Approval', 'Applied',
  'Follow-Up Due', 'Interview', 'Assessment', 'Offer', 'Rejected', 'Archived',
];

db.exec(`
CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source TEXT NOT NULL,            -- remotive, remoteok, wwr, ...
  source_id TEXT,                  -- id at the source
  platform TEXT NOT NULL,          -- display name
  title TEXT NOT NULL,
  company TEXT,
  company_url TEXT,
  url TEXT NOT NULL,
  apply_url TEXT,
  apply_email TEXT,
  date_posted TEXT,
  date_discovered TEXT NOT NULL DEFAULT (datetime('now')),
  salary_text TEXT,
  salary_min_month REAL,           -- normalized USD / month
  salary_max_month REAL,
  hourly_min REAL,
  hourly_max REAL,
  hours_per_week TEXT,
  employment_type TEXT,
  remote_eligibility TEXT,         -- worldwide | philippines | asia | restricted | unclear | not_remote
  location_restrictions TEXT,
  description TEXT,
  required_skills TEXT,            -- JSON array
  category TEXT,
  experience_level TEXT,
  tags TEXT,                       -- JSON array
  fingerprint TEXT,                -- dedupe key
  duplicate_of INTEGER REFERENCES jobs(id),
  match_score INTEGER,
  rule_score INTEGER,
  score_breakdown TEXT,            -- JSON
  match_explanation TEXT,          -- JSON
  scored_by TEXT,                  -- rules | claude
  scam_risk TEXT,                  -- Low | Moderate | High
  scam_flags TEXT,                 -- JSON
  company_research TEXT,           -- JSON
  proposal TEXT,
  proposal_style TEXT,
  application_questions TEXT,      -- JSON [{q, a, needsInput, note}]
  status TEXT NOT NULL DEFAULT 'New',
  saved INTEGER NOT NULL DEFAULT 0,
  approved_at TEXT,
  date_applied TEXT,
  applied_via TEXT,                -- email | assisted-browser | manual | upwork
  follow_up_date TEXT,
  follow_up_stage TEXT,
  follow_up_draft TEXT,
  follow_up_sent INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  contact_info TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(source, source_id)
);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_score ON jobs(match_score);
CREATE INDEX IF NOT EXISTS idx_jobs_fp ON jobs(fingerprint);

CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id INTEGER REFERENCES jobs(id) ON DELETE CASCADE,
  type TEXT NOT NULL,              -- status_change, applied, email_sent, note, response, ...
  detail TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_events_job ON events(job_id);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT,
  job_id INTEGER REFERENCES jobs(id) ON DELETE SET NULL,
  read INTEGER NOT NULL DEFAULT 0,
  emailed INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS search_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at TEXT,
  trigger TEXT,
  found INTEGER DEFAULT 0,
  new_jobs INTEGER DEFAULT 0,
  duplicates INTEGER DEFAULT 0,
  qualified INTEGER DEFAULT 0,
  source_report TEXT,              -- JSON per-source counts / errors
  error TEXT
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  week_start TEXT NOT NULL,
  data TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

function now() { return new Date().toISOString(); }

const J = (v) => (v == null ? null : JSON.stringify(v));
const P = (v, d = null) => { if (v == null || v === '') return d; try { return JSON.parse(v); } catch { return d; } };

const JSON_COLS = ['required_skills', 'tags', 'score_breakdown', 'match_explanation', 'scam_flags', 'company_research', 'application_questions'];

function hydrate(row) {
  if (!row) return row;
  const out = { ...row };
  const ARRAY_COLS = ['required_skills', 'tags', 'scam_flags', 'application_questions'];
  for (const c of JSON_COLS) out[c] = P(row[c], ARRAY_COLS.includes(c) ? [] : null);
  out.saved = !!row.saved;
  out.follow_up_sent = !!row.follow_up_sent;
  return out;
}

function getJob(id) { return hydrate(db.prepare('SELECT * FROM jobs WHERE id = ?').get(id)); }

function updateJob(id, fields) {
  const keys = Object.keys(fields);
  if (!keys.length) return getJob(id);
  const vals = keys.map((k) => (JSON_COLS.includes(k) && fields[k] != null && typeof fields[k] !== 'string' ? J(fields[k]) : (typeof fields[k] === 'boolean' ? (fields[k] ? 1 : 0) : fields[k])));
  db.prepare(`UPDATE jobs SET ${keys.map((k) => `${k} = ?`).join(', ')}, updated_at = datetime('now') WHERE id = ?`).run(...vals, id);
  return getJob(id);
}

function setStatus(id, status, detail) {
  if (!STATUSES.includes(status)) throw new Error(`Unknown status: ${status}`);
  const before = db.prepare('SELECT status FROM jobs WHERE id = ?').get(id);
  if (!before) throw new Error('Job not found');
  updateJob(id, { status });
  logEvent(id, 'status_change', `${before.status} → ${status}${detail ? ` (${detail})` : ''}`);
  return getJob(id);
}

function logEvent(jobId, type, detail) {
  db.prepare('INSERT INTO events (job_id, type, detail) VALUES (?, ?, ?)').run(jobId, type, detail ?? null);
}

function insertJob(job) {
  const cols = Object.keys(job);
  const vals = cols.map((k) => (JSON_COLS.includes(k) && job[k] != null && typeof job[k] !== 'string' ? J(job[k]) : job[k]));
  const r = db.prepare(`INSERT OR IGNORE INTO jobs (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`).run(...vals);
  return r.changes ? Number(r.lastInsertRowid) : null;
}

function getSetting(key, fallback) {
  const r = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return r ? P(r.value, fallback) : fallback;
}
function setSetting(key, value) {
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(key, J(value));
}

module.exports = { db, DB_PATH, DATA_DIR, STATUSES, getJob, updateJob, setStatus, logEvent, insertJob, getSetting, setSetting, hydrate, now, J, P };
