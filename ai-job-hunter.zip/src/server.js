'use strict';
require('./env').load();
const path = require('node:path');
const crypto = require('node:crypto');
const express = require('express');
const { db, getJob, updateJob, setStatus, logEvent, hydrate, STATUSES, getSetting, setSetting, DB_PATH } = require('./db');
const config = require('./config');
const ai = require('./engine/ai');
const pipeline = require('./engine/pipeline');
const submit = require('./engine/submit');
const followups = require('./engine/followups');
const analytics = require('./engine/analytics');
const scheduler = require('./engine/scheduler');
const { researchCompany } = require('./engine/research');
const { classify } = require('./engine/scoring');
const { smtpReady, sendMail } = require('./engine/notify');
const { assistedLinks } = require('./sources');

const app = express();
app.disable('x-powered-by');
if (process.env.TRUST_PROXY) app.set('trust proxy', +process.env.TRUST_PROXY || 1); // behind a hosting proxy (Render, Railway): real client IP for login rate limit
app.use(express.json({ limit: '2mb' }));
app.use((req, res, next) => { res.set({ 'X-Frame-Options': 'DENY', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' }); next(); });

// ---------------- auth (single user, password -> scrypt hash, HMAC-signed session cookie) ----------------
const SESSION_SECRET = (() => { let s = getSetting('sessionSecret', null); if (!s) { s = crypto.randomBytes(32).toString('hex'); setSetting('sessionSecret', s); } return s; })();
const sign = (v) => `${v}.${crypto.createHmac('sha256', SESSION_SECRET).update(v).digest('base64url')}`;
const verify = (c) => { if (!c) return false; const i = c.lastIndexOf('.'); const v = c.slice(0, i); const ok = sign(v) === c; return ok && +v.split(':')[1] > Date.now(); };
const hashPw = (pw, salt = crypto.randomBytes(16).toString('hex')) => `${salt}:${crypto.scryptSync(pw, salt, 64).toString('hex')}`;
const checkPw = (pw, stored) => { const [salt, h] = stored.split(':'); return crypto.timingSafeEqual(Buffer.from(h, 'hex'), crypto.scryptSync(pw, salt, 64)); };
function passwordHash() { return process.env.APP_PASSWORD ? hashPwEnv() : getSetting('passwordHash', null); }
let envHash = null; function hashPwEnv() { envHash ??= hashPw(process.env.APP_PASSWORD); return envHash; }
const cookie = (req) => Object.fromEntries((req.headers.cookie || '').split(';').map((p) => p.trim().split('=')).filter((a) => a[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join('='))]));
function setSession(res) { const exp = Date.now() + 14 * 86400e3; res.set('Set-Cookie', `jh_session=${encodeURIComponent(sign(`u:${exp}`))}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${14 * 86400}${process.env.COOKIE_SECURE === 'true' ? '; Secure' : ''}`); }

const attempts = new Map();
app.get('/healthz', (req, res) => res.send('ok'));
app.get('/api/auth/status', (req, res) => res.json({ setup: !!passwordHash(), loggedIn: verify(cookie(req).jh_session) }));
app.post('/api/auth/setup', (req, res) => {
  if (passwordHash()) return res.status(400).json({ error: 'Password already set.' });
  if (process.env.NODE_ENV === 'production') return res.status(403).json({ error: 'Set APP_PASSWORD in your hosting settings first.' }); // never let a stranger claim an online copy
  const pw = String(req.body.password || ''); if (pw.length < 8) return res.status(400).json({ error: 'Use at least 8 characters.' });
  setSetting('passwordHash', hashPw(pw)); setSession(res); res.json({ ok: true });
});
app.post('/api/auth/login', (req, res) => {
  const ip = req.ip; const a = attempts.get(ip) || { n: 0, t: Date.now() };
  if (a.n >= 8 && Date.now() - a.t < 15 * 60e3) return res.status(429).json({ error: 'Too many attempts. Wait 15 minutes.' });
  const h = passwordHash();
  if (h && checkPw(String(req.body.password || ''), h)) { attempts.delete(ip); setSession(res); return res.json({ ok: true }); }
  attempts.set(ip, { n: a.n + 1, t: a.n ? a.t : Date.now() }); res.status(401).json({ error: 'Wrong password.' });
});
app.post('/api/auth/logout', (req, res) => { res.set('Set-Cookie', 'jh_session=; Path=/; Max-Age=0'); res.json({ ok: true }); });
app.use('/api', (req, res, next) => {
  if (!verify(cookie(req).jh_session)) return res.status(401).json({ error: 'Not logged in' });
  if (req.method !== 'GET' && !req.is('application/json')) return res.status(415).json({ error: 'JSON required' }); // CSRF guard
  next();
});

const h = (fn) => async (req, res) => { try { const out = await fn(req, res); if (!res.headersSent) res.json(out ?? { ok: true }); } catch (e) { console.error(e); res.status(e.status || 400).json({ error: e.message }); } };
const job404 = (id) => { const j = getJob(id); if (!j) throw Object.assign(new Error('Job not found'), { status: 404 }); return j; };
const withMeta = (j) => ({ ...j, classification: classify(j.match_score), approvalReasons: submit.approvalReasons(j), submissionMethod: submit.submissionMethod(j) });

// ---------------- overview / jobs ----------------
app.get('/api/overview', h(() => ({
  stats: analytics.overview(), running: pipeline.isRunning(), aiAvailable: ai.aiAvailable(), smtpReady: smtpReady(), mode: config.getSettings().mode,
  runs: db.prepare('SELECT * FROM search_runs ORDER BY id DESC LIMIT 8').all().map((r) => ({ ...r, source_report: JSON.parse(r.source_report || 'null') })),
  pipeline: db.prepare("SELECT status, COUNT(*) n FROM jobs WHERE duplicate_of IS NULL GROUP BY status").all(),
})));

app.get('/api/jobs', h((req) => {
  const q = req.query; const where = ['duplicate_of IS NULL']; const args = [];
  if (q.status) { const st = String(q.status).split(','); where.push(`status IN (${st.map(() => '?').join(',')})`); args.push(...st); }
  else if (q.includeArchived !== '1') where.push("status != 'Archived'");
  if (q.minScore) { where.push('match_score >= ?'); args.push(+q.minScore); }
  if (q.platform) { where.push('platform = ?'); args.push(q.platform); }
  if (q.eligibility) { const el = String(q.eligibility).split(','); where.push(`remote_eligibility IN (${el.map(() => '?').join(',')})`); args.push(...el); }
  if (q.type) { where.push('employment_type LIKE ?'); args.push(`%${q.type}%`); }
  if (q.minSalary) { where.push('(salary_max_month IS NULL OR salary_max_month >= ?)'); args.push(+q.minSalary); }
  if (q.salaryKnown === '1') where.push('salary_max_month IS NOT NULL');
  if (q.hours === '30-40') where.push("(hours_per_week IS NULL OR CAST(hours_per_week AS INTEGER) BETWEEN 25 AND 45 OR hours_per_week LIKE '3%' OR hours_per_week LIKE '4%')");
  if (q.level) { where.push('(experience_level LIKE ? OR title LIKE ?)'); args.push(`%${q.level}%`, `%${q.level}%`); }
  if (q.maxAgeDays) { where.push("COALESCE(date_posted, date_discovered) >= datetime('now', ?)"); args.push(`-${+q.maxAgeDays} days`); }
  if (q.saved === '1') where.push('saved = 1');
  if (q.scam) { where.push('scam_risk = ?'); args.push(q.scam); }
  if (q.applied === '1') where.push('date_applied IS NOT NULL');
  if (q.q) { where.push('(title LIKE ? OR company LIKE ? OR description LIKE ? OR category LIKE ?)'); const s = `%${q.q}%`; args.push(s, s, s, s); }
  const sort = { score: 'match_score DESC, date_posted DESC', newest: 'COALESCE(date_posted, date_discovered) DESC', applied: 'date_applied DESC', followup: 'follow_up_date ASC' }[q.sort] || 'match_score DESC, date_posted DESC';
  const limit = Math.min(+q.limit || 50, 500); const offset = +q.offset || 0;
  const total = db.prepare(`SELECT COUNT(*) n FROM jobs WHERE ${where.join(' AND ')}`).get(...args).n;
  const rows = db.prepare(`SELECT id, title, company, platform, url, salary_text, salary_min_month, salary_max_month, hourly_min, hourly_max, match_score, scored_by, category, remote_eligibility, location_restrictions, date_posted, date_discovered, status, saved, scam_risk, employment_type, hours_per_week, date_applied, follow_up_date, proposal IS NOT NULL AS has_proposal FROM jobs WHERE ${where.join(' AND ')} ORDER BY ${sort} LIMIT ? OFFSET ?`).all(...args, limit, offset);
  return { total, jobs: rows.map((r) => ({ ...r, saved: !!r.saved, has_proposal: !!r.has_proposal, classification: classify(r.match_score) })) };
}));
app.get('/api/platforms', h(() => db.prepare('SELECT platform, COUNT(*) n FROM jobs GROUP BY platform ORDER BY n DESC').all()));

app.get('/api/jobs/:id', h((req) => ({ ...withMeta(job404(+req.params.id)), autonomous: submit.autonomousCheck(getJob(+req.params.id)), events: db.prepare('SELECT * FROM events WHERE job_id = ? ORDER BY id DESC').all(+req.params.id) })));

const EDITABLE = ['notes', 'proposal', 'application_questions', 'contact_info', 'saved', 'follow_up_draft', 'follow_up_date', 'apply_email', 'company_url', 'salary_text'];
app.patch('/api/jobs/:id', h((req) => {
  job404(+req.params.id);
  const patch = Object.fromEntries(Object.entries(req.body).filter(([k]) => EDITABLE.includes(k)));
  if ('proposal' in patch) logEvent(+req.params.id, 'proposal_edited', 'edited by you');
  return withMeta(updateJob(+req.params.id, patch));
}));
app.post('/api/jobs/:id/status', h((req) => {
  const id = +req.params.id; const j = job404(id); const st = req.body.status;
  if (st === 'Applied' && !j.date_applied) return submit.markApplied(id, req.body.via || 'manual');
  if (['Interview', 'Rejected', 'Offer', 'Assessment'].includes(st)) logEvent(id, 'response', `Employer response: ${st}`);
  return setStatus(id, st, req.body.detail || 'by you');
}));
app.post('/api/jobs/:id/analyze', h(async (req) => {
  const id = +req.params.id; job404(id);
  if (!ai.aiAvailable()) throw new Error('Add your Anthropic API key in Settings → Integrations to run Claude analysis. The rules score is already shown.');
  return withMeta(await pipeline.analyzeWithClaude(id));
}));
app.post('/api/jobs/:id/research', h(async (req) => { const j = job404(+req.params.id); const r = await researchCompany(j, config.getProfile(), ai); return updateJob(j.id, { company_research: r }); }));
app.post('/api/jobs/:id/proposal', h(async (req) => withMeta(await pipeline.generateProposal(+req.params.id, req.body || {}))));
app.post('/api/jobs/:id/approve', h((req) => {
  const id = +req.params.id; const j = job404(id);
  if (!j.proposal) throw new Error('Generate or write a proposal first.');
  if (/\[YOUR INPUT/i.test(j.proposal) || (j.application_questions || []).some((q) => /\[YOUR INPUT/i.test(q.answer || ''))) throw new Error('Fill in every [YOUR INPUT ...] placeholder before approving.');
  updateJob(id, { approved_at: new Date().toISOString() });
  logEvent(id, 'approved', 'Application approved by you');
  if (j.status !== 'Awaiting Approval' && !j.date_applied) setStatus(id, 'Awaiting Approval', 'approved, ready to send');
  return withMeta(getJob(id));
}));
app.post('/api/jobs/:id/apply', h(async (req) => {
  const id = +req.params.id; const j = job404(id);
  if (!j.approved_at) throw new Error('Approve the application first.');
  const method = req.body.method || submit.submissionMethod(j);
  if (method === 'email') return submit.submitByEmail(id, { approvedByUser: true });
  if (method === 'assisted') return submit.assistedApply(id);
  throw new Error('Apply on the platform yourself, then press Mark as Applied.');
}));
app.post('/api/jobs/:id/mark-applied', h((req) => submit.markApplied(+req.params.id, req.body.via || 'manual')));
app.post('/api/jobs/:id/reject', h((req) => { job404(+req.params.id); updateJob(+req.params.id, { notes: [getJob(+req.params.id).notes, `Not interested: ${req.body.reason || 'rejected by you'}`].filter(Boolean).join('\n') }); return setStatus(+req.params.id, 'Archived', 'rejected by you'); }));
app.post('/api/jobs/:id/followup/draft', h(async (req) => { const j = job404(+req.params.id); if (!j.date_applied) throw new Error('Not applied yet.'); if (j.follow_up_sent) throw new Error('A follow-up was already sent.'); return updateJob(j.id, { follow_up_draft: await followups.draftFor(j), follow_up_stage: 'day14-inactive' }); }));
app.post('/api/jobs/:id/followup/send', h((req) => followups.sendFollowUp(+req.params.id, req.body)));
app.post('/api/jobs/:id/followup/mark-sent', h((req) => followups.markFollowUpSent(+req.params.id, 'manual')));
app.delete('/api/jobs/:id', h((req) => { db.prepare('DELETE FROM jobs WHERE id = ?').run(+req.params.id); return { deleted: true }; }));

app.post('/api/import', h((req) => pipeline.importJob(req.body)));
app.post('/api/search/run', h(async () => { if (pipeline.isRunning()) return { alreadyRunning: true }; pipeline.runSearch({ trigger: 'manual' }).catch((e) => console.error('[search]', e)); return { started: true }; }));
app.get('/api/search/runs', h(() => db.prepare('SELECT * FROM search_runs ORDER BY id DESC LIMIT 30').all().map((r) => ({ ...r, source_report: JSON.parse(r.source_report || 'null') }))));
app.get('/api/assisted-links', h(() => assistedLinks(config.getSettings().keywords || config.getProfile().searchKeywords)));
app.post('/api/followups/run', h(() => followups.processFollowUps()));
app.post('/api/rescore', h(() => ({ rescored: pipeline.rescoreAll() })));

app.get('/api/notifications', h(() => ({ unread: db.prepare('SELECT COUNT(*) n FROM notifications WHERE read = 0').get().n, items: db.prepare('SELECT * FROM notifications ORDER BY id DESC LIMIT 60').all() })));
app.post('/api/notifications/read', h((req) => { if (req.body.id) db.prepare('UPDATE notifications SET read = 1 WHERE id = ?').run(+req.body.id); else db.prepare('UPDATE notifications SET read = 1').run(); }));

app.get('/api/analytics/weekly', h((req) => analytics.weeklyReport(req.query.date ? new Date(req.query.date) : new Date(), { withAI: req.query.ai === '1' })));
app.get('/api/reports', h(() => db.prepare('SELECT id, week_start, created_at FROM reports ORDER BY id DESC LIMIT 20').all()));

// ---------------- settings / profile / secrets ----------------
app.get('/api/settings', h(() => ({ settings: config.getSettings(), secrets: config.secretStatus(), statuses: STATUSES, dbPath: DB_PATH, schedule: scheduler.cronFor(config.getSettings()) || 'off' })));
app.put('/api/settings', h((req) => {
  const patch = { ...req.body };
  if (patch.mode === 'autonomous' && patch.autonomousArmed && !req.body.confirmAutonomous) throw new Error('Confirm autonomous mode explicitly.');
  delete patch.confirmAutonomous;
  const s = config.saveSettings(patch); const sched = scheduler.start(); return { settings: s, schedule: sched };
}));
app.put('/api/secrets', h((req) => { for (const k of ['anthropicApiKey', 'smtpPass']) if (k in req.body) config.setSecret(k, req.body[k] || null); return config.secretStatus(); }));
app.get('/api/profile', h(() => config.getProfile()));
app.put('/api/profile', h((req) => { config.saveProfile(req.body); return config.getProfile(); }));
app.post('/api/test/smtp', h(async () => { const to = config.getSettings().notifications.emailTo || config.getSettings().smtp.user; await sendMail({ to, subject: 'Job Hunter test email', text: 'SMTP works.' }); return { sentTo: to }; }));
app.post('/api/test/ai', h(async () => { if (!ai.aiAvailable()) throw new Error('No API key set.'); const Anthropic = require('@anthropic-ai/sdk'); const c = new Anthropic({ apiKey: config.getSecret('anthropicApiKey') }); const r = await c.messages.create({ model: config.getSettings().ai.model, max_tokens: 64, messages: [{ role: 'user', content: 'Reply with the single word OK.' }] }); return { ok: true, reply: r.content.find((b) => b.type === 'text')?.text }; }));

app.get('/api/export.csv', (req, res) => {
  if (!verify(cookie(req).jh_session)) return res.status(401).end();
  const cols = ['id', 'title', 'company', 'platform', 'url', 'status', 'match_score', 'scam_risk', 'remote_eligibility', 'salary_text', 'date_posted', 'date_discovered', 'date_applied', 'applied_via', 'follow_up_date', 'notes'];
  const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const rows = db.prepare(`SELECT ${cols.join(',')} FROM jobs WHERE duplicate_of IS NULL ORDER BY id`).all();
  res.type('text/csv').set('Content-Disposition', 'attachment; filename="jobs.csv"').send([cols.join(','), ...rows.map((r) => cols.map((c) => esc(r[c])).join(','))].join('\n'));
});

app.use(express.static(path.join(__dirname, '..', 'public')));
app.get(/^\/(?!api).*/, (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

if (require.main === module) {
  const PORT = +process.env.PORT || 3000; const HOST = process.env.HOST || '127.0.0.1';
  app.listen(PORT, HOST, () => {
    const sch = scheduler.start();
    console.log(`AI Job Hunter running at http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`);
    console.log(`Schedule: ${sch.search} (${sch.timezone}) | Claude: ${ai.aiAvailable() ? 'ready' : 'no API key yet'} | SMTP: ${smtpReady() ? 'ready' : 'not configured'}`);
    followups.processFollowUps().catch(() => {});
  });
}
module.exports = app;
