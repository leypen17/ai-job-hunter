'use strict';
// Job Normalization Engine: cleans HTML, normalizes salary to USD/month, detects remote
// eligibility (incl. Philippines), hours, employment type, apply email and a dedupe fingerprint.

function htmlToText(html) {
  if (!html) return '';
  return String(html)
    .replace(/<\s*(script|style)[^>]*>[\s\S]*?<\/\s*\1\s*>/gi, ' ')
    .replace(/<\s*br\s*\/?>/gi, '\n').replace(/<\s*\/(p|div|li|h\d|tr)\s*>/gi, '\n').replace(/<\s*li[^>]*>/gi, '• ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#0?39;|&rsquo;|&lsquo;/g, "'").replace(/&ldquo;|&rdquo;/g, '"').replace(/&mdash;|&ndash;/g, '-').replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n))
    .replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n\n').trim();
}

// ---------- salary ----------
const CURRENCY_SIGNS = { '$': 'USD', '€': 'EUR', '£': 'GBP', '₱': 'PHP', '₹': 'INR' };
function toNumber(s, k) { let n = parseFloat(String(s).replace(/,/g, '')); if (k) n *= 1000; return n; }

function parseSalaryText(text) {
  if (!text) return null;
  const t = String(text);
  const m = t.match(/([$€£₱₹]|USD|EUR|GBP|PHP|CAD|AUD)?\s?(\d[\d,]*(?:\.\d+)?)\s*(k)?\s*(?:-|–|to)\s*([$€£₱₹]|USD|EUR|GBP|PHP|CAD|AUD)?\s?(\d[\d,]*(?:\.\d+)?)\s*(k)?/i)
    || t.match(/([$€£₱₹]|USD|EUR|GBP|PHP|CAD|AUD)\s?(\d[\d,]*(?:\.\d+)?)\s*(k)?/i);
  if (!m) return null;
  let cur, min, max;
  if (m.length >= 7 && m[5]) {
    cur = m[1] || m[4]; min = toNumber(m[2], m[3] || m[6]); max = toNumber(m[5], m[6]);
  } else { cur = m[1]; min = max = toNumber(m[2], m[3]); }
  if (!cur && !/usd|\$|per|hour|month|year|annum|k\b/i.test(t)) return null;
  const currency = CURRENCY_SIGNS[cur] || (cur ? cur.toUpperCase() : 'USD');
  let period = null;
  if (/(per|an|\/|a)\s*(hour|hr)\b|hourly/i.test(t)) period = 'hour';
  else if (/(per|a|\/)\s*(month|mo)\b|monthly/i.test(t)) period = 'month';
  else if (/(per|a|\/)\s*(week|wk)\b|weekly/i.test(t)) period = 'week';
  else if (/(per|a|\/)\s*(year|yr|annum)|annual|yearly|\bk\b|\dk/i.test(t)) period = 'year';
  if (!period) period = max < 200 ? 'hour' : max <= 15000 ? 'month' : 'year';
  return { min, max, currency, period };
}

function toMonthlyUSD({ min, max, currency = 'USD', period = 'year' }, rates = {}, hoursPerWeek = 40) {
  const rate = currency === 'USD' ? 1 : rates[currency];
  if (!rate) return null;
  const f = { hour: hoursPerWeek * 4.33, week: 4.33, month: 1, year: 1 / 12 }[period] ?? 1 / 12;
  const mm = (v) => (v ? Math.round(v * rate * f) : null);
  const res = { minMonth: mm(min), maxMonth: mm(max || min) };
  if (period === 'hour') { res.hourlyMin = +(min * rate).toFixed(2); res.hourlyMax = +((max || min) * rate).toFixed(2); }
  else if (res.minMonth) { res.hourlyMin = +(res.minMonth / (hoursPerWeek * 4.33)).toFixed(2); res.hourlyMax = +(res.maxMonth / (hoursPerWeek * 4.33)).toFixed(2); }
  return res;
}

// ---------- hours / type ----------
function detectHours(text) {
  const t = text || '';
  const r = t.match(/(\d{1,2})\s*(?:-|–|to)\s*(\d{1,2})\s*(?:hours|hrs|h)\s*(?:per|a|\/|each)?\s*(?:week|wk)/i);
  if (r) return `${r[1]}-${r[2]}`;
  const s = t.match(/(\d{1,2})\+?\s*(?:hours|hrs)\s*(?:per|a|\/|each)\s*(?:week|wk)/i);
  if (s) return s[1];
  return null;
}
function detectEmploymentType(raw, text) {
  const s = `${raw || ''} ${String(text || '').slice(0, 3000)}`.toLowerCase();
  const types = [];
  if (/full[\s_-]?time/.test(s)) types.push('full-time');
  if (/part[\s_-]?time/.test(s)) types.push('part-time');
  if (/contract|contractor/.test(s)) types.push('contract');
  if (/freelance/.test(s)) types.push('freelance');
  if (/intern(ship)?\b/.test(s)) types.push('internship');
  return types.length ? [...new Set(types)].join(', ') : (raw || null);
}

// ---------- remote eligibility ----------
const RESTRICT_PATTERNS = [
  [/\b(us|u\.s\.|usa|united states)[\s-]*(only|based|residents?|citizens?)\b|(must|need to|required to) (be (located|based|residing|a resident)|reside|live)[^.]{0,25}\b(in|within) (the )?(us|u\.s\.|usa|united states)\b|authori[sz]ed to work in the (us|u\.s\.|united states)|\bw-?2\b/i, 'US only'],
  [/\b(canada|canadian)[\s-]*(only|based|residents?)\b|(must|need to) (be (located|based)|reside|live)[^.]{0,25}\bin canada/i, 'Canada only'],
  [/\b(eu|europe|emea)[\s-]*(only|based|residents?)\b|(must|need to) (be (located|based)|reside|live)[^.]{0,25}\bin (the )?(eu|europe|european union)\b|right to work in the (uk|eu)/i, 'EU/UK only'],
  [/\b(uk|united kingdom)[\s-]*(only|based|residents?)\b/i, 'UK only'],
  [/\b(latam|latin america)[\s-]*(only|based)\b/i, 'LATAM only'],
  [/\b(australia|nz|new zealand)[\s-]*(only|based)\b/i, 'AU/NZ only'],
  [/\b(india)[\s-]*(only|based)\b/i, 'India only'],
];
const REGION_WORDS = /\b(usa|united states|us|u\.s\.|canada|europe|eu|emea|uk|united kingdom|germany|france|spain|latam|latin america|brazil|mexico|australia|new zealand|india|americas|north america|south africa|israel|poland|portugal|netherlands)\b/i;

function detectEligibility(locationText, descText) {
  const loc = String(locationText || '').toLowerCase();
  const desc = String(descText || '').toLowerCase();
  const restrictions = [];
  for (const [re, label] of RESTRICT_PATTERNS) if (re.test(desc) || re.test(loc)) restrictions.push(label);

  const nonRemote = /\b(on[\s-]?site|in[\s-]office|hybrid)\b/i.test(loc) || /\b(this (is an?|role is) (on[\s-]?site|hybrid)|hybrid (role|position|schedule)|must (come|commute) (in)?to (the|our) office)\b/i.test(desc);
  if (nonRemote) return { eligibility: 'not_remote', restrictions: [...restrictions, 'On-site/hybrid'].join('; '), philippinesOk: false };

  const mentionsPH = /philippines|\bph\b|filipino|manila/.test(loc) || /(open to|welcome|including|based in|from) (the )?philippines|philippines[- ]based|filipino (va|virtual|candidates|applicants)/.test(desc);
  if (mentionsPH) return { eligibility: 'philippines', restrictions: restrictions.join('; ') || null, philippinesOk: true };

  const worldwide = /worldwide|anywhere|global|international|all countries|\bremote\b\s*$|^remote$/.test(loc.trim()) || /work from anywhere|open to (candidates|applicants) (from )?(anywhere|worldwide|all countries)|location[: ]+(anywhere|worldwide)/.test(desc);
  const asia = /\basia\b|apac|asia[- ]pacific|southeast asia|\bsea\b|gmt\s?\+\s?8|utc\s?\+\s?8/.test(loc) || /\b(apac|southeast asia)\b/.test(desc);

  if (restrictions.length) return { eligibility: 'restricted', restrictions: restrictions.join('; '), philippinesOk: false };
  if (asia) return { eligibility: 'asia', restrictions: null, philippinesOk: true };
  if (worldwide) return { eligibility: 'worldwide', restrictions: null, philippinesOk: true };
  if (loc && REGION_WORDS.test(loc)) return { eligibility: 'restricted', restrictions: `Location: ${locationText}`, philippinesOk: false };
  return { eligibility: 'unclear', restrictions: locationText || null, philippinesOk: null };
}

// ---------- misc ----------
function findApplyEmail(text) {
  const emails = String(text || '').match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || [];
  return emails.find((e) => !/noreply|no-reply|example\.|privacy|gdpr|accessibility|accommodation/i.test(e)) || null;
}
function fingerprint(company, title) {
  const n = (s) => String(s || '').toLowerCase().replace(/\(.*?\)|\[.*?\]/g, ' ').replace(/\b(remote|full[- ]?time|part[- ]?time|contract|freelance|wfh|worldwide|urgent|hiring)\b/g, ' ').replace(/[^a-z0-9]+/g, ' ').trim();
  return `${n(company)}|${n(title)}`;
}

const SKILL_VOCAB = [
  'gohighlevel', 'highlevel', 'ghl', 'zapier', 'n8n', 'make.com', 'integromat', 'webhooks', 'api', 'rest api', 'hubspot', 'salesforce', 'zoho', 'klaviyo', 'mailchimp', 'activecampaign', 'keap', 'pipedrive', 'monday.com', 'clickup', 'asana', 'notion', 'airtable', 'trello', 'jira', 'google workspace', 'excel', 'google sheets', 'canva', 'photoshop', 'figma', 'capcut', 'wordpress', 'wix', 'shopify', 'zendesk', 'freshdesk', 'intercom', 'seo', 'local seo', 'google analytics', 'ga4', 'search console', 'google business profile', 'google ads', 'facebook ads', 'meta ads', 'tiktok', 'instagram', 'facebook', 'linkedin', 'youtube', 'email marketing', 'copywriting', 'content creation', 'social media', 'chatgpt', 'openai', 'claude', 'ai agents', 'llm', 'prompt engineering', 'chatbot', 'python', 'javascript', 'sql', 'crm', 'lead generation', 'cold email', 'sales navigator', 'project management', 'agile', 'scrum', 'sop', 'data entry', 'customer support', 'calendar management', 'bookkeeping', 'quickbooks', 'video editing', 'adobe premiere', 'slack', 'loom', 'funnels', 'retool', 'bubble', 'webflow', 'stripe',
];
function extractSkills(text) {
  const t = ` ${String(text || '').toLowerCase()} `;
  return SKILL_VOCAB.filter((s) => new RegExp(`[^a-z0-9]${s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}[^a-z0-9]`).test(t));
}

function normalize(raw, settings) {
  const description = htmlToText(raw.description);
  const full = `${raw.title}\n${description}`;
  let sal = null;
  if (raw.salary_min || raw.salary_max) sal = { min: +raw.salary_min || +raw.salary_max, max: +raw.salary_max || +raw.salary_min, currency: raw.salary_currency || 'USD', period: raw.salary_period || 'year' };
  else sal = parseSalaryText(raw.salary_text) || parseSalaryText((description.match(/[^.\n]*(salary|compensation|pay|rate)[^.\n]*/i) || [])[0]);
  const hours = detectHours(full);
  const hoursNum = hours ? Math.max(...hours.split('-').map(Number)) : 40;
  const money = sal ? toMonthlyUSD(sal, settings?.usdRates || {}, hoursNum) : null;
  const elig = detectEligibility(raw.location_text, description);
  // A region named in the title ("BDR - DACH", "Ops Manager - LATAM") overrides a generic "anywhere" location.
  const titleRegion = String(raw.title || '').match(/\b(LATAM|LatAm|DACH|EMEA|NORAM|AMER|Americas|North America|USA?|U\.S\.|UK|Canada|Europe|EU|Brazil|Mexico|Germany|France|Spain|Netherlands|Australia|India)\b/);
  if (titleRegion && !['philippines', 'asia', 'not_remote'].includes(elig.eligibility)) Object.assign(elig, { eligibility: 'restricted', restrictions: [elig.restrictions, `Title names a region: ${titleRegion[1]}`].filter(Boolean).join('; '), philippinesOk: false });
  let datePosted = null;
  if (raw.date_posted) { const d = new Date(raw.date_posted); if (!isNaN(d)) datePosted = d.toISOString(); }
  return {
    source: raw.source, source_id: raw.source_id || raw.url, platform: raw.platform,
    title: String(raw.title || '').trim().slice(0, 300), company: raw.company ? String(raw.company).trim() : null,
    company_url: raw.company_url || null, url: raw.url, apply_url: raw.apply_url || raw.url,
    apply_email: findApplyEmail(description), date_posted: datePosted,
    salary_text: raw.salary_text || (sal ? `${sal.currency} ${sal.min}${sal.max && sal.max !== sal.min ? `-${sal.max}` : ''} / ${sal.period}` : null),
    salary_min_month: money?.minMonth ?? null, salary_max_month: money?.maxMonth ?? null,
    hourly_min: money?.hourlyMin ?? null, hourly_max: money?.hourlyMax ?? null,
    hours_per_week: hours, employment_type: detectEmploymentType(raw.employment_type, description),
    remote_eligibility: elig.eligibility, location_restrictions: elig.restrictions,
    description, required_skills: extractSkills(full), category: raw.category || null,
    experience_level: raw.experience_level || null, tags: raw.tags || [], fingerprint: fingerprint(raw.company, raw.title),
  };
}

module.exports = { normalize, htmlToText, parseSalaryText, toMonthlyUSD, detectEligibility, detectHours, detectEmploymentType, fingerprint, extractSkills, findApplyEmail, SKILL_VOCAB };
