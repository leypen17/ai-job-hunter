'use strict';
// Company Research Engine: fetches the company's own site (home + about) and has Claude
// summarize only what those pages and the posting say. Without an API key it stores the
// page title/meta description so you still see something real.
const { fetchText } = require('../sources/http');
const { htmlToText } = require('./normalize');

const JOB_BOARD_HOSTS = /(remotive|remoteok|weworkremotely|workingnomads|jobicy|himalayas|greenhouse|lever\.co|ashbyhq|linkedin|indeed|upwork|glassdoor|wellfound|angel\.co|workable|bamboohr|smartrecruiters|jobvite|recruitee|breezy|google\.com|forms\.gle|typeform|notion\.site|bit\.ly|t\.co)/i;

function guessCompanySite(job) {
  if (job.company_url) return job.company_url;
  const urls = String(job.description || '').match(/https?:\/\/[^\s)"'<>]+/g) || [];
  for (const u of [...urls, job.apply_url]) {
    try { const h = new URL(u); if (!JOB_BOARD_HOSTS.test(h.host)) return `${h.protocol}//${h.host}`; } catch { /* ignore */ }
  }
  return null;
}

function meta(html) {
  const title = (html.match(/<title[^>]*>([^<]*)<\/title>/i) || [])[1]?.trim();
  const desc = (html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']*)/i) || html.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']*)/i) || [])[1]?.trim();
  return { title, desc };
}

async function fetchCompanyPages(site) {
  const pages = [];
  for (const p of ['', '/about', '/about-us']) {
    try {
      const html = await fetchText(site.replace(/\/$/, '') + p, { timeoutMs: 12000, retries: 0 });
      pages.push({ url: site + p, text: htmlToText(html).slice(0, 12000), meta: meta(html) });
      if (pages.length >= 2) break;
    } catch { /* page missing */ }
  }
  return pages;
}

async function researchCompany(job, profile, ai) {
  const site = guessCompanySite(job);
  const pages = site ? await fetchCompanyPages(site) : [];
  if (ai.aiAvailable()) {
    const { data } = await ai.synthesizeResearch(job, pages, profile);
    return { site, sources: pages.map((p) => p.url), ...data, by: 'claude' };
  }
  const m = pages[0]?.meta || {};
  return { site, sources: pages.map((p) => p.url), overview: m.desc || m.title || 'Not stated (no company site found).', by: 'page-metadata', note: 'Add an Anthropic API key for a full research summary.' };
}

module.exports = { researchCompany, guessCompanySite };
