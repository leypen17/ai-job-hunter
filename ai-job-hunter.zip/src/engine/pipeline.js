'use strict';
// The 17-step daily job-hunting workflow: discover → normalize → dedupe → eligibility → rules score →
// scam check → reject irrelevant → Claude analysis → research → proposal/answers → apply per mode →
// record → follow-ups (followups.js) → weekly analytics (analytics.js).
const { db, getJob, updateJob, setStatus, insertJob, logEvent, getSetting, setSetting } = require('../db');
const { getSettings, getProfile } = require('../config');
const { SOURCES } = require('../sources');
const { normalize, extractSkills } = require('./normalize');
const { ruleScore, weighted, classify, detectCategory } = require('./scoring');
const { scamCheck, maxRisk } = require('./scam');
const ai = require('./ai');
const { researchCompany } = require('./research');
const { notify } = require('./notify');
const submit = require('./submit');

let running = null;
const log = (...a) => console.log('[pipeline]', ...a);

function applyRuleResults(id, job, profile, settings) {
  const r = ruleScore(job, profile, settings);
  const scam = scamCheck(job);
  const fields = { rule_score: r.score, category: job.category && !r.category ? job.category : r.category || job.category, scam_risk: scam.risk, scam_flags: scam.flags };
  if (job.scored_by !== 'claude') Object.assign(fields, { match_score: r.score, score_breakdown: r.criteria, match_explanation: r.explanation, scored_by: 'rules' });
  updateJob(id, fields);
  return { r, scam };
}

async function analyzeWithClaude(id) {
  const job = getJob(id); const profile = getProfile();
  const prev = job.status;
  if (!['Applied', 'Interview', 'Offer'].includes(prev)) updateJob(id, { status: 'Analyzing' });
  try {
    const { data } = await ai.analyzeJob(job, profile);
    const c = data.criteria;
    // Keep hard eligibility rules authoritative: Claude can't lift a restricted job above 45.
    let score = weighted(c);
    const blocked = data.remote.philippinesEligible === 'no' || !data.remote.genuinelyRemote || ['restricted', 'not_remote'].includes(job.remote_eligibility) && data.remote.philippinesEligible !== 'yes';
    if (blocked) score = Math.min(score, 45);
    const scam = maxRisk(job.scam_risk || 'Low', data.scam.risk);
    const explanation = { ...data, classification: classify(score), interviewLikelihood: { ...data.interviewLikelihood, disclaimer: 'AI estimate, not a factual prediction.' }, source: 'claude' };
    const elig = data.remote.philippinesEligible === 'yes' && ['unclear'].includes(job.remote_eligibility) ? 'worldwide' : job.remote_eligibility;
    updateJob(id, {
      match_score: score, score_breakdown: c, match_explanation: explanation, scored_by: 'claude', category: data.category || job.category,
      scam_risk: scam, scam_flags: [...new Set([...(job.scam_flags || []), ...data.scam.flags])], remote_eligibility: elig,
      required_skills: data.requiredSkills?.length ? data.requiredSkills : job.required_skills,
      application_questions: (data.applicationQuestions || []).map((q) => ({ question: q, answer: '', needsInput: false, note: '' })),
    });
    const next = ['Applied', 'Interview', 'Offer', 'Assessment', 'Follow-Up Due'].includes(prev) ? prev : score >= 70 && scam !== 'High' ? 'Qualified' : score >= 60 ? 'New' : 'Archived';
    setStatus(id, next, `Claude score ${score}`);
    return getJob(id);
  } catch (e) {
    updateJob(id, { status: prev });
    throw e;
  }
}

function offlineDraft(job, profile) {
  // Used only without an API key. Built from matched profile facts; clearly labeled.
  const skills = (job.match_explanation?.relevantSkills || []).slice(0, 6).map((s) => s.replace(' (self-reported)', ''));
  const exp = profile.experience.slice(0, 3).map((e) => `${e.title} at ${e.company}`).join('; ');
  return `[OFFLINE DRAFT - not AI-tailored. Add an Anthropic API key for a personalized proposal, or rewrite this before sending.]

Hi ${job.company ? `${job.company} team` : 'there'},

Your ${job.title} role caught my attention. I have ${profile.yearsExperience}+ years of remote experience across ${profile.headline.toLowerCase()}, and have supported 200+ clients, including SaaS organizations such as Qubole and Metadata.io.
${skills.length ? `\nRelevant to your posting, I work with ${skills.join(', ')}.` : ''}
Recent roles: ${exp}.

[YOUR INPUT: one sentence on how you would tackle the main problem in this posting]

I'm based in the Philippines, available ${profile.preferences.hoursPerWeek.min}-${profile.preferences.hoursPerWeek.max} hours a week, and comfortable overlapping US hours. I'd be glad to talk about what you need.

${profile.name}`;
}

async function generateProposal(id, opts = {}) {
  const job = getJob(id); const profile = getProfile();
  let research = job.company_research;
  if (!research && opts.research !== false) {
    try { research = await researchCompany(job, profile, ai); updateJob(id, { company_research: research }); } catch (e) { log('research failed', e.message); }
  }
  const questions = opts.questions?.length ? opts.questions : (job.application_questions || []).map((q) => q.question);
  if (!ai.aiAvailable()) {
    updateJob(id, { proposal: offlineDraft(getJob(id), profile), proposal_style: 'offline-draft', application_questions: questions.map((q) => ({ question: q, answer: '', needsInput: true, note: 'Add an API key to draft answers, or answer yourself.' })) });
  } else {
    const { data } = await ai.writeProposal(job, profile, { format: opts.format || 'auto', questions, research, extraInstructions: opts.instructions || '' });
    updateJob(id, { proposal: data.proposal, proposal_style: data.style || opts.format || 'auto', application_questions: data.answers, notes: [job.notes, data.needsUserInput?.length ? `Needs your input: ${data.needsUserInput.join('; ')}` : '', data.rateSuggestion ? `Rate suggestion: ${data.rateSuggestion}` : ''].filter(Boolean).join('\n') });
  }
  const after = getJob(id);
  if (!['Applied', 'Interview', 'Offer', 'Assessment', 'Follow-Up Due'].includes(after.status)) {
    setStatus(id, 'Proposal Generated');
    if (getSettings().mode !== 'search_only') setStatus(id, 'Awaiting Approval');
  }
  logEvent(id, 'proposal', `Generated (${after.proposal_style})`);
  return getJob(id);
}

async function fetchAll(settings, report) {
  const profile = getProfile();
  const keywords = settings.keywords || profile.searchKeywords;
  const raws = [];
  for (const src of SOURCES) {
    if (!settings.sources[src.id]) { report[src.id] = { skipped: 'disabled' }; continue; }
    const lastKey = `lastFetch:${src.id}`; const last = getSetting(lastKey, 0);
    if (src.minIntervalHours && Date.now() - last < src.minIntervalHours * 3600e3) { report[src.id] = { skipped: `fetched < ${src.minIntervalHours}h ago (source rate limit)` }; continue; }
    try {
      const items = await src.fetchJobs({ keywords, settings });
      raws.push(...items); setSetting(lastKey, Date.now());
      report[src.id] = { fetched: items.length, ...(items.partialErrors?.length ? { errors: items.partialErrors } : {}) };
    } catch (e) { report[src.id] = { error: e.message }; log(src.id, 'failed:', e.message); }
  }
  return raws;
}

function ingest(raws, settings, profile, counters, report) {
  const maxAge = Date.now() - settings.maxAgeDays * 86400e3;
  const newIds = [];
  const fpStmt = db.prepare('SELECT id FROM jobs WHERE fingerprint = ? AND duplicate_of IS NULL AND NOT (source = ? AND source_id = ?) ORDER BY id LIMIT 1');
  const existsStmt = db.prepare('SELECT id FROM jobs WHERE source = ? AND source_id = ?');
  for (const raw of raws) {
    if (!raw.url || !raw.title) continue;
    const job = normalize(raw, settings);
    counters.found++;
    if (job.date_posted && new Date(job.date_posted).getTime() < maxAge) { counters.tooOld++; continue; }
    if (existsStmt.get(job.source, job.source_id)) { counters.seen++; continue; }
    const r = ruleScore(job, profile, settings);
    // Eliminate irrelevant positions before they reach the database (no matching category and weak fit).
    if (!r.category && r.score < 40) { counters.irrelevant++; continue; }
    const dup = fpStmt.get(job.fingerprint, job.source, job.source_id);
    if (dup) { job.duplicate_of = dup.id; job.status = 'Archived'; job.notes = `Duplicate of job #${dup.id}`; counters.duplicates++; }
    const id = insertJob(job);
    if (!id) continue;
    const { r: rr, scam } = applyRuleResults(id, getJob(id), profile, settings);
    if (!dup) {
      const status = rr.blockers.length || rr.score < settings.rejectBelow ? 'Archived' : rr.score >= 70 && scam.risk !== 'High' ? 'Qualified' : 'New';
      updateJob(id, { status, notes: status === 'Archived' ? `Auto-deprioritized: ${rr.blockers.join('; ') || `rule score ${rr.score}`}` : null });
      logEvent(id, 'discovered', `${job.platform}; rule score ${rr.score}`);
      newIds.push(id);
    }
  }
  return newIds;
}

async function runSearch({ trigger = 'manual' } = {}) {
  if (running) return { alreadyRunning: true };
  running = (async () => {
    const settings = getSettings(); const profile = getProfile();
    const runId = Number(db.prepare('INSERT INTO search_runs (trigger) VALUES (?)').run(trigger).lastInsertRowid);
    const report = {}; const counters = { found: 0, seen: 0, tooOld: 0, irrelevant: 0, duplicates: 0, analyzed: 0, aiErrors: 0, proposals: 0, sent: 0 };
    try {
      const raws = await fetchAll(settings, report);
      const newIds = ingest(raws, settings, profile, counters, report);

      // Claude analysis for the most promising unscored jobs
      if (ai.aiAvailable()) {
        const cands = db.prepare(`SELECT id FROM jobs WHERE scored_by = 'rules' AND duplicate_of IS NULL AND status IN ('New','Qualified') AND rule_score >= ? ORDER BY rule_score DESC, date_posted DESC LIMIT ?`).all(settings.aiScoreMinRuleScore, settings.ai.maxJobsPerRun);
        for (const { id } of cands) {
          try { await analyzeWithClaude(id); counters.analyzed++; } catch (e) { counters.aiErrors++; log('analyze', id, e.message); if (/api key|authentication|401|credit/i.test(e.message)) break; }
        }
      }

      // Notifications for strong new matches and scams
      const fresh = newIds.length ? db.prepare(`SELECT * FROM jobs WHERE id IN (${newIds.map(() => '?').join(',')})`).all(...newIds) : [];
      for (const j of fresh) {
        const cur = getJob(j.id);
        if (cur.scam_risk === 'High') await notify('scam', `Possible scam: ${cur.title}`, (cur.scam_flags || []).join('; '), cur.id);
        else if (cur.match_score >= 90) await notify('match90', `Excellent match (${cur.match_score}): ${cur.title} at ${cur.company}`, cur.match_explanation?.summary || '', cur.id);
        else if (cur.match_score >= settings.notifications.minScoreAlert) await notify('match85', `Strong match (${cur.match_score}): ${cur.title} at ${cur.company}`, cur.match_explanation?.summary || '', cur.id);
      }

      // Modes 2 and 3: proposals for qualified jobs, then submission per mode
      if (settings.mode !== 'search_only') {
        const q = db.prepare(`SELECT id FROM jobs WHERE status = 'Qualified' AND proposal IS NULL AND match_score >= ? AND scam_risk != 'High' AND duplicate_of IS NULL ORDER BY match_score DESC LIMIT ?`).all(settings.autoProposalMinScore, settings.ai.maxJobsPerRun);
        for (const { id } of q) {
          try {
            const j = await generateProposal(id); counters.proposals++;
            if (settings.mode === 'autonomous') {
              const gate = submit.autonomousCheck(j, settings);
              if (gate.ok) { await submit.submitByEmail(id, { approvedByUser: false }); counters.sent++; }
              else { updateJob(id, { notes: [j.notes, `Needs approval: ${gate.blockers.join('; ')}`].filter(Boolean).join('\n') }); await notify('approval', `Approval needed: ${j.title} at ${j.company}`, gate.blockers.join('; '), id); }
            } else await notify('approval', `Ready for review (${j.match_score}): ${j.title} at ${j.company}`, 'Proposal drafted. Review, edit and approve before anything is sent.', id);
          } catch (e) { log('proposal', id, e.message); if (/api key|authentication|401|credit/i.test(e.message)) break; }
        }
      }

      const qualified = db.prepare(`SELECT COUNT(*) n FROM jobs WHERE status IN ('Qualified','Proposal Generated','Awaiting Approval') AND date_discovered >= (SELECT started_at FROM search_runs WHERE id = ?)`).get(runId).n;
      db.prepare('UPDATE search_runs SET finished_at = datetime(\'now\'), found = ?, new_jobs = ?, duplicates = ?, qualified = ?, source_report = ? WHERE id = ?')
        .run(counters.found, newIds.length, counters.duplicates, qualified, JSON.stringify({ sources: report, counters }), runId);
      if (settings.notifications.dailyReport && trigger !== 'manual') await notify('report', `Search finished: ${newIds.length} new jobs, ${qualified} qualified`, `Found ${counters.found} postings; ${counters.seen} already known, ${counters.duplicates} duplicates, ${counters.irrelevant} irrelevant, ${counters.tooOld} too old. Claude analyzed ${counters.analyzed}. Proposals drafted: ${counters.proposals}. Sent: ${counters.sent}.`);
      return { runId, newJobs: newIds.length, qualified, counters, sources: report };
    } catch (e) {
      db.prepare('UPDATE search_runs SET finished_at = datetime(\'now\'), error = ?, source_report = ? WHERE id = ?').run(e.message, JSON.stringify({ sources: report, counters }), runId);
      throw e;
    }
  })();
  try { return await running; } finally { running = null; }
}

// Manual import for assisted platforms (LinkedIn, Indeed, Upwork, OnlineJobs.ph, ...)
function importJob(input) {
  const settings = getSettings(); const profile = getProfile();
  if (!input.title || !input.url) throw new Error('Title and URL are required.');
  const platform = input.platform || (() => { try { return new URL(input.url).host.replace(/^www\./, ''); } catch { return 'Manual'; } })();
  const job = normalize({ ...input, source: 'manual', source_id: input.url, platform, description: input.description || '' }, settings);
  const exists = db.prepare('SELECT id FROM jobs WHERE url = ? OR (fingerprint = ? AND duplicate_of IS NULL)').get(job.url, job.fingerprint);
  if (exists) return { id: exists.id, duplicate: true };
  const id = insertJob(job);
  const { r } = applyRuleResults(id, getJob(id), profile, settings);
  updateJob(id, { status: r.blockers.length ? 'Archived' : r.score >= 70 ? 'Qualified' : 'New' });
  logEvent(id, 'imported', platform);
  return { id, duplicate: false };
}

function rescoreAll() {
  const settings = getSettings(); const profile = getProfile();
  const rows = db.prepare("SELECT id FROM jobs WHERE scored_by = 'rules'").all();
  for (const { id } of rows) { const j = getJob(id); j.required_skills = extractSkills(`${j.title}\n${j.description}`); updateJob(id, { required_skills: j.required_skills }); applyRuleResults(id, j, profile, settings); }
  return rows.length;
}

const isRunning = () => !!running;
module.exports = { runSearch, analyzeWithClaude, generateProposal, importJob, rescoreAll, isRunning, offlineDraft, ingest };
