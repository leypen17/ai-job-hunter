'use strict';
// Application Performance Analytics. Every number here is counted from your own database.
const { db, hydrate } = require('../db');
const { getProfile } = require('../config');
const { hasSkill, profileSkillSet } = require('./scoring');
const ai = require('./ai');

const RESPONDED = ['Interview', 'Assessment', 'Offer', 'Rejected'];
const pct = (a, b) => (b ? Math.round((a / b) * 1000) / 10 : null);

function overview() {
  const one = (sql, ...a) => db.prepare(sql).get(...a).n;
  const applied = one("SELECT COUNT(*) n FROM jobs WHERE date_applied IS NOT NULL");
  const interviews = one("SELECT COUNT(DISTINCT job_id) n FROM events WHERE type='status_change' AND detail LIKE '%→ Interview%'");
  const responded = one(`SELECT COUNT(*) n FROM jobs WHERE date_applied IS NOT NULL AND status IN (${RESPONDED.map(() => '?').join(',')})`, ...RESPONDED);
  return {
    jobsFoundToday: one("SELECT COUNT(*) n FROM jobs WHERE date(date_discovered) = date('now') AND duplicate_of IS NULL"),
    totalAnalyzed: one("SELECT COUNT(*) n FROM jobs WHERE match_score IS NOT NULL AND duplicate_of IS NULL"),
    analyzedByClaude: one("SELECT COUNT(*) n FROM jobs WHERE scored_by='claude'"),
    excellent: one("SELECT COUNT(*) n FROM jobs WHERE match_score >= 90 AND duplicate_of IS NULL AND status != 'Archived'"),
    strong: one("SELECT COUNT(*) n FROM jobs WHERE match_score BETWEEN 80 AND 89 AND duplicate_of IS NULL AND status != 'Archived'"),
    applicationsSubmitted: applied,
    awaitingApproval: one("SELECT COUNT(*) n FROM jobs WHERE status = 'Awaiting Approval'"),
    interviews: one("SELECT COUNT(*) n FROM jobs WHERE status = 'Interview'"),
    interviewsEver: interviews,
    rejections: one("SELECT COUNT(*) n FROM jobs WHERE status = 'Rejected'"),
    pendingResponses: one("SELECT COUNT(*) n FROM jobs WHERE status IN ('Applied','Follow-Up Due')"),
    successRate: pct(interviews, applied),
    responseRate: pct(responded, applied),
    followUpsDue: one("SELECT COUNT(*) n FROM jobs WHERE status = 'Follow-Up Due'"),
  };
}

function weekRange(ref = new Date()) {
  const d = new Date(Date.UTC(ref.getUTCFullYear(), ref.getUTCMonth(), ref.getUTCDate()));
  const day = (d.getUTCDay() + 6) % 7; d.setUTCDate(d.getUTCDate() - day);
  const end = new Date(d); end.setUTCDate(end.getUTCDate() + 7);
  return [d.toISOString().slice(0, 10), end.toISOString().slice(0, 10)];
}

function group(rows, key) {
  const m = {};
  for (const r of rows) { const k = r[key] || 'Unknown'; m[k] ??= { applied: 0, interviews: 0, responses: 0 }; m[k].applied++; if (r.gotInterview) m[k].interviews++; if (r.responded) m[k].responses++; }
  return Object.entries(m).map(([k, v]) => ({ name: k, ...v, interviewRate: pct(v.interviews, v.applied) })).sort((a, b) => b.interviews - a.interviews || b.responses - a.responses || b.applied - a.applied);
}

async function weeklyReport(ref = new Date(), { withAI = true } = {}) {
  const [start, end] = weekRange(ref);
  const profile = getProfile(); const sets = profileSkillSet(profile);
  const n = (sql) => db.prepare(sql).get(start, end).n;
  const discovered = n("SELECT COUNT(*) n FROM jobs WHERE date(date_discovered) >= ? AND date(date_discovered) < ? AND duplicate_of IS NULL");
  const qualified = n("SELECT COUNT(*) n FROM jobs WHERE date(date_discovered) >= ? AND date(date_discovered) < ? AND match_score >= 70 AND duplicate_of IS NULL");
  const appliedWeek = n("SELECT COUNT(*) n FROM jobs WHERE date(date_applied) >= ? AND date(date_applied) < ?");
  const interviewsWeek = n("SELECT COUNT(DISTINCT job_id) n FROM events WHERE type='status_change' AND detail LIKE '%→ Interview%' AND date(created_at) >= ? AND date(created_at) < ?");

  const interviewed = new Set(db.prepare("SELECT DISTINCT job_id FROM events WHERE type='status_change' AND detail LIKE '%→ Interview%'").all().map((r) => r.job_id));
  const appliedAll = db.prepare('SELECT * FROM jobs WHERE date_applied IS NOT NULL').all().map(hydrate).map((j) => ({ ...j, gotInterview: interviewed.has(j.id), responded: RESPONDED.includes(j.status) || interviewed.has(j.id) }));

  const qualRows = db.prepare("SELECT required_skills, match_explanation FROM jobs WHERE match_score >= 60 AND date(date_discovered) >= date(?, '-28 days') AND duplicate_of IS NULL").all(end).map(hydrate);
  const freq = {}; for (const j of qualRows) for (const s of j.required_skills || []) freq[s.toLowerCase()] = (freq[s.toLowerCase()] || 0) + 1;
  const requested = Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 15).map(([skill, count]) => ({ skill, count, inProfile: !!hasSkill(skill, sets) }));
  const missing = requested.filter((s) => !s.inProfile);

  const companiesResponded = appliedAll.filter((j) => j.responded).map((j) => ({ company: j.company, title: j.title, status: j.status }));
  const report = {
    week: { start, end },
    jobsDiscovered: discovered, qualifiedJobs: qualified, applicationsSubmitted: appliedWeek, interviews: interviewsWeek,
    interviewConversionRate: pct(interviewsWeek, appliedWeek), allTime: { applied: appliedAll.length, interviews: appliedAll.filter((j) => j.gotInterview).length, conversion: pct(appliedAll.filter((j) => j.gotInterview).length, appliedAll.length) },
    bestCategories: group(appliedAll, 'category').slice(0, 8), bestProposalStyles: group(appliedAll, 'proposal_style').slice(0, 8), platforms: group(appliedAll, 'platform'),
    mostRequestedSkills: requested, missingSkills: missing, companiesResponded,
    sampleNote: appliedAll.length < 10 ? 'Fewer than 10 applications so far: category/style/platform comparisons are not yet meaningful.' : null,
  };
  let recs = [];
  if (missing.length) recs.push(`Skills often requested that aren't on your profile: ${missing.slice(0, 5).map((s) => s.skill).join(', ')}. Add any you genuinely have to your CV and profile.json.`);
  if (discovered && !qualified) recs.push('No qualified jobs this week: consider adding company ATS boards (Settings → Sources) or broadening keywords.');
  if (appliedWeek === 0 && qualified > 0) recs.push(`${qualified} qualified jobs this week but no applications. Review Top Matches.`);
  if (withAI && ai.aiAvailable() && (discovered || appliedAll.length)) { try { recs = (await ai.weeklyInsights(report, profile)).data.recommendations; } catch (e) { recs.push(`(AI insights unavailable: ${e.message})`); } }
  report.recommendations = recs;
  return report;
}

async function saveWeeklyReport() {
  const r = await weeklyReport(new Date(Date.now() - 86400e3));
  db.prepare('INSERT INTO reports (week_start, data) VALUES (?, ?)').run(r.week.start, JSON.stringify(r));
  return r;
}

module.exports = { overview, weeklyReport, saveWeeklyReport, weekRange };
