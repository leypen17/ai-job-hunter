'use strict';
// Follow-Up Automation. Day 3: check-in reminder. Day 5-7: draft ONE follow-up (never auto-sent).
// Day 14: flag as inactive / awaiting response. Platform rules are respected by you sending it.
const { db, getJob, updateJob, setStatus, logEvent } = require('../db');
const { getProfile, getSettings } = require('../config');
const ai = require('./ai');
const { notify, sendMail, smtpReady } = require('./notify');

const MESSAGING_LIMITED = /linkedin|indeed|glassdoor|onlinejobs|upwork|wellfound/i;
const daysSince = (iso) => (Date.now() - new Date(iso).getTime()) / 86400e3;

async function draftFor(job) {
  const profile = getProfile();
  if (ai.aiAvailable()) { const { data } = await ai.writeFollowUp(job, profile); return `Subject: ${data.subject}\n\n${data.message}`; }
  return `Subject: Following up on my ${job.title} application\n\nHi ${job.company || 'there'} team,\n\nI applied for the ${job.title} role on ${job.date_applied.slice(0, 10)} and wanted to check whether there's any update. I'm still very interested and happy to share more about my experience if helpful.\n\nThanks for your time,\n${profile.name}\n\n[Offline draft - edit before sending]`;
}

async function processFollowUps() {
  if (!getSettings().followUps.enabled) return { skipped: true };
  const rows = db.prepare("SELECT id FROM jobs WHERE date_applied IS NOT NULL AND status IN ('Applied','Follow-Up Due') AND COALESCE(follow_up_stage,'') != 'inactive'").all();
  const out = { checked: rows.length, day3: 0, drafted: 0, inactive: 0 };
  for (const { id } of rows) {
    const job = getJob(id); const d = daysSince(job.date_applied);
    const via = MESSAGING_LIMITED.test(`${job.platform} ${job.url}`) ? ` Send it only through ${job.platform}'s own messaging, and only if the platform allows messaging this employer.` : '';
    if (job.follow_up_stage === 'day3-check' && d >= 3) {
      updateJob(id, { follow_up_stage: 'day5-draft', follow_up_date: plus(job.date_applied, 5) });
      await notify('followup', `Day 3 check: ${job.title} at ${job.company}`, `No follow-up needed yet unless the posting invited questions. A follow-up draft will be ready on day 5.${via}`, id);
      out.day3++;
    } else if (job.follow_up_stage === 'day5-draft' && d >= 5 && !job.follow_up_sent) {
      try {
        const draft = await draftFor(job);
        updateJob(id, { follow_up_draft: draft, follow_up_stage: 'day14-inactive', follow_up_date: plus(job.date_applied, 14) });
        setStatus(id, 'Follow-Up Due', 'day 5-7 follow-up drafted');
        await notify('followup', `Follow-up ready: ${job.title} at ${job.company}`, `Review the draft and send it yourself, or skip it.${via}`, id);
        out.drafted++;
      } catch (e) { console.error('[followups]', e.message); }
    } else if (['day14-inactive', 'day5-draft'].includes(job.follow_up_stage) && d >= 14) {
      updateJob(id, { follow_up_stage: 'inactive', notes: [job.notes, `Inactive / awaiting response since ${new Date().toISOString().slice(0, 10)} (14 days, no reply).`].filter(Boolean).join('\n') });
      if (job.status === 'Follow-Up Due') setStatus(id, 'Applied', 'day 14: inactive, awaiting response');
      await notify('followup', `No response after 14 days: ${job.title}`, 'Flagged as inactive. No more follow-ups will be suggested.', id);
      out.inactive++;
    }
  }
  return out;
}

async function sendFollowUp(id, { text } = {}) {
  const job = getJob(id);
  if (job.follow_up_sent) throw new Error('A follow-up was already sent for this application. Repeated follow-ups are blocked.');
  const draft = text || job.follow_up_draft;
  if (!draft) throw new Error('No follow-up draft.');
  if (job.applied_via !== 'email' || !job.apply_email || !smtpReady()) throw new Error('This application was not sent by email. Send the follow-up through the platform yourself, then press "Mark follow-up sent".');
  const m = draft.match(/^Subject:\s*(.+)\n+([\s\S]*)$/);
  await sendMail({ to: job.apply_email, subject: m ? m[1] : `Re: Application: ${job.title}`, text: m ? m[2] : draft });
  return markFollowUpSent(id, 'email');
}
function markFollowUpSent(id, via = 'manual') {
  updateJob(id, { follow_up_sent: 1 });
  logEvent(id, 'followup_sent', via);
  const job = getJob(id);
  if (job.status === 'Follow-Up Due') setStatus(id, 'Applied', 'follow-up sent');
  return getJob(id);
}
function plus(iso, d) { const t = new Date(iso); t.setDate(t.getDate() + d); return t.toISOString(); }

module.exports = { draftFor, processFollowUps, sendFollowUp, markFollowUpSent };
