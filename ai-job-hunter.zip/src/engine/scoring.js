'use strict';
// AI Job Match Engine. A deterministic rules scorer runs on every job (free, offline) and acts as
// a pre-filter; jobs that pass are re-scored by Claude (see ai.js). The final 0-100 score is always
// computed here from the 8 weighted criteria, so the weights in the spec are enforced in code.

const WEIGHTS = { skills: 0.30, experience: 0.20, automation: 0.15, compensation: 0.10, remote: 0.10, hours: 0.05, longTerm: 0.05, growth: 0.05 };

function classify(score) {
  if (score == null) return 'Unscored';
  if (score >= 90) return 'Excellent Match';
  if (score >= 80) return 'Strong Match';
  if (score >= 70) return 'Good Match';
  if (score >= 60) return 'Possible Match';
  return 'Reject / Deprioritize';
}

function weighted(c) {
  return Math.round(Object.entries(WEIGHTS).reduce((s, [k, w]) => s + w * Math.max(0, Math.min(100, Number(c[k]) || 0)), 0));
}

// Title patterns -> priority category (order = priority from the profile)
const CATEGORY_RULES = [
  [/\b(ai|llm|gpt)\b.*\bautomation|automation.*\b(ai)\b/i, 'AI Automation Specialist'],
  [/\bai\b.*\boperations|ai ops/i, 'AI Operations Specialist'],
  [/\b(ai )?agent (builder|developer)|ai agents?\b/i, 'AI Agent Builder'],
  [/\bai\b.*(workflow|implementation)/i, 'AI Implementation Specialist'],
  [/\bn8n\b/i, 'n8n Automation Specialist'],
  [/\bzapier\b/i, 'Zapier Automation Specialist'],
  [/\b(go ?high ?level|highlevel|ghl)\b/i, 'GoHighLevel Specialist'],
  [/no[- ]?code|low[- ]?code/i, 'No-Code Automation Specialist'],
  [/crm.*(automation|specialist|manager)|hubspot|salesforce admin/i, 'CRM Automation Specialist'],
  [/crm admin/i, 'CRM Administrator'],
  [/marketing automation|marketing ops|marketing operations/i, 'Marketing Automation Specialist'],
  [/\bautomation\b/i, 'Automation Specialist'],
  [/sales op(eration)?s|revops|revenue operations/i, 'Sales Operations Specialist'],
  [/systems? (specialist|administrator|manager)|business systems/i, 'Systems Specialist'],
  [/saas op/i, 'SaaS Operations Specialist'],
  [/customer success op/i, 'Customer Success Operations'],
  [/process improvement|workflow/i, 'Workflow & Process Improvement Specialist'],
  [/operations (manager|lead|director)|head of operations|ops manager/i, 'Operations Manager'],
  [/(business )?operations (specialist|associate|coordinator|assistant|analyst)|online business manager|obm\b/i, 'Business Operations Specialist'],
  [/agile|scrum master/i, 'Agile Project Manager'],
  [/project (manager|coordinator|lead)|program coordinator/i, 'Project Manager'],
  [/ai (virtual )?assistant/i, 'AI Virtual Assistant'],
  [/technical (virtual )?assistant|tech va/i, 'Technical Virtual Assistant'],
  [/executive (virtual )?assistant|\bea\b|chief of staff/i, 'Executive Virtual Assistant'],
  [/virtual assistant|\bva\b|admin(istrative)? assistant|personal assistant/i, 'Remote Operations Assistant'],
  [/email marketing|lifecycle marketing|retention marketing|klaviyo/i, 'Email Marketing Specialist'],
  [/social media|community manager|content (manager|creator|specialist)/i, 'Social Media Manager'],
  [/digital marketing|growth marketing|marketing (manager|specialist|coordinator)|performance marketing|seo/i, 'Digital Marketing Manager'],
  [/lead gen|appointment setter|sdr|business development rep/i, 'Lead Generation Specialist'],
];
function detectCategory(title, desc = '') {
  for (const [re, cat] of CATEGORY_RULES) if (re.test(title)) return cat;
  for (const [re, cat] of CATEGORY_RULES.slice(0, 11)) if (re.test(desc.slice(0, 1500))) return `${cat} (from description)`;
  return null;
}

const AUTOMATION_TERMS = ['automation', 'automate', 'zapier', 'n8n', 'make.com', 'integromat', 'webhook', 'api', 'workflow', 'gohighlevel', 'highlevel', 'ghl', 'ai ', 'llm', 'chatgpt', 'openai', 'claude', 'agent', 'chatbot', 'crm', 'hubspot', 'no-code', 'integration'];
const HEAVY_TECH = /\b(senior|staff|principal|lead)?\s*(software|backend|frontend|full[- ]?stack|devops|data|ml|machine learning|site reliability|platform|security|ios|android|qa automation|test automation)\s*(engineer|developer|scientist|architect)\b/i;
const OFF_PROFILE = /\b(nurse|physician|doctor|dentist|pharmac|lawyer|attorney|paralegal|cpa\b|accountant|driver|warehouse|electrician|mechanic|teacher|tutor|therapist|clinician|recruiter \(technical\)|sales executive \(enterprise\)|account executive)\b/i;

function profileSkillSet(profile) {
  const verified = new Set(); const self = new Set();
  for (const arr of Object.values(profile.skills?.verifiedOnCV || {})) for (const s of arr) verified.add(s.toLowerCase());
  for (const [k, arr] of Object.entries(profile.skills?.selfReportedNotOnCV || {})) if (Array.isArray(arr)) for (const s of arr) self.add(s.toLowerCase());
  return { verified, self };
}
// Map vocab terms found in postings to profile skill names
const ALIASES = { ghl: 'gohighlevel', highlevel: 'gohighlevel', 'go high level': 'gohighlevel', 'monday.com': 'monday.com', excel: 'microsoft excel', 'search console': 'google search console', ga4: 'google analytics', 'meta ads': 'facebook marketing', 'facebook ads': 'facebook marketing', facebook: 'facebook marketing', instagram: 'instagram marketing', tiktok: 'tiktok marketing', 'zoho': 'zoho crm', api: 'api integrations', 'rest api': 'api integrations', chatbot: 'ai chatbot workflows', 'social media': 'social media management', 'content creation': 'content strategy', sop: 'sop development', crm: 'crm administration', 'project management': 'project management', 'customer support': 'customer support', 'google business profile': 'google business profile', 'sales navigator': 'linkedin sales navigator', agile: 'agile project management', funnels: 'ghl funnels', photoshop: 'adobe photoshop' };
function hasSkill(term, sets) {
  const t = (ALIASES[term] || term).toLowerCase();
  const inSet = (set) => [...set].some((s) => s === t || s.includes(t) || (t.length > 4 && t.includes(s)));
  if (inSet(sets.verified)) return 'verified';
  if (inSet(sets.self)) return 'self';
  return null;
}

function ruleScore(job, profile, settings) {
  const title = job.title || '';
  const desc = job.description || '';
  const text = `${title}\n${desc}`.toLowerCase();
  const sets = profileSkillSet(profile);
  const reasons = []; const missing = []; const relevant = [];

  // Skills
  for (const s of job.required_skills || []) {
    const h = hasSkill(s, sets);
    if (h) relevant.push(h === 'self' ? `${s} (self-reported)` : s); else missing.push(s);
  }
  const req = (job.required_skills || []).length;
  const matchedWeight = relevant.reduce((a, s) => a + (s.includes('self-reported') ? 0.8 : 1), 0);
  let skills = req ? Math.round((matchedWeight / req) * 100) : 45;
  if (req && req < 3) skills = Math.round(skills * 0.8 + 10);

  // Experience / role fit
  const category = detectCategory(title, desc);
  let experience = category ? (category.includes('from description') ? 65 : 85) : 35;
  const yrs = desc.match(/(\d{1,2})\+?\s*(?:years|yrs)/i);
  if (yrs && +yrs[1] > (profile.yearsExperience || 14)) { experience -= 25; reasons.push(`Asks for ${yrs[1]}+ years`); }
  if (HEAVY_TECH.test(title)) { experience = 10; skills = Math.min(skills, 30); reasons.push('Engineering role outside profile'); }
  if (OFF_PROFILE.test(title)) { experience = 5; skills = Math.min(skills, 20); reasons.push('Profession outside profile'); }
  if (/\b(director|vp|vice president|head of)\b/i.test(title) && !/operations|marketing|social/i.test(title)) experience -= 20;

  // Automation / AI relevance
  const autoHits = AUTOMATION_TERMS.filter((t) => text.includes(t)).length;
  let automation = Math.min(100, autoHits * 14);
  if (/automation|ai\b|n8n|zapier|gohighlevel|highlevel|ghl/i.test(title)) automation = Math.max(automation, 85);

  // Compensation
  const pref = profile.preferences?.salaryMonthlyUSD || { min: 1500, target: 2000 };
  let compensation = 55; let compNote = 'Salary not stated';
  if (job.salary_max_month) {
    const max = job.salary_max_month; const min = job.salary_min_month || max;
    if (max >= pref.min) { compensation = min >= pref.min ? 100 : 85; compNote = `~$${min.toLocaleString()}-$${max.toLocaleString()}/mo meets target`; }
    else { compensation = Math.max(0, Math.round((max / pref.min) * 70)); compNote = `~$${max.toLocaleString()}/mo is below the $${pref.min}/mo minimum`; }
  }

  // Remote eligibility
  const remote = { philippines: 100, worldwide: 95, asia: 90, unclear: 50, restricted: 0, not_remote: 0 }[job.remote_eligibility] ?? 50;

  // Hours
  let hours = 60;
  if (job.hours_per_week) { const n = Math.max(...String(job.hours_per_week).split('-').map(Number)); hours = n >= 28 && n <= 45 ? 100 : n < 28 ? 55 : 40; }
  else if (/full-time/.test(job.employment_type || '')) hours = 90;
  else if (/part-time/.test(job.employment_type || '')) hours = 65;
  if (/flexible (hours|schedule)|async/i.test(desc)) hours = Math.min(100, hours + 10);

  // Long-term
  let longTerm = 60;
  if (/full-time|long[- ]term|permanent|ongoing/i.test(`${job.employment_type} ${desc}`)) longTerm = 90;
  if (/one[- ]time|short[- ]term|temporary|\btemp\b|(\d+)[- ]week project|internship/i.test(`${job.employment_type} ${desc}`)) longTerm = 30;

  // Growth
  let growth = 55;
  if (/growth|career (path|development)|promotion|learning|training|mentor|scale|scaling|fast-growing/i.test(desc)) growth = 80;

  const criteria = { skills: Math.max(0, skills), experience: Math.max(0, experience), automation, compensation, remote, hours, longTerm, growth };
  let score = weighted(criteria);

  // Hard rules
  const blockers = [];
  if (job.remote_eligibility === 'restricted') blockers.push(`Location restricted (${job.location_restrictions || 'not open to the Philippines'})`);
  if (job.remote_eligibility === 'not_remote') blockers.push('Not genuinely remote (on-site/hybrid)');
  const excl = (settings?.excludeTitleWords || []).find((w) => title.toLowerCase().includes(w.toLowerCase()));
  if (excl) blockers.push(`Excluded title keyword "${excl}"`);
  if (blockers.length) score = Math.min(score, 45);

  return {
    score, criteria, category, blockers,
    explanation: {
      whyMatch: category ? `Title fits your ${category} target. ${relevant.length}${req ? ` of ${req}` : ''} skills named in the posting are in your profile${relevant.length ? ` (${relevant.slice(0, 5).join(', ')})` : ''}.` : `No priority category in the title; ${relevant.length} of ${req} named skills are in your profile.`,
      summary: blockers.length ? `Deprioritized: ${blockers.join('; ')}.` : `${classify(score)} by rules${category ? ` for ${category}` : ''}.`,
      relevantSkills: relevant, missingQualifications: [...missing.map((m) => `${m} (not in profile)`), ...reasons],
      compensationFit: compNote,
      remoteEligibility: { status: job.remote_eligibility, philippinesEligible: ['philippines', 'worldwide', 'asia'].includes(job.remote_eligibility) ? true : job.remote_eligibility === 'unclear' ? null : false, note: job.location_restrictions || '' },
      worthApplying: !blockers.length && score >= 70,
      interviewLikelihood: null,
      source: 'rules',
    },
  };
}

module.exports = { WEIGHTS, classify, weighted, ruleScore, detectCategory, hasSkill, profileSkillSet };
