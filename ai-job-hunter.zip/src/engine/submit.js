'use strict';
// Application Submission Engine. Three honest paths:
//  1. email     - the posting says "apply by email": the app sends your approved application from
//                 YOUR mailbox via SMTP. This is the only path Mode 3 (autonomous) may use.
//  2. assisted  - opens the employer's form in a visible Playwright browser and pre-fills basic
//                 fields + cover letter. YOU review and press Submit. The app never clicks Submit,
//                 never solves CAPTCHAs, and never logs in for you.
//  3. manual    - copy the proposal, apply yourself, then press "Mark as Applied".
// A job is only marked Applied after a confirmed email send or your own confirmation.
const fs = require('node:fs');
const { getJob, updateJob, setStatus, logEvent } = require('../db');
const { getSettings, getProfile } = require('../config');
const { sendMail, smtpReady, notify } = require('./notify');

const APPROVAL_TRIGGERS = [
  [/video (interview|introduction|recording)|record a (video|loom)|loom video/i, 'Video interview/recording'],
  [/assessment|skills? test|test task|trial task|paid trial|coding challenge/i, 'Assessment or test'],
  [/personality (test|assessment)|disc assessment|myers|16personalities|culture index|predictive index/i, 'Personality test'],
  [/technical (test|interview|exercise)/i, 'Technical test'],
  [/\b(nda|non-disclosure|contract to sign|sign (the|a) (contract|agreement))\b/i, 'Contract / NDA'],
  [/background (check|screening)|criminal record|nbi clearance/i, 'Background check'],
  [/\b(ssn|social security|passport (number|copy)|national id|tin number|government id)\b/i, 'Sensitive personal data'],
  [/bank (account|details)|paypal (email|account)|credit card|payment details/i, 'Financial/payment details'],
  [/declare|declaration|certify that|attest/i, 'Legal declaration'],
  [/salary expectations?|expected (salary|rate|compensation)|desired (salary|pay)/i, 'Salary expectation question'],
];

function approvalReasons(job) {
  const reasons = [];
  const text = `${job.description || ''}\n${(job.application_questions || []).map((q) => q.question).join('\n')}`;
  for (const [re, label] of APPROVAL_TRIGGERS) if (re.test(text)) reasons.push(label);
  for (const q of job.application_questions || []) if (q.needsInput) reasons.push(`Needs your input: "${q.question.slice(0, 80)}"`);
  if (job.scam_risk && job.scam_risk !== 'Low') reasons.push(`Scam risk ${job.scam_risk}`);
  if (/\[YOUR INPUT/i.test(job.proposal || '')) reasons.push('Proposal has [YOUR INPUT] placeholders');
  return [...new Set(reasons)];
}

function submissionMethod(job) {
  if (job.apply_email && smtpReady()) return 'email';
  if (/upwork\.com/i.test(job.url)) return 'manual-upwork';
  return 'assisted';
}

// Gate for Mode 3. Every rule from the spec is checked; the result lists what blocked it.
function autonomousCheck(job, settings = getSettings()) {
  const blockers = [];
  if (settings.mode !== 'autonomous') blockers.push('Mode 3 is not selected');
  if (!settings.autonomousArmed) blockers.push('Autonomous sending is not armed in Settings');
  if ((job.match_score ?? 0) < settings.autonomousMinScore) blockers.push(`Score ${job.match_score} < ${settings.autonomousMinScore}`);
  if (job.scored_by !== 'claude') blockers.push('Not yet analyzed by Claude');
  if (!['philippines', 'worldwide', 'asia'].includes(job.remote_eligibility)) blockers.push(`Philippines eligibility not confirmed (${job.remote_eligibility})`);
  if (job.match_explanation?.remote && job.match_explanation.remote.philippinesEligible !== 'yes') blockers.push('Claude could not confirm Philippines eligibility');
  if (job.match_explanation?.remote && job.match_explanation.remote.genuinelyRemote === false) blockers.push('Not genuinely remote');
  if (job.scam_risk !== 'Low') blockers.push(`Scam risk ${job.scam_risk}`);
  if (job.duplicate_of) blockers.push('Duplicate listing');
  if (job.date_applied) blockers.push('Already applied');
  if (!job.proposal) blockers.push('No proposal generated');
  if ((job.salary_max_month && job.salary_max_month < (getProfile().preferences.salaryMonthlyUSD.min))) blockers.push('Compensation below your minimum');
  if (submissionMethod(job) !== 'email') blockers.push('No authorized automated method (only email applications can be sent automatically)');
  blockers.push(...approvalReasons(job));
  return { ok: blockers.length === 0, blockers };
}

function applicationEmail(job, profile) {
  const answers = (job.application_questions || []).filter((q) => q.answer && !q.needsInput);
  const body = [job.proposal.trim(), answers.length ? `\n\n${answers.map((q) => `${q.question}\n${q.answer}`).join('\n\n')}` : '',
    `\n\n${profile.name}\n${profile.contact.email}${profile.contact.phone ? ` | ${profile.contact.phone}` : ''}${profile.contact.linkedin ? `\n${profile.contact.linkedin}` : ''}`].join('');
  return { subject: `Application: ${job.title} - ${profile.name}`, text: body };
}

async function submitByEmail(jobId, { approvedByUser }) {
  const job = getJob(jobId); const profile = getProfile(); const settings = getSettings();
  if (!job.apply_email) throw new Error('This posting has no application email.');
  if (!job.proposal) throw new Error('Generate and review a proposal first.');
  if (job.date_applied) throw new Error('Already applied.');
  if (!approvedByUser) { const gate = autonomousCheck(job, settings); if (!gate.ok) throw new Error(`Blocked: ${gate.blockers.join('; ')}`); }
  const { subject, text } = applicationEmail(job, profile);
  const attachments = settings.cvPath && fs.existsSync(settings.cvPath) ? [{ filename: require('node:path').basename(settings.cvPath), path: settings.cvPath }] : [];
  const info = await sendMail({ to: job.apply_email, subject, text, attachments });
  const ts = new Date().toISOString();
  updateJob(jobId, { date_applied: ts, applied_via: 'email', follow_up_date: addDays(ts, 3), follow_up_stage: 'day3-check' });
  setStatus(jobId, 'Applied', approvedByUser ? 'sent by email after your approval' : 'sent automatically (Mode 3)');
  logEvent(jobId, 'email_sent', `To ${job.apply_email}; message id ${info.messageId}`);
  await notify('applied', `Application sent: ${job.title} at ${job.company}`, `Sent by email to ${job.apply_email}.`, jobId);
  return { sent: true, messageId: info.messageId };
}

async function assistedApply(jobId) {
  const job = getJob(jobId); const profile = getProfile();
  let playwright;
  try { playwright = require('playwright'); } catch { throw new Error('Assisted apply needs Playwright: run "npm i playwright && npx playwright install chromium", then try again. Or apply manually and press Mark as Applied.'); }
  const browser = await playwright.chromium.launch({ headless: process.env.ASSISTED_HEADLESS === '1' }); // visible so you can review and submit
  const page = await (await browser.newContext()).newPage();
  await page.goto(job.apply_url || job.url, { waitUntil: 'domcontentloaded', timeout: 45000 });
  const [first, ...rest] = profile.name.split(' ');
  const fills = [
    ['input[name*="first" i], input[id*="first" i], input[autocomplete="given-name"]', first],
    ['input[name*="last" i], input[id*="last" i], input[autocomplete="family-name"]', rest.join(' ')],
    ['input[name="name" i], input[name*="full_name" i], input[name*="fullname" i]', profile.name],
    ['input[type="email"], input[name*="email" i]', profile.contact.email],
    ['input[type="tel"], input[name*="phone" i]', profile.contact.phone],
    ['input[name*="linkedin" i], input[id*="linkedin" i]', profile.contact.linkedin],
    ['textarea[name*="cover" i], textarea[id*="cover" i], textarea[name*="comments" i]', job.proposal || ''],
  ];
  const filled = [];
  for (const [sel, val] of fills) {
    if (!val) continue;
    try { const el = page.locator(sel).first(); if (await el.count() && await el.isVisible() && !(await el.inputValue())) { await el.fill(val); filled.push(sel.split(',')[0]); } } catch { /* field absent */ }
  }
  const cv = getSettings().cvPath;
  if (cv && fs.existsSync(cv)) { try { const f = page.locator('input[type="file"]').first(); if (await f.count()) { await f.setInputFiles(cv); filled.push('resume upload'); } } catch { /* none */ } }
  logEvent(jobId, 'assisted_open', `Opened form, pre-filled: ${filled.join(', ') || 'nothing (form not recognized)'}`);
  // Browser stays open for you to review and submit. Close it when done, then Mark as Applied.
  return { opened: true, filled };
}

function markApplied(jobId, via = 'manual') {
  const job = getJob(jobId);
  const ts = new Date().toISOString();
  updateJob(jobId, { date_applied: job.date_applied || ts, applied_via: via, follow_up_date: addDays(ts, 3), follow_up_stage: 'day3-check' });
  return setStatus(jobId, 'Applied', `marked applied by you (${via})`);
}

function addDays(iso, d) { const t = new Date(iso); t.setDate(t.getDate() + d); return t.toISOString(); }

module.exports = { approvalReasons, autonomousCheck, submissionMethod, submitByEmail, assistedApply, markApplied, applicationEmail, addDays };
