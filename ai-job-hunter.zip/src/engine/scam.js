'use strict';
// Scam Detection Engine (rules). Claude adds its own assessment when scoring; the higher risk wins.

const RULES = [
  { re: /(pay|deposit|fee|purchase|buy)[^.]{0,60}(training|starter kit|registration|onboarding|equipment|software license)|upfront (payment|fee)|application fee/i, flag: 'Asks for upfront payment or fees', w: 3 },
  { re: /(cheque|check)[^.]{0,60}(equipment|deposit|supplies)|send (you )?a (cheque|check)/i, flag: 'Equipment-purchase cheque pattern', w: 3 },
  { re: /bitcoin|crypto(currency)?\s*(payment|wallet|deposit)|usdt|pay(ment)? in crypto/i, flag: 'Cryptocurrency payment or requests', w: 2 },
  { re: /bank (login|password|credentials)|online banking (details|access)|(your|share) (bank|card) (pin|password)/i, flag: 'Requests bank credentials', w: 3 },
  { re: /(send|provide|upload)[^.]{0,40}(passport|ssn|social security|national id|driver'?s licen[cs]e)[^.]{0,40}(before|to apply|with your application)/i, flag: 'Identity documents requested before onboarding', w: 3 },
  { re: /telegram|whatsapp only|signal app|contact (us|me) on (telegram|whatsapp)|wickr/i, flag: 'Telegram/WhatsApp-only communication', w: 2 },
  { re: /(install|download)[^.]{0,40}(anydesk|teamviewer|remote access|our (app|software)|apk)/i, flag: 'Asks you to install unusual software', w: 2 },
  { re: /(earn|make) \$?\d{3,},?\d*\s*(per|a|\/)\s*(day|week)|no experience (needed|required)[^.]{0,40}\$\d{3,}/i, flag: 'Unrealistic earnings claims', w: 2 },
  { re: /reshipping|package (forwarding|reshipment)|receive (and|&) (reship|forward) packages|money mule|process payments? (for|on behalf)/i, flag: 'Reshipping / payment-processing scheme', w: 3 },
  { re: /bit\.ly|tinyurl|t\.me\/|wa\.me\/|forms\.gle.*(bank|ssn)/i, flag: 'Shortened or messaging-app links', w: 1 },
  { re: /(hiring immediately|start today|no interview)/i, flag: 'Pressure tactics / no interview', w: 1 },
  { re: /@(gmail|yahoo|outlook|hotmail)\.com/i, flag: 'Recruiter uses a free email address', w: 1, onlyIfNoCompanySite: true },
];

function scamCheck(job) {
  const text = `${job.title}\n${job.description || ''}`;
  const flags = []; let score = 0;
  for (const r of RULES) {
    if (r.onlyIfNoCompanySite && job.company_url) continue;
    if (r.re.test(text)) { flags.push(r.flag); score += r.w; }
  }
  if (!job.company || /^(confidential|private|anonymous|n\/?a|stealth)$/i.test(job.company.trim())) { flags.push('Company not named'); score += 1; }
  if (job.salary_max_month && job.salary_max_month > 15000 && /assistant|data entry|support|virtual/i.test(job.title)) { flags.push('Compensation far above market for the role'); score += 2; }
  if ((job.description || '').length < 250) { flags.push('Very short / vague description'); score += 1; }
  if (job.remote_eligibility === 'not_remote' && /remote/i.test(job.title)) { flags.push('Advertised as remote but description says on-site/hybrid'); score += 1; }
  const risk = score >= 4 ? 'High' : score >= 2 ? 'Moderate' : 'Low';
  return { risk, flags, score };
}

const RANK = { Low: 0, Moderate: 1, High: 2 };
function maxRisk(a, b) { return (RANK[a] ?? 0) >= (RANK[b] ?? 0) ? a : b; }

module.exports = { scamCheck, maxRisk };
