'use strict';
// Notification System: dashboard notifications + optional email (SMTP).
const { db } = require('../db');
const { getSettings, getSecret } = require('../config');

let transport = null; let transportKey = '';
function mailer() {
  const s = getSettings().smtp; const pass = getSecret('smtpPass');
  if (!s.host || !s.user || !pass) return null;
  const key = `${s.host}|${s.port}|${s.user}|${pass}`;
  if (key !== transportKey) {
    const nodemailer = require('nodemailer');
    transport = nodemailer.createTransport({ host: s.host, port: +s.port, secure: !!s.secure, auth: { user: s.user, pass } });
    transportKey = key;
  }
  return transport;
}
const smtpReady = () => !!mailer();

async function sendMail({ to, subject, text, attachments }) {
  const m = mailer(); if (!m) throw new Error('SMTP is not configured (Settings → Integrations).');
  const s = getSettings().smtp;
  return m.sendMail({ from: s.from || s.user, to, subject, text, attachments });
}

async function notify(kind, title, body = '', jobId = null) {
  const r = db.prepare('INSERT INTO notifications (kind, title, body, job_id) VALUES (?, ?, ?, ?)').run(kind, title, body, jobId);
  const n = getSettings().notifications;
  if (n.email && n.emailTo && smtpReady()) {
    try {
      await sendMail({ to: n.emailTo, subject: `[Job Hunter] ${title}`, text: `${body}\n\nOpen the dashboard: ${process.env.PUBLIC_URL || `http://localhost:${process.env.PORT || 3000}`}${jobId ? `/#/job/${jobId}` : ''}` });
      db.prepare('UPDATE notifications SET emailed = 1 WHERE id = ?').run(r.lastInsertRowid);
    } catch (e) { console.error('[notify] email failed:', e.message); }
  }
}
module.exports = { notify, sendMail, smtpReady };
