'use strict';
// Scheduling: every 4 hours, once daily, custom cron, or off (on-demand only).
const cron = require('node-cron');
const { getSettings } = require('../config');
const { runSearch } = require('./pipeline');
const { processFollowUps } = require('./followups');
const { saveWeeklyReport } = require('./analytics');
const { notify } = require('./notify');

let tasks = [];
function cronFor(s) {
  if (s.schedule === 'every4h') return '0 */4 * * *';
  if (s.schedule === 'daily') { const [h, m] = (s.dailyTime || '08:00').split(':'); return `${+m || 0} ${+h || 8} * * *`; }
  if (s.schedule === 'custom' && cron.validate(s.scheduleCron)) return s.scheduleCron;
  return null;
}
function start() {
  stop();
  const s = getSettings(); const tz = process.env.TZ || 'Asia/Manila';
  const expr = cronFor(s);
  if (expr) tasks.push(cron.schedule(expr, () => runSearch({ trigger: `schedule:${s.schedule}` }).catch((e) => notify('error', 'Scheduled search failed', e.message)), { timezone: tz }));
  tasks.push(cron.schedule('30 9 * * *', () => processFollowUps().catch((e) => console.error('[followups]', e.message)), { timezone: tz }));
  tasks.push(cron.schedule('0 18 * * 0', () => saveWeeklyReport().then((r) => notify('report', `Weekly report: ${r.applicationsSubmitted} applications, ${r.interviews} interviews`, (r.recommendations || []).join('\n'))).catch((e) => console.error('[weekly]', e.message)), { timezone: tz }));
  return { search: expr || 'off (on-demand only)', timezone: tz };
}
function stop() { for (const t of tasks) t.stop(); tasks = []; }
module.exports = { start, stop, cronFor };
