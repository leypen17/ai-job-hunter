'use strict';
// Settings, profile and encrypted secret storage.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { getSetting, setSetting, DATA_DIR } = require('./db');

const BUNDLED_PROFILE = path.join(__dirname, '..', 'config', 'profile.json');
const PROFILE_PATH = process.env.PROFILE_PATH || BUNDLED_PROFILE;
// Online hosting: PROFILE_PATH points at the persistent disk. Seed it once from the bundled profile.
if (PROFILE_PATH !== BUNDLED_PROFILE && !fs.existsSync(PROFILE_PATH)) {
  fs.mkdirSync(path.dirname(PROFILE_PATH), { recursive: true });
  fs.copyFileSync(BUNDLED_PROFILE, PROFILE_PATH);
}

const DEFAULT_SETTINGS = {
  mode: 'draft_approve',             // search_only | draft_approve | autonomous
  autonomousArmed: false,            // second switch required before Mode 3 can send anything
  autonomousMinScore: 85,
  autoProposalMinScore: 80,          // Mode 2: generate proposals for jobs at/above this score
  aiScoreMinRuleScore: 45,           // only send jobs with rule score >= this to Claude (saves cost)
  rejectBelow: 60,
  schedule: 'every4h',               // off | every4h | daily | custom
  scheduleCron: '0 8 * * *',         // used when schedule = custom, or daily time
  dailyTime: '08:00',
  maxAgeDays: 21,                    // ignore postings older than this
  sources: {
    remotive: true, remoteok: true, wwr: true, workingnomads: true, jobicy: true, himalayas: true,
    greenhouse: true, lever: true, ashby: true,
  },
  atsBoards: { greenhouse: [], lever: [], ashby: [] },   // company board tokens added by the user
  keywords: null,                    // null = use profile.searchKeywords
  excludeTitleWords: ['senior software engineer', 'staff engineer', 'nurse', 'physician', 'driver', 'warehouse', 'attorney', 'accountant (cpa)'],
  ai: { model: 'claude-opus-5-5', effort: 'medium', maxJobsPerRun: 40 },
  notifications: { email: false, emailTo: '', minScoreAlert: 85, dailyReport: true },
  smtp: { host: '', port: 587, secure: false, user: '', from: '' },
  followUps: { enabled: true },
  cvPath: '',                        // absolute path to your CV PDF (attached to email applications / uploaded in assisted mode)
  usdRates: { PHP: 0.017, EUR: 1.08, GBP: 1.27, CAD: 0.73, AUD: 0.66, INR: 0.012 },
};

function deepMerge(base, over) {
  if (Array.isArray(base) || typeof base !== 'object' || base === null) return over === undefined ? base : over;
  const out = { ...base };
  for (const k of Object.keys(over || {})) out[k] = k in base ? deepMerge(base[k], over[k]) : over[k];
  return out;
}

function getSettings() { return deepMerge(DEFAULT_SETTINGS, getSetting('settings', {})); }
function saveSettings(patch) {
  const merged = deepMerge(getSettings(), patch);
  setSetting('settings', merged);
  return merged;
}

function getProfile() { return JSON.parse(fs.readFileSync(PROFILE_PATH, 'utf8')); }
function saveProfile(p) {
  JSON.parse(JSON.stringify(p)); // validate serializable
  fs.writeFileSync(PROFILE_PATH, JSON.stringify(p, null, 2));
}

// --- encrypted secrets (AES-256-GCM). Key from APP_SECRET, or a generated key file in data/. ---
function secretKey() {
  let s = process.env.APP_SECRET;
  if (!s) {
    const kf = path.join(DATA_DIR, '.secret.key');
    if (!fs.existsSync(kf)) fs.writeFileSync(kf, crypto.randomBytes(32).toString('hex'), { mode: 0o600 });
    s = fs.readFileSync(kf, 'utf8').trim();
  }
  return crypto.createHash('sha256').update(s).digest();
}
function encrypt(plain) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', secretKey(), iv);
  const enc = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return [iv, c.getAuthTag(), enc].map((b) => b.toString('base64')).join('.');
}
function decrypt(blob) {
  const [iv, tag, enc] = blob.split('.').map((s) => Buffer.from(s, 'base64'));
  const d = crypto.createDecipheriv('aes-256-gcm', secretKey(), iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(enc), d.final()]).toString('utf8');
}

const SECRET_ENV = { anthropicApiKey: 'ANTHROPIC_API_KEY', smtpPass: 'SMTP_PASS' };
function getSecret(name) {
  if (process.env[SECRET_ENV[name]]) return process.env[SECRET_ENV[name]];
  const blob = getSetting(`secret:${name}`, null);
  if (!blob) return null;
  try { return decrypt(blob); } catch { return null; }
}
function setSecret(name, value) { setSetting(`secret:${name}`, value ? encrypt(value) : null); }
function secretStatus() {
  return Object.fromEntries(Object.keys(SECRET_ENV).map((k) => [k, getSecret(k) ? (process.env[SECRET_ENV[k]] ? 'set (env)' : 'set (encrypted in DB)') : 'missing']));
}

module.exports = { getSettings, saveSettings, getProfile, saveProfile, getSecret, setSecret, secretStatus, DEFAULT_SETTINGS, encrypt, decrypt };
