'use strict';
// Daily cloud search for the hosted AI Job Hunter page.
// Fetches the public job feeds, normalizes, dedupes, rules-scores and scam-checks them with the same
// engine as the app, and writes the NEW worthwhile jobs as page documents for Claude to save with
// ArtifactData. It never applies, never logs in anywhere, and never invents jobs.
//
// Usage: node daily/run.js <existingDir> <outDir> [runsVersion] [notificationsVersion]
//   existingDir: ArtifactData `list` out_dir of data/users/me (JSON files, searched recursively)
//   outDir:      receives one <jobId>.json per new job, merged runs.json + notifications.json,
//                summary.json, and batch.json (the ArtifactData batch `writes` to send as-is)
//   versions:    the current `version` of the runs / notifications docs from that listing (omit if absent)
const fs = require('fs');
const path = require('path');
const { SOURCES } = require('../src/sources');
const { normalize } = require('../src/engine/normalize');
const { ruleScore } = require('../src/engine/scoring');
const { scamCheck } = require('../src/engine/scam');
const PROFILE_FILE = require('../config/profile.json');

const [existingDir, outDir, runsVersion, notifsVersion] = process.argv.slice(2);
if (!outDir) { console.error('usage: node daily/run.js <existingDir> <outDir>'); process.exit(2); }

const HOSTED_DEFAULTS = { // keep in sync with hosted/hosted-app.js DEFAULT_SETTINGS
  rejectBelow: 60, maxAgeDays: 21,
  excludeTitleWords: ['senior software engineer', 'staff engineer', 'nurse', 'physician', 'driver', 'warehouse', 'attorney'],
  usdRates: { PHP: 0.017, EUR: 1.08, GBP: 1.27, CAD: 0.73, AUD: 0.66, INR: 0.012 },
};
const MAX_NEW = Number(process.env.MAX_NEW || 40);
const MAX_DESC = 12000;
const hashId = (s) => { let h = 5381; for (const c of String(s)) h = ((h * 33) ^ c.charCodeAt(0)) >>> 0; return h.toString(36); };

function readExisting(dir) {
  const docs = new Map();
  if (!dir || !fs.existsSync(dir)) return docs;
  const walk = (d) => { for (const f of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, f.name);
    if (f.isDirectory()) walk(p);
    else if (f.name.endsWith('.json')) {
      try { let v = JSON.parse(fs.readFileSync(p, 'utf8')); if (!v.kind && v.data && typeof v.data === 'object' && v.data.kind) v = v.data; docs.set(path.basename(f.name, '.json'), v); } catch { /* skip unreadable */ }
    }
  } };
  walk(dir); return docs;
}

(async () => {
  const existing = readExisting(existingDir);
  const stored = existing.get('settings') || {};
  const settings = { ...HOSTED_DEFAULTS, ...stored, sources: { remotive: true, remoteok: true, wwr: true, workingnomads: true, jobicy: true, himalayas: true, greenhouse: true, lever: true, ashby: true, ...(stored.sources || {}) }, atsBoards: stored.atsBoards || { greenhouse: [], lever: [], ashby: [] } };
  const profile = existing.get('profile')?.data || PROFILE_FILE;
  const keywords = settings.keywords || profile.searchKeywords;
  const knownIds = new Set(); const fps = new Set();
  for (const [id, v] of existing) if (v.kind === 'job') { knownIds.add(id); if (v.fingerprint) fps.add(v.fingerprint); }

  const report = {}; const raws = [];
  for (const src of SOURCES) {
    if (!settings.sources[src.id]) { report[src.id] = 'disabled'; continue; }
    if (['greenhouse', 'lever', 'ashby'].includes(src.id) && !(settings.atsBoards[src.id] || []).length) { report[src.id] = 'no company boards added'; continue; }
    try { const items = await src.fetchJobs({ keywords, settings }); raws.push(...items); report[src.id] = items.length; }
    catch (e) { report[src.id] = `error: ${e.message}`; }
  }

  const maxAge = Date.now() - settings.maxAgeDays * 86400e3;
  const c = { found: 0, seen: 0, tooOld: 0, irrelevant: 0, duplicates: 0, belowBar: 0 };
  const keep = [];
  const now = new Date().toISOString();
  for (const raw of raws) {
    if (!raw || !raw.title || !raw.url) continue;
    const job = normalize(raw, settings); c.found++;
    const id = `j_${hashId(`${job.source}|${job.source_id}`)}`;
    if (knownIds.has(id)) { c.seen++; continue; }
    if (job.date_posted && new Date(job.date_posted).getTime() < maxAge) { c.tooOld++; continue; }
    const r = ruleScore(job, profile, settings);
    if (!r.category && r.score < 40) { c.irrelevant++; continue; }
    if (fps.has(job.fingerprint)) { c.duplicates++; continue; }
    if (r.blockers.length || r.score < settings.rejectBelow) { c.belowBar++; continue; }
    const scam = scamCheck(job);
    fps.add(job.fingerprint); knownIds.add(id);
    if (job.description && job.description.length > MAX_DESC) job.description = `${job.description.slice(0, MAX_DESC)}\n[…trimmed; see the original posting]`;
    Object.assign(job, {
      id, date_discovered: now, updated_at: now, extra: null, rule_score: r.score, match_score: r.score, score_breakdown: r.criteria,
      match_explanation: r.explanation, scored_by: 'rules', category: r.category || job.category, scam_risk: scam.risk, scam_flags: scam.flags,
      status: r.score >= 70 && scam.risk !== 'High' ? 'Qualified' : 'New',
      events: [{ at: now, type: 'discovered', detail: `${job.platform} via daily cloud search; rule score ${r.score}` }],
    });
    keep.push(job);
  }
  keep.sort((a, b) => b.match_score - a.match_score);
  const saved = keep.slice(0, MAX_NEW);

  fs.mkdirSync(outDir, { recursive: true });
  for (const j of saved) fs.writeFileSync(path.join(outDir, `${j.id}.json`), JSON.stringify({ kind: 'job', ...j }));
  const errors = Object.entries(report).filter(([, v]) => String(v).startsWith('error')).map(([k, v]) => `${k}: ${String(v).slice(7)}`);
  const run = { at: now, source: 'Daily cloud search', found: c.found, added: saved.length, seen: c.seen, duplicates: c.duplicates, irrelevant: c.irrelevant + c.belowBar, tooOld: c.tooOld, errors };
  const notifications = saved.filter((j) => j.scam_risk === 'High').map((j) => ({ kind: 'scam', title: `Possible scam: ${j.title}`, body: j.scam_flags.join('; '), jobId: j.id, at: now, read: false }))
    .concat(saved.filter((j) => j.scam_risk !== 'High' && j.match_score >= 80).map((j) => ({ kind: 'match', title: `Strong match (${j.match_score}): ${j.title}`, body: j.match_explanation?.summary || '', jobId: j.id, at: now, read: false })));
  if (saved.length) notifications.push({ kind: 'search', title: `Daily search: ${saved.length} new job${saved.length === 1 ? '' : 's'}`, body: `Best score ${saved[0].match_score}. Rules-scored; open a job and press Analyze for Claude's score.`, jobId: null, at: now, read: false });
  const summary = { run, notifications, perSource: report, keptBeforeCap: keep.length, files: saved.map((j) => `${j.id}.json`),
    top: saved.slice(0, 10).map((j) => ({ score: j.match_score, title: j.title, company: j.company, platform: j.platform, eligibility: j.remote_eligibility, scam: j.scam_risk })) };
  fs.writeFileSync(path.join(outDir, 'summary.json'), JSON.stringify(summary, null, 2));
  const runsDoc = { kind: 'runs', items: [run, ...(existing.get('runs')?.items || [])].slice(0, 25) };
  const notifsDoc = { kind: 'notifications', items: [...notifications, ...(existing.get('notifications')?.items || [])].slice(0, 80) };
  fs.writeFileSync(path.join(outDir, 'runs.json'), JSON.stringify(runsDoc));
  fs.writeFileSync(path.join(outDir, 'notifications.json'), JSON.stringify(notifsDoc));
  const abs = (f) => path.resolve(outDir, f);
  const pin = (v) => (v && /^\d+$/.test(v) ? { if_version: Number(v) } : {});
  const writes = saved.map((j) => ({ op: 'set', collection: 'data/users/me', doc_id: j.id, file_path: abs(`${j.id}.json`) }));
  writes.push({ op: 'set', collection: 'data/users/me', doc_id: 'runs', file_path: abs('runs.json'), ...pin(runsVersion) });
  if (notifications.length) writes.push({ op: 'set', collection: 'data/users/me', doc_id: 'notifications', file_path: abs('notifications.json'), ...pin(notifsVersion) });
  fs.writeFileSync(path.join(outDir, 'batch.json'), JSON.stringify(writes));
  console.log(JSON.stringify({ ...summary, notifications: notifications.length }, null, 2));
})().catch((e) => { console.error(e); process.exit(1); });
