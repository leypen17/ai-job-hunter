'use strict';
// Builds the single-file hosted (Claude artifact) edition: hosted/dist/job-hunter.html
// The browser uses the exact same normalize/scoring/scam engines as the local app.
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

const wrap = (file) => `(function(){const module={exports:{}};${read(file)}\nreturn module.exports;})()`;
const engine = `const ENGINE = { normalize: ${wrap('src/engine/normalize.js')}, scoring: ${wrap('src/engine/scoring.js')}, scam: ${wrap('src/engine/scam.js')} };`;

// The hosted page never embeds contact details: the viewer adds email/phone in Preferences if they want them in drafts.
const profile = JSON.parse(read('config/profile.json'));
profile.contact = { email: '', phone: '', linkedin: profile.contact?.linkedin || '' };
const profileJs = `const DEFAULT_PROFILE = ${JSON.stringify(profile).replace(/</g, '\\u003c')};`;

let css = read('public/styles.css');
css = css.replace(/--radius: 10px; color-scheme: light;/, '--radius: 10px; --scrim: rgba(10,12,16,.5); color-scheme: light;')
  .replace(/--shadow: none; color-scheme: dark;/g, '--shadow: none; --scrim: rgba(0,0,0,.6); color-scheme: dark;');
css += `
.tablewrap { overflow-x: auto; max-width: 100%; }
.main { padding-left: max(28px, env(safe-area-inset-left)); padding-right: max(28px, env(safe-area-inset-right)); }
@media (max-width: 760px) { .main { padding: 16px max(16px, env(safe-area-inset-right)) 60px max(16px, env(safe-area-inset-left)); } .sidebar { padding-left: max(12px, env(safe-area-inset-left)); padding-right: max(12px, env(safe-area-inset-right)); } .drawer { padding: 16px max(16px, env(safe-area-inset-right)) 60px max(16px, env(safe-area-inset-left)); } .kv { grid-template-columns: 1fr; } .notifs { right: 16px; } }
body { min-height: 100vh; overflow-x: hidden; }
`;

const app = read('hosted/hosted-app.js');
const html = `<title>AI Job Hunter</title>
<meta name="claude:viewport-fit-sides" content="cover">
<style>
${css}
</style>
<div id="app"><div class="empty">Loading your job hunter…</div></div>
<script>
${engine}
${profileJs}
${app.replace(/<\/script/gi, '<\\/script')}
</script>
`;
fs.mkdirSync(path.join(__dirname, 'dist'), { recursive: true });
fs.writeFileSync(path.join(__dirname, 'dist', 'job-hunter.html'), html);
console.log('wrote', html.length, 'bytes');
