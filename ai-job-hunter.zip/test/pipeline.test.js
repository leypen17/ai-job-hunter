'use strict';
const { mockFetch } = require('./helpers');
const test = require('node:test'); const assert = require('node:assert');
const f = require('./fixtures');

const routes = [
  [/remotive\.com\/api/, f.remotive], [/remoteok\.com\/api/, f.remoteok],
  [/weworkremotely\.com\/categories\/all-other/, f.wwrRss], [/weworkremotely\.com/, '<rss><channel></channel></rss>'],
  [/workingnomads/, f.empty], [/jobicy/, { jobs: [] }], [/himalayas/, { jobs: [] }],
];

test('full search run: ingest, dedupe, eliminate, score, scam-flag, draft (Mode 2, no AI key)', async () => {
  const calls = mockFetch(routes);
  const { runSearch } = require('../src/engine/pipeline');
  const { db, getJob } = require('../src/db');
  const r = await runSearch({ trigger: 'test' });
  assert.ok(calls.some((c) => /User-Agent/i.test(JSON.stringify(c.opts.headers))), 'sends a User-Agent');
  const jobs = db.prepare('SELECT * FROM jobs').all();
  const titles = jobs.map((j) => j.title);
  assert.ok(!titles.includes('Senior Backend Engineer (Go)'), 'irrelevant engineering job eliminated before storage');
  const dup = jobs.find((j) => j.source === 'remoteok' && /GoHighLevel/.test(j.title));
  assert.ok(dup.duplicate_of, 'cross-platform duplicate detected');
  assert.strictEqual(r.counters.duplicates, 1);
  const smm = jobs.find((j) => j.title === 'Social Media Manager');
  assert.strictEqual(smm.remote_eligibility, 'restricted'); assert.strictEqual(smm.status, 'Archived');
  const scam = jobs.find((j) => j.title === 'Data Entry Assistant');
  assert.strictEqual(scam.scam_risk, 'High');
  const ghl = getJob(jobs.find((j) => j.source === 'remotive' && /GoHighLevel/.test(j.title)).id);
  assert.ok(ghl.match_score >= 80, `ghl score ${ghl.match_score}`);
  assert.strictEqual(ghl.status, 'Awaiting Approval', 'Mode 2 drafts and waits for approval');
  assert.match(ghl.proposal, /OFFLINE DRAFT/); assert.strictEqual(ghl.date_applied, null, 'nothing submitted');
  const ea = jobs.find((j) => j.title === 'Executive Virtual Assistant');
  assert.strictEqual(ea.apply_email, 'hiring@quietcapital.example');
  assert.strictEqual(ea.remote_eligibility, 'worldwide', '"available for US hours" is not a location restriction');
  const n8n = jobs.find((j) => /n8n/.test(j.title));
  assert.strictEqual(n8n.company, 'Flowstate'); assert.strictEqual(n8n.remote_eligibility, 'worldwide');
  const notifs = db.prepare('SELECT kind FROM notifications').all().map((x) => x.kind);
  assert.ok(notifs.includes('scam') && notifs.includes('approval'));
  // second run: nothing new, Remotive respected its 6h minimum gap
  const r2 = await runSearch({ trigger: 'test' });
  assert.strictEqual(r2.newJobs, 0); assert.match(r2.sources.remotive.skipped, /6h/);
});

test('autonomous gate blocks anything not fully verified', () => {
  const { autonomousCheck, approvalReasons } = require('../src/engine/submit');
  const { db, getJob } = require('../src/db');
  const { saveSettings } = require('../src/config');
  const s = saveSettings({ mode: 'autonomous', autonomousArmed: true });
  const ghl = getJob(db.prepare("SELECT id FROM jobs WHERE source='remotive' AND title LIKE 'GoHigh%'").get().id);
  const g = autonomousCheck(ghl, s);
  assert.strictEqual(g.ok, false);
  assert.ok(g.blockers.some((b) => /Claude/.test(b)));
  assert.ok(g.blockers.some((b) => /email/.test(b)));
  assert.ok(approvalReasons({ description: 'Please complete a skills test and record a Loom video', application_questions: [] }).length >= 2);
  saveSettings({ mode: 'draft_approve', autonomousArmed: false });
});

test('follow-up schedule: day 3 check, day 5 draft once, day 14 inactive', async () => {
  const { db, getJob, updateJob } = require('../src/db');
  const { markApplied } = require('../src/engine/submit');
  const { processFollowUps, markFollowUpSent } = require('../src/engine/followups');
  const id = db.prepare("SELECT id FROM jobs WHERE title = 'Executive Virtual Assistant'").get().id;
  markApplied(id, 'manual');
  const back = (d) => updateJob(id, { date_applied: new Date(Date.now() - d * 86400e3).toISOString() });
  back(3.1); await processFollowUps(); assert.strictEqual(getJob(id).follow_up_stage, 'day5-draft');
  back(5.1); await processFollowUps(); let j = getJob(id);
  assert.strictEqual(j.status, 'Follow-Up Due'); assert.match(j.follow_up_draft, /Subject:/);
  markFollowUpSent(id); assert.strictEqual(getJob(id).status, 'Applied');
  await assert.rejects(require('../src/engine/followups').sendFollowUp(id, {}), /already sent/);
  back(14.1); await processFollowUps(); j = getJob(id);
  assert.strictEqual(j.follow_up_stage, 'inactive'); assert.match(j.notes, /Inactive/);
});

test('analytics only counts real records', async () => {
  const { overview, weeklyReport } = require('../src/engine/analytics');
  const o = overview();
  assert.strictEqual(o.applicationsSubmitted, 1); assert.strictEqual(o.interviews, 0); assert.strictEqual(o.successRate, 0);
  const w = await weeklyReport(new Date(), { withAI: false });
  assert.ok(w.jobsDiscovered >= 4); assert.strictEqual(w.allTime.applied, 1); // applied date was moved back 14 days above
  assert.ok(w.sampleNote);
});

test('manual import for assisted platforms dedupes', () => {
  const { importJob } = require('../src/engine/pipeline');
  const a = importJob({ url: 'https://www.onlinejobs.ph/jobseekers/job/123', title: 'GHL VA', company: 'PH Co', description: 'GoHighLevel VA for Filipino applicants, 40 hours per week, $1,500 per month' });
  assert.strictEqual(a.duplicate, false);
  const { getJob } = require('../src/db'); const j = getJob(a.id);
  assert.strictEqual(j.platform, 'onlinejobs.ph'); assert.strictEqual(j.remote_eligibility, 'philippines');
  assert.strictEqual(importJob({ url: 'https://www.onlinejobs.ph/jobseekers/job/123', title: 'GHL VA' }).duplicate, true);
});
