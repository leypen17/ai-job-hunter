'use strict';
require('./helpers');
const test = require('node:test'); const assert = require('node:assert');
const N = require('../src/engine/normalize'); const { ruleScore, classify, weighted } = require('../src/engine/scoring'); const { scamCheck } = require('../src/engine/scam');
const profile = JSON.parse(require('node:fs').readFileSync(process.env.PROFILE_PATH, 'utf8'));
const settings = require('../src/config').getSettings();

test('salary parsing and monthly USD normalization', () => {
  assert.deepStrictEqual(N.parseSalaryText('$1,800 - $2,200 / month'), { min: 1800, max: 2200, currency: 'USD', period: 'month' });
  assert.strictEqual(N.parseSalaryText('$10-12/hr').period, 'hour');
  assert.strictEqual(N.parseSalaryText('$60k - $80k').period, 'year');
  assert.strictEqual(N.parseSalaryText('Competitive'), null);
  const m = N.toMonthlyUSD({ min: 24000, max: 36000, currency: 'USD', period: 'year' });
  assert.strictEqual(m.minMonth, 2000); assert.strictEqual(m.maxMonth, 3000);
  const h = N.toMonthlyUSD({ min: 10, max: 12, currency: 'USD', period: 'hour' }, {}, 40);
  assert.strictEqual(h.minMonth, 1732);
  assert.strictEqual(N.toMonthlyUSD({ min: 60000, max: 60000, currency: 'PHP', period: 'month' }, { PHP: 0.017 }).minMonth, 1020);
});

test('remote eligibility detection', () => {
  assert.strictEqual(N.detectEligibility('Worldwide', '').eligibility, 'worldwide');
  assert.strictEqual(N.detectEligibility('Philippines', '').eligibility, 'philippines');
  assert.strictEqual(N.detectEligibility('USA Only', '').eligibility, 'restricted');
  assert.strictEqual(N.detectEligibility('Remote', 'Candidates must reside in the United States.').eligibility, 'restricted');
  assert.strictEqual(N.detectEligibility('Europe', '').eligibility, 'restricted');
  assert.strictEqual(N.detectEligibility('Anywhere', 'Must be available for US hours.').eligibility, 'worldwide');
  assert.strictEqual(N.detectEligibility('Remote', 'You must be based in the US.').eligibility, 'restricted');
  assert.strictEqual(N.detectEligibility('APAC', '').eligibility, 'asia');
  assert.strictEqual(N.detectEligibility('Hybrid - London', '').eligibility, 'not_remote');
  assert.strictEqual(N.detectEligibility('', 'Great team.').eligibility, 'unclear');
});

test('hours, types, emails, fingerprints', () => {
  assert.strictEqual(N.detectHours('Part-time 30 hours per week'), '30');
  assert.strictEqual(N.detectHours('30-40 hours/week'), '30-40');
  assert.match(N.detectEmploymentType('full_time', ''), /full-time/);
  assert.strictEqual(N.findApplyEmail('email jobs@acme.io or noreply@acme.io'), 'jobs@acme.io');
  assert.strictEqual(N.fingerprint('Brightpath Agency', 'GoHighLevel Automation Specialist (Remote)'), N.fingerprint('Brightpath Agency', 'GoHighLevel Automation Specialist'));
});

test('rule scoring follows spec weights and hard rules', () => {
  assert.strictEqual(weighted({ skills: 100, experience: 100, automation: 100, compensation: 100, remote: 100, hours: 100, longTerm: 100, growth: 100 }), 100);
  assert.strictEqual(weighted({ skills: 100, experience: 0, automation: 0, compensation: 0, remote: 0, hours: 0, longTerm: 0, growth: 0 }), 30);
  assert.strictEqual(classify(92), 'Excellent Match'); assert.strictEqual(classify(85), 'Strong Match'); assert.strictEqual(classify(59), 'Reject / Deprioritize');
  const f = require('./fixtures');
  const ghl = N.normalize({ ...f.remotive.jobs[0], source: 'remotive', platform: 'Remotive', company: 'Brightpath', location_text: 'Worldwide', salary_text: f.remotive.jobs[0].salary }, settings);
  const r = ruleScore(ghl, profile, settings);
  assert.ok(r.score >= 80, `GHL job should score 80+, got ${r.score}`);
  assert.strictEqual(r.category, 'GoHighLevel Specialist');
  const us = N.normalize({ title: 'Social Media Manager', company: 'X', url: 'u', location_text: 'USA Only', description: 'Instagram content' }, settings);
  assert.ok(ruleScore(us, profile, settings).score <= 45);
  const eng = N.normalize({ title: 'Senior Backend Engineer', company: 'X', url: 'u', location_text: 'Worldwide', description: 'Go, Kubernetes' }, settings);
  assert.ok(ruleScore(eng, profile, settings).score < 50);
});

test('scam detection', () => {
  const s = scamCheck({ title: 'Data Entry', company: '', description: 'Earn $900 per day! Contact us on Telegram. Pay a $50 registration fee for training.' });
  assert.strictEqual(s.risk, 'High'); assert.ok(s.flags.length >= 3);
  const ok = scamCheck({ title: 'Ops Manager', company: 'Acme', company_url: 'https://acme.io', description: 'x'.repeat(400) });
  assert.strictEqual(ok.risk, 'Low');
});

test('secrets are encrypted at rest', () => {
  const c = require('../src/config');
  const blob = c.encrypt('sk-ant-secret'); assert.ok(!blob.includes('sk-ant')); assert.strictEqual(c.decrypt(blob), 'sk-ant-secret');
});

test('region in title restricts eligibility', () => {
  const { normalize } = require('../src/engine/normalize');
  const a = normalize({ source: 't', source_id: '1', title: 'Business Development Rep, Enterprise, DACH', url: 'https://x.test/1', location_text: 'Anywhere in the World', description: 'Remote role.' }, {});
  assert.equal(a.remote_eligibility, 'restricted');
  const b = normalize({ source: 't', source_id: '2', title: 'Email Marketing Automation Specialist', url: 'https://x.test/2', location_text: 'Anywhere in the World', description: 'Remote role.' }, {});
  assert.equal(b.remote_eligibility, 'worldwide');
});
