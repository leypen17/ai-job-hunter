'use strict';
// Test-only setup: isolated temp DB/profile, and a fetch mock that serves fixture payloads.
// Fixtures are synthetic and never touch your real database.
const fs = require('node:fs'); const os = require('node:os'); const path = require('node:path');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'jh-test-'));
process.env.DATA_DIR = dir; process.env.DB_PATH = path.join(dir, 'test.db');
process.env.PROFILE_PATH = path.join(dir, 'profile.json');
fs.copyFileSync(path.join(__dirname, '..', 'config', 'profile.json'), process.env.PROFILE_PATH);
delete process.env.ANTHROPIC_API_KEY; delete process.env.SMTP_PASS;

function mockFetch(routes) {
  const calls = [];
  global.fetch = async (url, opts = {}) => {
    calls.push({ url: String(url), opts });
    for (const [re, handler] of routes) if (re.test(String(url))) {
      const body = typeof handler === 'function' ? handler(String(url), opts) : handler;
      const text = typeof body === 'string' ? body : JSON.stringify(body);
      return new Response(text, { status: 200, headers: { 'content-type': typeof body === 'string' ? 'text/xml' : 'application/json' } });
    }
    return new Response('not found', { status: 404 });
  };
  return calls;
}
module.exports = { dir, mockFetch };
