'use strict';
const daysAgo = (d) => new Date(Date.now() - d * 86400e3).toISOString();
const GHL_DESC = `<p>We are a fast-growing marketing agency looking for a GoHighLevel Automation Specialist to build and maintain client CRM pipelines, workflows and follow-up sequences.</p><ul><li>Build GHL funnels, pipelines and workflows</li><li>Connect tools with Zapier and webhooks</li><li>Write SOPs for the team</li><li>Manage email marketing in GHL and Mailchimp</li></ul><p>Full-time, 40 hours per week, long-term role with growth opportunities. Pay: $1,800 - $2,200 per month. Open to candidates worldwide; we have several team members in the Philippines. Please answer: What is your experience with GoHighLevel workflows?</p>`;
module.exports = {
  remotive: { jobs: [
    { id: 101, url: 'https://remotive.com/remote-jobs/marketing/ghl-101', title: 'GoHighLevel Automation Specialist', company_name: 'Brightpath Agency', category: 'Marketing', tags: ['gohighlevel', 'zapier'], job_type: 'full_time', publication_date: daysAgo(1), candidate_required_location: 'Worldwide', salary: '$1,800 - $2,200 / month', description: GHL_DESC },
    { id: 102, url: 'https://remotive.com/remote-jobs/software-dev/eng-102', title: 'Senior Backend Engineer (Go)', company_name: 'Infra Co', category: 'Software Development', tags: ['go'], job_type: 'full_time', publication_date: daysAgo(2), candidate_required_location: 'USA', salary: '$180k', description: '<p>Build distributed systems in Go. 8+ years required.</p>' },
    { id: 103, url: 'https://remotive.com/remote-jobs/marketing/smm-103', title: 'Social Media Manager', company_name: 'Northwind Health', category: 'Marketing', tags: [], job_type: 'full_time', publication_date: daysAgo(3), candidate_required_location: 'USA Only', salary: '', description: '<p>Manage Instagram, TikTok and Facebook content calendars using Canva. Must reside in the US.</p>' },
  ] },
  remoteok: [
    { legal: 'API terms' },
    { id: 'ro-9', epoch: Math.floor(Date.now() / 1000) - 3600, position: 'GoHighLevel Automation Specialist (Remote)', company: 'Brightpath Agency', tags: ['crm'], description: GHL_DESC, location: 'Worldwide', salary_min: 21600, salary_max: 26400, apply_url: 'https://brightpath.example/apply', url: 'https://remoteok.com/remote-jobs/ro-9' },
    { id: 'ro-10', epoch: Math.floor(Date.now() / 1000) - 7200, position: 'Executive Virtual Assistant', company: 'Quiet Capital', tags: ['assistant'], description: '<p>Support our CEO with calendar management, email management, research and documentation in Google Workspace and ClickUp. Part-time 30 hours per week. Must be available for US hours. Apply by emailing hiring@quietcapital.example with a short note.</p>', location: 'Anywhere', salary_min: 0, salary_max: 0, url: 'https://remoteok.com/remote-jobs/ro-10' },
    { id: 'ro-11', epoch: Math.floor(Date.now() / 1000) - 7200, position: 'Data Entry Assistant', company: '', tags: [], description: '<p>Earn $900 per day! No experience needed. Contact us on Telegram. Pay a $50 registration fee for training.</p>', location: 'Worldwide', url: 'https://remoteok.com/remote-jobs/ro-11' },
  ],
  wwrRss: `<?xml version="1.0"?><rss version="2.0"><channel><title>WWR</title>
    <item><title>Flowstate: n8n &amp; AI Workflow Builder</title><region>Anywhere in the World</region><category>All Other Remote</category><type>Contract</type><pubDate>${new Date(Date.now() - 86400e3).toUTCString()}</pubDate><guid>https://weworkremotely.com/remote-jobs/flowstate-n8n</guid><link>https://weworkremotely.com/remote-jobs/flowstate-n8n</link><description>&lt;p&gt;Design n8n and Zapier automations, connect APIs with webhooks, and build AI-assisted workflows using Claude and OpenAI for our SaaS customers. Long-term contract, 30-40 hours per week, flexible hours.&lt;/p&gt;</description></item>
  </channel></rss>`,
  empty: [],
};
