'use strict';
// Verifies the Claude integration end to end against a stubbed Messages API endpoint:
// request shape (model, structured output schema, fallbacks), parsing, and how results are stored.
const { mockFetch } = require('./helpers');
const test = require('node:test'); const assert = require('node:assert');
const f = require('./fixtures');

const analysis = { criteria: { skills: 95, experience: 90, automation: 90, compensation: 95, remote: 100, hours: 100, longTerm: 90, growth: 80 }, category: 'GoHighLevel Specialist', summary: 'Strong GHL fit.', whyMatch: 'GHL pipelines and workflows are core to the profile.', relevantSkills: ['GoHighLevel', 'Zapier'], missingQualifications: [], compensationFit: '$1,800-$2,200/mo fits', remote: { genuinelyRemote: true, philippinesEligible: 'yes', explanation: 'Worldwide, PH team members' }, worthApplying: { verdict: 'apply', reason: 'Core skills' }, interviewLikelihood: { level: 'high', reason: 'Direct match' }, scam: { risk: 'Low', flags: [] }, painPoints: ['Client CRM upkeep'], applicationQuestions: ['What is your experience with GoHighLevel workflows?'], requiredSkills: ['gohighlevel', 'zapier'] };
const proposal = { style: 'short', proposal: 'Keeping client pipelines clean while follow-ups run on time is the job...', wordCount: 160, rateSuggestion: '', answers: [{ question: 'What is your experience with GoHighLevel workflows?', answer: 'I build GHL funnels, pipelines and workflows...', needsInput: false, note: '' }], needsUserInput: [], factsUsed: ['GoHighLevel'] };
const bodies = [];
const reply = (obj) => ({ id: 'msg_1', type: 'message', role: 'assistant', model: 'claude-opus-5-5', content: [{ type: 'text', text: JSON.stringify(obj) }], stop_reason: 'end_turn', usage: { input_tokens: 10, output_tokens: 10 } });

test('Claude analysis + proposal flow with approval gate', async () => {
  mockFetch([
    [/api\.anthropic\.com\/v1\/messages/, (url, opts) => { const b = JSON.parse(opts.body); bodies.push(b); const sys = JSON.stringify(b.system);
      if (sys.includes('matching analyst')) return reply(analysis);
      if (sys.includes('Summarize what is known')) return reply({ overview: 'Marketing agency', products: 'Not stated', businessModel: 'Not stated', industry: 'Marketing', size: 'Not stated', mission: 'Not stated', hiringManager: 'Not stated', recentDevelopments: 'Not stated', likelyChallenges: [], howCandidateHelps: [], confidence: 'low' });
      return reply(proposal); }],
    [/remotive\.com\/api/, f.remotive], [/./, []],
  ]);
  require('../src/config').setSecret('anthropicApiKey', 'sk-ant-test');
  const { saveSettings } = require('../src/config'); saveSettings({ sources: { remoteok: false, wwr: false, workingnomads: false, jobicy: false, himalayas: false } });
  const { runSearch } = require('../src/engine/pipeline'); const { db, getJob } = require('../src/db');
  await runSearch({ trigger: 'test' });
  const id = db.prepare("SELECT id FROM jobs WHERE title LIKE 'GoHigh%'").get().id; const j = getJob(id);
  assert.strictEqual(j.scored_by, 'claude'); assert.strictEqual(j.match_score, 93);
  assert.strictEqual(j.status, 'Awaiting Approval'); assert.ok(j.proposal.startsWith('Keeping client'));
  assert.strictEqual(j.application_questions[0].needsInput, false); assert.strictEqual(j.date_applied, null);
  assert.strictEqual(j.match_explanation.interviewLikelihood.disclaimer, 'AI estimate, not a factual prediction.');
  const b = bodies[0];
  assert.strictEqual(b.model, 'claude-opus-5-5'); assert.strictEqual(b.output_config.format.type, 'json_schema'); assert.strictEqual(b.fallbacks, 'default'); assert.deepStrictEqual(b.thinking, { type: 'adaptive' });
  assert.match(JSON.stringify(b.system), /Never invent/);
  // Approval required to send; no SMTP so autonomous can't send either
  const { autonomousCheck } = require('../src/engine/submit');
  assert.ok(autonomousCheck(j).blockers.some((x) => /Mode 3 is not selected/.test(x)));
});
