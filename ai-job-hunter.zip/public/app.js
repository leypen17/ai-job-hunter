/* AI Job Hunter - single-page dashboard (no build step). */
'use strict';
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtDate = (d) => (d ? new Date(d.includes('T') || d.includes('Z') ? d : d.replace(' ', 'T') + 'Z').toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '—');
const ago = (d) => { if (!d) return '—'; const t = new Date(d.includes('T') ? d : d.replace(' ', 'T') + 'Z'); const days = Math.floor((Date.now() - t) / 86400e3); return days <= 0 ? 'today' : days === 1 ? '1 day ago' : `${days} days ago`; };
const money = (j) => j.salary_max_month ? `$${Math.round(j.salary_min_month || j.salary_max_month).toLocaleString()}${j.salary_max_month !== j.salary_min_month ? `–$${Math.round(j.salary_max_month).toLocaleString()}` : ''}/mo` : (j.salary_text || 'Salary not stated');
const ELIG = { philippines: ['ok', 'Philippines OK'], worldwide: ['ok', 'Worldwide'], asia: ['ok', 'Asia/APAC'], unclear: ['warn', 'Eligibility unclear'], restricted: ['bad', 'Restricted'], not_remote: ['bad', 'Not remote'] };
const eligBadge = (e, r) => { const [c, l] = ELIG[e] || ['', e || '?']; return `<span class="badge ${c}" title="${esc(r || '')}">${l}</span>`; };
const scamBadge = (r) => (r === 'High' ? '<span class="badge bad">Scam risk: High</span>' : r === 'Moderate' ? '<span class="badge warn">Scam risk: Moderate</span>' : r ? '<span class="badge">Scam risk: Low</span>' : '');
const scoreCls = (s) => (s >= 90 ? 's90' : s >= 80 ? 's80' : s >= 70 ? 's70' : s >= 60 ? 's60' : '');
const STATUS_CLS = { Applied: 'info', Interview: 'ok', Offer: 'ok', Assessment: 'info', 'Awaiting Approval': 'warn', 'Follow-Up Due': 'warn', Rejected: 'bad', Archived: '', Qualified: 'ok', 'Proposal Generated': 'info' };

const state = { overview: null, settings: null, notifs: { unread: 0, items: [] }, statuses: [] };

async function api(path, opts = {}) {
  const res = await fetch(`/api${path}`, { method: opts.method || 'GET', headers: opts.body ? { 'Content-Type': 'application/json' } : {}, body: opts.body ? JSON.stringify(opts.body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && !path.startsWith('/auth')) { renderAuth(); throw new Error('Please log in'); }
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}
function toast(msg, err) { const t = document.createElement('div'); t.className = `toast${err ? ' err' : ''}`; t.textContent = msg; document.body.append(t); setTimeout(() => t.remove(), err ? 6000 : 3000); }
async function busy(btn, fn) {
  const old = btn?.innerHTML; if (btn) { btn.disabled = true; btn.innerHTML = `<span class="spinner"></span> ${old}`; }
  try { return await fn(); } catch (e) { toast(e.message, true); throw e; } finally { if (btn) { btn.disabled = false; btn.innerHTML = old; } }
}

// ---------------- auth ----------------
async function renderAuth() {
  const s = await api('/auth/status');
  if (s.loggedIn) return boot();
  $('#app').innerHTML = `<div class="overlay" style="background:var(--bg)"><form class="modal" id="authf" style="width:min(380px,100%)">
    <div class="logo"><span>JH</span> AI Job Hunter</div>
    <h2>${s.setup ? 'Log in' : 'Create your password'}</h2>
    ${s.setup ? '' : '<p class="muted small">First run: choose a password to protect your dashboard (min 8 characters).</p>'}
    <div class="field"><label>Password</label><input type="password" name="password" autocomplete="${s.setup ? 'current-password' : 'new-password'}" required minlength="8" autofocus></div>
    <button class="primary" style="width:100%;justify-content:center">${s.setup ? 'Log in' : 'Create & continue'}</button></form></div>`;
  $('#authf').onsubmit = async (e) => { e.preventDefault(); try { await api(s.setup ? '/auth/login' : '/auth/setup', { method: 'POST', body: { password: e.target.password.value } }); boot(); } catch (err) { toast(err.message, true); } };
}

// ---------------- shell ----------------
const NAV = [['dashboard', 'Dashboard'], ['search', 'Job Search'], ['top', 'Top Matches'], ['applications', 'Applications'], ['proposal', 'Proposal Generator'], ['interviews', 'Interviews'], ['analytics', 'Analytics'], ['settings', 'Settings']];
async function boot() {
  $('#app').innerHTML = `<div class="layout"><aside class="sidebar"><div class="logo"><span>JH</span> AI Job Hunter</div><nav class="nav" id="nav"></nav>
    <div class="small muted" style="padding:16px 10px" id="modeBox"></div></aside>
    <main class="main"><div class="topbar"><div id="pageTitle"></div><div class="right">
      <button id="runBtn" class="primary">Search now</button>
      <button class="bell" id="bellBtn" title="Notifications">🔔<span class="dot" id="bellDot" hidden></span></button>
      <button id="logoutBtn" class="sm">Log out</button></div></div>
      <div id="notifPanel" class="card notifs" hidden></div><div id="view"></div></main></div><div id="drawerHost"></div>`;
  $('#runBtn').onclick = (e) => busy(e.currentTarget, async () => { const r = await api('/search/run', { method: 'POST', body: {} }); toast(r.alreadyRunning ? 'A search is already running' : 'Search started. Results appear as sources respond.'); pollRun(); });
  $('#logoutBtn').onclick = async () => { await api('/auth/logout', { method: 'POST', body: {} }); renderAuth(); };
  $('#bellBtn').onclick = toggleNotifs;
  window.onhashchange = route;
  await refreshShell();
  api('/settings').then((x) => { state.settings = x; }).catch(() => {});
  route();
  setInterval(refreshShell, 60000);
}
async function refreshShell() {
  try {
    const [o, n] = await Promise.all([api('/overview'), api('/notifications')]);
    state.overview = o; state.notifs = n;
    const counts = Object.fromEntries(o.pipeline.map((p) => [p.status, p.n]));
    const navCount = { top: o.stats.excellent + o.stats.strong, applications: o.stats.awaitingApproval || '', interviews: (counts.Interview || 0) + (counts.Assessment || 0) + (counts.Offer || 0) || '' };
    const cur = (location.hash.slice(2) || 'dashboard').split('/')[0];
    $('#nav').innerHTML = NAV.map(([k, l]) => `<a href="#/${k}" class="${cur === k ? 'active' : ''}">${l}${navCount[k] ? `<span class="count">${navCount[k]}</span>` : ''}</a>`).join('');
    const modeName = { search_only: 'Mode 1 · Search only', draft_approve: 'Mode 2 · Draft & approve', autonomous: 'Mode 3 · Autonomous' }[o.mode];
    $('#modeBox').innerHTML = `<div><b>${modeName}</b></div><div>Claude: ${o.aiAvailable ? '<span class="badge ok">ready</span>' : '<span class="badge warn">no key</span>'}</div><div style="margin-top:4px">Email: ${o.smtpReady ? '<span class="badge ok">ready</span>' : '<span class="badge">off</span>'}</div>${o.running ? '<div style="margin-top:6px"><span class="spinner"></span> searching…</div>' : ''}`;
    $('#bellDot').hidden = !n.unread; $('#bellDot').textContent = n.unread;
  } catch { /* shown elsewhere */ }
}
let pollTimer;
function pollRun() { clearInterval(pollTimer); pollTimer = setInterval(async () => { await refreshShell(); if (!state.overview.running) { clearInterval(pollTimer); toast('Search finished'); route(); } }, 4000); }
function toggleNotifs() {
  const p = $('#notifPanel'); p.hidden = !p.hidden; if (p.hidden) return;
  const n = state.notifs;
  p.innerHTML = `<div class="row" style="justify-content:space-between"><h2 style="margin:0">Notifications</h2><button class="sm" id="readAll">Mark all read</button></div>
    ${n.items.length ? n.items.map((x) => `<div class="notif ${x.read ? '' : 'unread'}"><b>${esc(x.title)}</b><div class="muted small">${esc(x.body || '')}</div><div class="small muted">${ago(x.created_at)} ${x.job_id ? `· <a href="#/job/${x.job_id}">open job</a>` : ''}</div></div>`).join('') : '<div class="empty">No notifications yet.</div>'}`;
  $('#readAll').onclick = async () => { await api('/notifications/read', { method: 'POST', body: {} }); p.hidden = true; refreshShell(); };
}

let routeTok = 0;
function route() {
  routeTok++;
  const [page, arg] = (location.hash.slice(2) || 'dashboard').split('/');
  $('#notifPanel').hidden = true;
  if (page === 'job') { openJob(+arg); if (!$('#view').innerHTML) views.dashboard(); return; }
  closeDrawer(false);
  $$('#nav a').forEach((a) => a.classList.toggle('active', a.getAttribute('href') === `#/${page}`));
  (views[page] || views.dashboard)();
}
const setTitle = (t, sub = '') => { $('#pageTitle').innerHTML = `<h1>${esc(t)}</h1>${sub ? `<div class="muted small">${sub}</div>` : ''}`; };

// ---------------- job card ----------------
function jobCard(j) {
  return `<div class="card job" data-id="${j.id}">
    <div class="score ${scoreCls(j.match_score)}" title="${esc(j.classification)} (${j.scored_by === 'claude' ? 'Claude' : 'rules'})">${j.match_score ?? '–'}</div>
    <div><div class="title"><a href="#/job/${j.id}">${esc(j.title)}</a></div>
      <div class="meta"><span>${esc(j.company || 'Unknown company')}</span><span>${esc(j.platform)}</span><span>${esc(money(j))}</span><span>Posted ${ago(j.date_posted || j.date_discovered)}</span>${j.category ? `<span>${esc(j.category)}</span>` : ''}</div>
      <div class="row" style="margin-top:6px;gap:6px">${eligBadge(j.remote_eligibility, j.location_restrictions)}<span class="badge ${STATUS_CLS[j.status] || ''}">${esc(j.status)}</span>${scamBadge(j.scam_risk !== 'Low' ? j.scam_risk : '')}${j.scored_by === 'claude' ? '<span class="badge info">Claude</span>' : '<span class="badge" title="Rules-based score. Analyze for a Claude score.">rules</span>'}${j.saved ? '<span class="badge info">★ Saved</span>' : ''}${j.employment_type ? `<span class="badge">${esc(j.employment_type)}</span>` : ''}</div>
      <div class="actions">
        <a class="btn sm" href="${esc(j.url)}" target="_blank" rel="noopener">View job ↗</a>
        <button class="sm" data-act="analyze">Analyze</button>
        <button class="sm" data-act="proposal">${j.has_proposal ? 'Regenerate' : 'Generate'} proposal</button>
        ${j.has_proposal ? '<button class="sm" data-act="edit">Edit proposal</button><button class="sm ok" data-act="approve">Approve</button>' : ''}
        ${j.status === 'Awaiting Approval' ? '<button class="sm" data-act="edit">Apply…</button>' : ''}
        ${j.date_applied ? '' : '<button class="sm" data-act="applied">Mark as applied</button>'}
        <button class="sm" data-act="save">${j.saved ? 'Unsave' : 'Save'}</button>
        ${j.status !== 'Archived' ? '<button class="sm danger" data-act="reject">Reject</button>' : ''}
      </div></div>
    <div class="side small muted" style="text-align:right">${esc(j.classification)}</div></div>`;
}
function bindCards(root, reload) {
  root.onclick = async (e) => {
    const b = e.target.closest('button[data-act]'); if (!b) return;
    const id = +b.closest('[data-id]').dataset.id; const act = b.dataset.act;
    const run = (fn) => busy(b, fn).then(reload).catch(() => {});
    if (act === 'analyze') run(async () => { await api(`/jobs/${id}/analyze`, { method: 'POST', body: {} }); toast('Analyzed by Claude'); });
    if (act === 'proposal') run(async () => { await api(`/jobs/${id}/proposal`, { method: 'POST', body: {} }); toast('Proposal ready for review'); location.hash = `#/job/${id}`; });
    if (act === 'edit') location.hash = `#/job/${id}`;
    if (act === 'approve') run(async () => { await api(`/jobs/${id}/approve`, { method: 'POST', body: {} }); toast('Approved. Open the job to send or apply.'); location.hash = `#/job/${id}`; });
    if (act === 'applied') { if (confirm('Mark as applied? Only do this if you actually submitted the application.')) run(() => api(`/jobs/${id}/mark-applied`, { method: 'POST', body: {} })); }
    if (act === 'save') run(async () => { const j = await api(`/jobs/${id}`); await api(`/jobs/${id}`, { method: 'PATCH', body: { saved: !j.saved } }); });
    if (act === 'reject') run(() => api(`/jobs/${id}/reject`, { method: 'POST', body: {} }));
  };
}
async function jobList(container, params, { empty = 'No jobs match.' } = {}) {
  const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v != null && v !== false)).toString();
  const r = await api(`/jobs?${qs}`);
  container.innerHTML = r.jobs.length ? `<div class="muted small" style="margin-bottom:8px">${r.total} job${r.total === 1 ? '' : 's'}</div><div class="jobs">${r.jobs.map(jobCard).join('')}</div>${r.total > r.jobs.length + (+params.offset || 0) ? '<div style="text-align:center;margin-top:12px"><button id="moreBtn">Load more</button></div>' : ''}` : `<div class="card empty">${empty}</div>`;
  bindCards(container, () => jobList(container, params, { empty }));
  const more = $('#moreBtn', container);
  if (more) more.onclick = async () => { const p = { ...params, offset: (+params.offset || 0) + 50 }; const r2 = await api(`/jobs?${new URLSearchParams(p)}`); more.parentElement.insertAdjacentHTML('beforebegin', r2.jobs.map(jobCard).join('')); more.parentElement.remove(); };
}

// ---------------- views ----------------
const views = {};
views.dashboard = async () => {
  const tok = routeTok;
  setTitle('Dashboard', 'Your job hunt at a glance. Every number is counted from your own data.');
  const o = state.overview || await api('/overview'); const s = o.stats;
  const stat = (v, l) => `<div class="card stat"><div class="v">${v ?? '—'}</div><div class="l">${l}</div></div>`;
  const warns = [];
  if (!o.aiAvailable) warns.push('<div class="notice">Claude is not connected, so jobs get rules-based scores and offline drafts only. <a href="#/settings">Add your Anthropic API key</a>.</div>');
  if (!o.runs.length) warns.push('<div class="notice info">No searches yet. Press <b>Search now</b> to pull live jobs from Remotive, Remote OK, We Work Remotely, Working Nomads, Jobicy and Himalayas.</div>');
  if (tok !== routeTok) return;
  $('#view').innerHTML = `${warns.join('')}
    <div class="grid stats">${stat(s.jobsFoundToday, 'Jobs found today')}${stat(s.totalAnalyzed, 'Total jobs analyzed')}${stat(s.excellent, 'Excellent matches (90+)')}${stat(s.strong, 'Strong matches (80–89)')}${stat(s.applicationsSubmitted, 'Applications submitted')}${stat(s.awaitingApproval, 'Awaiting approval')}${stat(s.interviews, 'Interviews')}${stat(s.rejections, 'Rejections')}${stat(s.pendingResponses, 'Pending responses')}${stat(s.successRate == null ? '—' : `${s.successRate}%`, 'Application success rate (interviews ÷ applied)')}</div>
    <div class="grid two" style="margin-top:14px">
      <div class="card"><h2>Top matches right now</h2><div id="dashTop"></div></div>
      <div class="card"><h2>Recent searches</h2>${o.runs.length ? `<table><tr><th>When</th><th>Found</th><th>New</th><th>Qualified</th><th>Sources</th></tr>${o.runs.map((r) => `<tr><td>${ago(r.started_at)}<div class="small muted">${esc(r.trigger)}</div></td><td>${r.found}</td><td>${r.new_jobs}</td><td>${r.qualified}</td><td class="small">${r.error ? `<span class="badge bad">${esc(r.error)}</span>` : Object.entries(r.source_report?.sources || {}).map(([k, v]) => `<span title="${esc(v.error || v.skipped || '')}" class="badge ${v.error ? 'bad' : v.skipped ? '' : 'ok'}">${esc(k)}${v.fetched != null ? ` ${v.fetched}` : ''}</span>`).join(' ')}</td></tr>`).join('')}</table>` : '<div class="empty">No searches yet.</div>'}
      <h3>Pipeline</h3><div class="row">${o.pipeline.map((p) => `<span class="badge ${STATUS_CLS[p.status] || ''}">${esc(p.status)}: ${p.n}</span>`).join('') || '<span class="muted">Empty</span>'}</div></div></div>`;
  const top = $('#dashTop');
  const r = await api('/jobs?minScore=80&limit=6&status=New,Qualified,Proposal Generated,Awaiting Approval');
  top.innerHTML = r.jobs.length ? r.jobs.map((j) => `<div class="row" style="justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border)"><div><a href="#/job/${j.id}"><b>${esc(j.title)}</b></a><div class="small muted">${esc(j.company || '')} · ${esc(j.platform)} · ${esc(money(j))}</div></div><div class="score ${scoreCls(j.match_score)}" style="width:40px;height:40px;font-size:15px">${j.match_score}</div></div>`).join('') : '<div class="empty">No 80+ matches yet.</div>';
};

views.search = async () => {
  const tok = routeTok;
  setTitle('Job Search', 'Live postings from official APIs and feeds, plus jobs you import from other sites.');
  const plats = await api('/platforms');
  if (tok !== routeTok) return;
  $('#view').innerHTML = `<div class="card"><form id="ff" class="filters">
    <div><label>Keywords</label><input name="q" placeholder="e.g. GoHighLevel, n8n"></div>
    <div><label>Min score</label><select name="minScore"><option value="">Any</option><option>90</option><option selected>60</option><option>70</option><option>80</option></select></div>
    <div><label>Platform</label><select name="platform"><option value="">All</option>${plats.map((p) => `<option>${esc(p.platform)}</option>`).join('')}</select></div>
    <div><label>Remote eligibility</label><select name="eligibility"><option value="">Any</option><option value="philippines,worldwide,asia" selected>Philippines eligible</option><option value="unclear">Unclear</option><option value="restricted,not_remote">Restricted / not remote</option></select></div>
    <div><label>Employment type</label><select name="type"><option value="">Any</option><option>full-time</option><option>part-time</option><option>contract</option><option>freelance</option></select></div>
    <div><label>Min salary ($/mo)</label><input name="minSalary" type="number" placeholder="1500"></div>
    <div><label>Hours</label><select name="hours"><option value="">Any</option><option value="30-40">30–40 h/week</option></select></div>
    <div><label>Experience level</label><select name="level"><option value="">Any</option><option>junior</option><option>mid</option><option>senior</option><option>manager</option></select></div>
    <div><label>Posted within</label><select name="maxAgeDays"><option value="">Any</option><option value="1">24 hours</option><option value="3">3 days</option><option value="7" selected>7 days</option><option value="14">14 days</option></select></div>
    <div><label>Scam risk</label><select name="scam"><option value="">Any</option><option>Low</option><option>Moderate</option><option>High</option></select></div>
    <div><label>Sort</label><select name="sort"><option value="score">Best match</option><option value="newest">Newest</option></select></div>
    <div><label class="check"><input type="checkbox" name="salaryKnown" value="1"> Salary stated</label><label class="check"><input type="checkbox" name="includeArchived" value="1"> Include archived</label><label class="check"><input type="checkbox" name="saved" value="1"> Saved only</label></div>
    </form><div class="row" style="margin-top:12px"><button class="primary" form="ff">Apply filters</button><button id="impBtn">+ Import job from another site</button><button id="assBtn">LinkedIn, Indeed, Upwork & other sites</button><button id="rescoreBtn" title="Re-run rules scoring after editing your profile">Re-score</button></div></div>
    <div id="assisted"></div><div id="results" style="margin-top:14px"></div>`;
  const load = () => { const fd = Object.fromEntries(new FormData($('#ff'))); jobList($('#results'), { ...fd, limit: 50 }); };
  $('#ff').onsubmit = (e) => { e.preventDefault(); load(); };
  $('#impBtn').onclick = importModal;
  $('#assBtn').onclick = assistedPanel;
  $('#rescoreBtn').onclick = (e) => busy(e.currentTarget, async () => { const r = await api('/rescore', { method: 'POST', body: {} }); toast(`Re-scored ${r.rescored} jobs`); load(); });
  load();
};
async function assistedPanel() {
  const host = $('#assisted'); if (host.innerHTML) { host.innerHTML = ''; return; }
  const list = await api('/assisted-links');
  host.innerHTML = `<div class="card" style="margin-top:14px"><h2>Assisted search</h2><p class="muted small">These sites don't allow automated searching or applying for individual job seekers, so the app gives you ready-made searches. Open them, and use <b>Import job</b> for anything interesting: it gets scored, scam-checked and a tailored proposal like every other job.</p>
    <div class="grid three">${list.map((p) => `<div><b>${esc(p.name)}</b><div class="small muted">${esc(p.why)}</div><div class="small" style="margin-top:4px">${p.links.map((l) => `<a href="${esc(l.url)}" target="_blank" rel="noopener">${esc(l.keyword)}</a>`).join(' · ')}</div></div>`).join('')}</div></div>`;
}
function modal(html, onMount) {
  const o = document.createElement('div'); o.className = 'overlay'; o.innerHTML = `<div class="modal">${html}</div>`;
  o.onclick = (e) => { if (e.target === o) o.remove(); }; document.body.append(o); onMount?.(o); return o;
}
function importModal() {
  modal(`<h2>Import a job</h2><p class="muted small">Paste a posting from LinkedIn, Indeed, Upwork, OnlineJobs.ph or any site. The full description gives the best match and proposal.</p>
    <form id="impf"><div class="field"><label>Job URL *</label><input name="url" required type="url"></div>
    <div class="grid two"><div class="field"><label>Job title *</label><input name="title" required></div><div class="field"><label>Company</label><input name="company"></div></div>
    <div class="grid two"><div class="field"><label>Platform</label><input name="platform" placeholder="LinkedIn, Upwork, OnlineJobs.ph…"></div><div class="field"><label>Location / eligibility text</label><input name="location_text" placeholder="e.g. Remote - Worldwide"></div></div>
    <div class="grid two"><div class="field"><label>Salary / rate text</label><input name="salary_text" placeholder="$1,800/month or $12/hr"></div><div class="field"><label>Employment type</label><input name="employment_type" placeholder="full-time, contract…"></div></div>
    <div class="field"><label>Full job description</label><textarea name="description" style="min-height:200px"></textarea></div>
    <div class="row"><button class="primary">Import & score</button><label class="check"><input type="checkbox" name="analyze" checked> Analyze with Claude right away</label></div></form>`, (o) => {
    $('#impf', o).onsubmit = async (e) => {
      e.preventDefault(); const fd = Object.fromEntries(new FormData(e.target)); const btn = $('button.primary', o);
      await busy(btn, async () => {
        const r = await api('/import', { method: 'POST', body: fd });
        if (r.duplicate) toast('Already in your database: opening it');
        else if (fd.analyze && state.overview?.aiAvailable) await api(`/jobs/${r.id}/analyze`, { method: 'POST', body: {} }).catch((err) => toast(err.message, true));
        o.remove(); location.hash = `#/job/${r.id}`;
      }).catch(() => {});
    };
  });
}

views.top = async () => {
  const tok = routeTok;
  setTitle('Top Matches', 'Score 80+ and open to applicants from the Philippines. Only these are considered for automatic proposals.');
  if (tok !== routeTok) return;
  $('#view').innerHTML = '<div id="results"></div>';
  jobList($('#results'), { minScore: 80, eligibility: 'philippines,worldwide,asia,unclear', status: 'New,Qualified,Proposal Generated,Awaiting Approval', sort: 'score', limit: 50 }, { empty: 'No 80+ matches yet. Run a search, add your API key for Claude scoring, or import jobs.' });
};

views.applications = async () => {
  const tok = routeTok;
  setTitle('Applications', 'Your pipeline. Click a card to open it; change status from the job page.');
  const cols = ['Qualified', 'Proposal Generated', 'Awaiting Approval', 'Applied', 'Follow-Up Due', 'Interview', 'Assessment', 'Offer', 'Rejected'];
  const r = await api(`/jobs?status=${encodeURIComponent(cols.join(','))}&limit=500&sort=score`);
  const by = Object.fromEntries(cols.map((c) => [c, []])); for (const j of r.jobs) by[j.status]?.push(j);
  if (tok !== routeTok) return;
  $('#view').innerHTML = `<div class="row" style="margin-bottom:10px"><a class="btn sm" href="/api/export.csv">Export CSV</a><button class="sm" id="fuBtn">Check follow-ups now</button></div><div class="kanban">${cols.map((c) => `<div class="col"><h3>${c}<span class="count badge">${by[c].length}</span></h3>${by[c].map((j) => `<div class="mini" onclick="location.hash='#/job/${j.id}'"><b>${esc(j.title)}</b>${esc(j.company || '')}<div class="row" style="gap:4px;margin-top:4px"><span class="badge ${scoreCls(j.match_score) ? 'info' : ''}">${j.match_score ?? '–'}</span>${j.date_applied ? `<span class="small muted">applied ${ago(j.date_applied)}</span>` : ''}${j.follow_up_date && ['Applied', 'Follow-Up Due'].includes(j.status) ? `<span class="small muted">· follow-up ${fmtDate(j.follow_up_date)}</span>` : ''}</div></div>`).join('') || '<div class="small muted">—</div>'}</div>`).join('')}</div>`;
  $('#fuBtn').onclick = (e) => busy(e.currentTarget, async () => { const r2 = await api('/followups/run', { method: 'POST', body: {} }); toast(`Checked ${r2.checked ?? 0}: ${r2.drafted ?? 0} follow-ups drafted, ${r2.inactive ?? 0} marked inactive`); views.applications(); });
};

views.interviews = async () => {
  const tok = routeTok;
  setTitle('Interviews', 'Interviews, assessments and offers. Move a job here from its page when an employer responds.');
  if (tok !== routeTok) return;
  $('#view').innerHTML = '<div id="results"></div>';
  jobList($('#results'), { status: 'Interview,Assessment,Offer', sort: 'applied' }, { empty: 'No interviews yet. When an employer replies, open the job and set its status to Interview.' });
};

views.proposal = async () => {
  const tok = routeTok;
  setTitle('Proposal Generator', 'Pick a job (or paste a new one) and Claude writes a tailored application from your real profile only.');
  const r = await api('/jobs?minScore=0&status=New,Qualified,Proposal Generated,Awaiting Approval&limit=200&sort=score');
  if (tok !== routeTok) return;
  $('#view').innerHTML = `<div class="grid two"><div class="card"><h2>1. Choose the job</h2>
    <div class="field"><label>From your database</label><select id="pgJob"><option value="">Select a job…</option>${r.jobs.map((j) => `<option value="${j.id}">${j.match_score ?? '–'} · ${esc(j.title)} — ${esc(j.company || '')}</option>`).join('')}</select></div>
    <div class="small muted" style="margin-bottom:12px">or <a href="#" id="pgImport">paste a new job posting</a></div>
    <h2>2. Format</h2><div class="field"><select id="pgFmt"><option value="auto">Auto (based on posting)</option><option value="short">Short application (100–200 words)</option><option value="detailed">Detailed application (200–350 words)</option><option value="linkedin">LinkedIn message (50–120 words)</option><option value="cover">Cover letter</option><option value="upwork">Upwork proposal</option></select></div>
    <h2>3. Application questions (one per line)</h2><div class="field"><textarea id="pgQs" placeholder="Tell us about yourself&#10;Describe your experience with automation&#10;What is your hourly rate?"></textarea></div>
    <div class="field"><label>Extra instructions (optional)</label><input id="pgIns" placeholder="e.g. mention I can start next week"></div>
    <button class="primary" id="pgGo">Generate</button></div>
    <div class="card"><h2>Result</h2><div id="pgOut" class="muted">The proposal and answers appear here, and are saved on the job.</div></div></div>`;
  $('#pgImport').onclick = (e) => { e.preventDefault(); importModal(); };
  $('#pgGo').onclick = (e) => busy(e.currentTarget, async () => {
    const id = $('#pgJob').value; if (!id) throw new Error('Choose a job first.');
    const qs = $('#pgQs').value.split('\n').map((s) => s.trim()).filter(Boolean);
    const j = await api(`/jobs/${id}/proposal`, { method: 'POST', body: { format: $('#pgFmt').value, questions: qs, instructions: $('#pgIns').value } });
    $('#pgOut').innerHTML = `<div class="row" style="justify-content:space-between"><span class="badge info">${esc(j.proposal_style)}</span><a href="#/job/${j.id}">Open job to edit & approve →</a></div><div class="desc" style="margin-top:8px">${esc(j.proposal)}</div>${(j.application_questions || []).map((q) => `<h3>${esc(q.question)}</h3>${q.needsInput ? `<div class="notice small">Needs your input: ${esc(q.note)}</div>` : ''}<div class="desc">${esc(q.answer)}</div>`).join('')}`;
  }).catch(() => {});
};

views.analytics = async () => {
  const tok = routeTok;
  setTitle('Analytics', 'Weekly performance from your own records. No sample or projected numbers.');
  if (tok !== routeTok) return;
  $('#view').innerHTML = `<div class="card row"><label style="margin:0">Week containing</label><input type="date" id="wk" style="width:auto" value="${new Date().toISOString().slice(0, 10)}"><button id="wkGo">Show</button><button id="wkAI" title="Uses Claude to suggest improvements from these numbers">Show with AI recommendations</button></div><div id="rep" style="margin-top:14px"></div>`;
  const load = async (ai) => {
    const r = await api(`/analytics/weekly?date=${$('#wk').value}${ai ? '&ai=1' : ''}`);
    const tbl = (rows, label) => rows.length ? `<table><tr><th>${label}</th><th>Applied</th><th>Responses</th><th>Interviews</th><th>Interview rate</th></tr>${rows.map((x) => `<tr><td>${esc(x.name)}</td><td>${x.applied}</td><td>${x.responses}</td><td>${x.interviews}</td><td>${x.interviewRate ?? '—'}%</td></tr>`).join('')}</table>` : '<div class="muted">No applications yet.</div>';
    const stat = (v, l) => `<div class="card stat"><div class="v">${v ?? '—'}</div><div class="l">${l}</div></div>`;
    $('#rep').innerHTML = `<div class="muted small" style="margin-bottom:8px">Week of ${esc(r.week.start)}</div>${r.sampleNote ? `<div class="notice info">${esc(r.sampleNote)}</div>` : ''}
      <div class="grid stats">${stat(r.jobsDiscovered, 'Jobs discovered')}${stat(r.qualifiedJobs, 'Qualified (70+)')}${stat(r.applicationsSubmitted, 'Applications submitted')}${stat(r.interviews, 'Interviews')}${stat(r.interviewConversionRate == null ? '—' : `${r.interviewConversionRate}%`, 'Interview conversion (week)')}${stat(r.allTime.conversion == null ? '—' : `${r.allTime.conversion}%`, `All-time conversion (${r.allTime.interviews}/${r.allTime.applied})`)}</div>
      <div class="grid two" style="margin-top:14px"><div class="card"><h2>Best-performing job categories</h2>${tbl(r.bestCategories, 'Category')}</div><div class="card"><h2>Best-performing proposal styles</h2>${tbl(r.bestProposalStyles, 'Style')}</div>
      <div class="card"><h2>Platforms producing results</h2>${tbl(r.platforms, 'Platform')}</div>
      <div class="card"><h2>Most requested skills (last 4 weeks, 60+ jobs)</h2>${r.mostRequestedSkills.length ? `<table>${r.mostRequestedSkills.map((s) => `<tr><td>${esc(s.skill)}</td><td style="width:50%"><div class="bar"><div style="width:${Math.min(100, (s.count / r.mostRequestedSkills[0].count) * 100)}%"></div></div></td><td>${s.count}</td><td>${s.inProfile ? '<span class="badge ok">have</span>' : '<span class="badge warn">missing</span>'}</td></tr>`).join('')}</table>` : '<div class="muted">Not enough data yet.</div>'}</div>
      <div class="card"><h2>Companies that responded</h2>${r.companiesResponded.length ? `<ul class="list">${r.companiesResponded.map((c) => `<li>${esc(c.company)} — ${esc(c.title)} <span class="badge">${esc(c.status)}</span></li>`).join('')}</ul>` : '<div class="muted">None yet.</div>'}</div>
      <div class="card"><h2>Recommended improvements</h2>${r.recommendations.length ? `<ul class="list">${r.recommendations.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : '<div class="muted">Nothing to recommend yet.</div>'}</div></div>`;
  };
  $('#wkGo').onclick = (e) => busy(e.currentTarget, () => load(false));
  $('#wkAI').onclick = (e) => busy(e.currentTarget, () => load(true));
  load(false);
};

// ---------------- job detail drawer ----------------
function closeDrawer(nav = true) { $('#drawerHost').innerHTML = ''; if (nav && location.hash.startsWith('#/job')) history.back(); }
async function openJob(id) {
  const j = await api(`/jobs/${id}`).catch((e) => { toast(e.message, true); return null; }); if (!j) return;
  const ex = j.match_explanation || {}; const bd = j.score_breakdown || {}; const res = j.company_research;
  const W = { skills: 30, experience: 20, automation: 15, compensation: 10, remote: 10, hours: 5, longTerm: 5, growth: 5 };
  const LBL = { skills: 'Skills match', experience: 'Experience match', automation: 'Automation / AI relevance', compensation: 'Compensation', remote: 'Remote eligibility', hours: 'Working hours', longTerm: 'Long-term potential', growth: 'Career growth' };
  const statuses = state.settings?.statuses || ['New', 'Analyzing', 'Qualified', 'Proposal Generated', 'Awaiting Approval', 'Applied', 'Follow-Up Due', 'Interview', 'Assessment', 'Offer', 'Rejected', 'Archived'];
  const method = j.submissionMethod;
  $('#drawerHost').innerHTML = `<div class="overlay" id="dov" style="background:rgba(10,12,16,.35);z-index:39"></div><div class="drawer">
    <div class="row" style="justify-content:space-between;align-items:start"><div style="flex:1;min-width:0"><h1>${esc(j.title)}</h1><div class="muted">${esc(j.company || 'Unknown company')} · ${esc(j.platform)} · <a href="${esc(j.url)}" target="_blank" rel="noopener">View posting ↗</a></div>
      <div class="row" style="margin-top:8px;gap:6px">${eligBadge(j.remote_eligibility, j.location_restrictions)}<span class="badge ${STATUS_CLS[j.status] || ''}">${esc(j.status)}</span>${scamBadge(j.scam_risk)}<span class="badge">${esc(money(j))}</span>${j.hours_per_week ? `<span class="badge">${esc(j.hours_per_week)} h/week</span>` : ''}${j.employment_type ? `<span class="badge">${esc(j.employment_type)}</span>` : ''}</div></div>
      <div class="score ${scoreCls(j.match_score)}" style="width:64px;height:64px;font-size:22px">${j.match_score ?? '–'}</div><button id="closeD" style="margin-left:10px">✕</button></div>
    <div class="row" style="margin:14px 0"><button id="aAnalyze">${j.scored_by === 'claude' ? 'Re-analyze' : 'Analyze with Claude'}</button><button id="aResearch">Research company</button>
      <select id="aFmt" style="width:auto"><option value="auto">Auto format</option><option value="short">Short</option><option value="detailed">Detailed</option><option value="linkedin">LinkedIn msg</option><option value="cover">Cover letter</option><option value="upwork">Upwork</option></select><button id="aProp">${j.proposal ? 'Regenerate' : 'Generate'} proposal</button>
      <button id="aSave">${j.saved ? '★ Saved' : '☆ Save'}</button><select id="aStatus" style="width:auto">${statuses.map((s) => `<option ${s === j.status ? 'selected' : ''}>${s}</option>`).join('')}</select>${j.status !== 'Archived' ? '<button class="danger" id="aReject">Reject</button>' : ''}</div>
    <div class="tabs" id="dtabs"><button data-t="match" class="active">Match</button><button data-t="apply">Proposal & apply</button><button data-t="research">Company</button><button data-t="desc">Description</button><button data-t="track">Tracking</button></div>
    <div data-p="match">
      <div class="notice ${j.scored_by === 'claude' ? 'info' : ''}">${esc(ex.classification || j.classification)} · scored by ${j.scored_by === 'claude' ? 'Claude' : 'rules (add an API key and press Analyze for an AI review)'}. ${esc(ex.summary || '')}</div>
      <div class="grid two"><div class="card"><h2>Score breakdown</h2>${Object.keys(W).map((k) => `<div style="margin-bottom:8px"><div class="row small" style="justify-content:space-between"><span>${LBL[k]} <span class="muted">(${W[k]}%)</span></span><b>${bd[k] ?? '–'}</b></div><div class="bar"><div style="width:${bd[k] || 0}%"></div></div></div>`).join('')}</div>
      <div class="card"><h2>Why it fits</h2><p>${esc(ex.whyMatch || '—')}</p>
        <h3>Relevant skills</h3><div class="row" style="gap:4px">${(ex.relevantSkills || []).map((s) => `<span class="badge ok">${esc(s)}</span>`).join('') || '<span class="muted">—</span>'}</div>
        <h3>Missing qualifications</h3><ul class="list">${(ex.missingQualifications || []).map((s) => `<li>${esc(s)}</li>`).join('') || '<li class="muted">None found</li>'}</ul>
        <h3>Compensation</h3><p>${esc(ex.compensationFit || '—')}</p>
        <h3>Remote & Philippines eligibility</h3><p>${esc(ex.remote ? `${ex.remote.genuinelyRemote ? 'Genuinely remote' : 'Not genuinely remote'}; Philippines eligible: ${ex.remote.philippinesEligible}. ${ex.remote.explanation}` : `${ex.remoteEligibility?.status || j.remote_eligibility}${j.location_restrictions ? ` (${j.location_restrictions})` : ''}`)}</p>
        <h3>Worth applying?</h3><p>${esc(ex.worthApplying?.verdict ? `${ex.worthApplying.verdict.toUpperCase()}: ${ex.worthApplying.reason}` : ex.worthApplying === true ? 'Likely yes (rules)' : ex.worthApplying === false ? 'Probably not (rules)' : '—')}</p>
        <h3>Interview likelihood <span class="badge warn">AI estimate, not a prediction</span></h3><p>${esc(ex.interviewLikelihood?.level ? `${ex.interviewLikelihood.level}: ${ex.interviewLikelihood.reason}` : 'Available after Claude analysis.')}</p>
        ${(j.scam_flags || []).length ? `<h3>Scam signals</h3><ul class="list">${j.scam_flags.map((f) => `<li>${esc(f)}</li>`).join('')}</ul>` : ''}</div></div></div>
    <div data-p="apply" hidden>
      ${j.approvalReasons.length ? `<div class="notice"><b>Needs your review before sending:</b> ${j.approvalReasons.map(esc).join(' · ')}</div>` : ''}
      <div class="card"><div class="row" style="justify-content:space-between"><h2 style="margin:0">Proposal ${j.proposal_style ? `<span class="badge info">${esc(j.proposal_style)}</span>` : ''}</h2><span class="small muted" id="wc"></span></div>
        <textarea id="propTxt" style="min-height:260px;margin-top:10px" placeholder="Generate a proposal, or write your own.">${esc(j.proposal || '')}</textarea>
        <h3>Application questions</h3><div id="qaBox">${(j.application_questions || []).map((q, i) => `<div class="field"><label>${esc(q.question)} ${q.needsInput ? '<span class="badge warn">needs your input</span>' : ''}</label>${q.note ? `<div class="small muted">${esc(q.note)}</div>` : ''}<textarea data-q="${i}" style="min-height:80px">${esc(q.answer || '')}</textarea></div>`).join('') || '<div class="muted small">No questions detected. Add them in Proposal Generator if the form has any.</div>'}</div>
        <div class="row"><button id="savePropBtn">Save edits</button><button class="ok" id="approveBtn">${j.approved_at ? '✓ Approved — re-approve' : 'Approve application'}</button>
          <button class="primary" id="sendBtn" ${j.approved_at && !j.date_applied ? '' : 'disabled'}>${method === 'email' ? `Send by email to ${esc(j.apply_email)}` : method === 'manual-upwork' ? 'Copy & open Upwork' : 'Open form & pre-fill (you submit)'}</button>
          <button id="copyBtn">Copy proposal</button>${j.date_applied ? '' : '<button id="markBtn">Mark as applied</button>'}</div>
        <p class="small muted" style="margin-top:10px">${method === 'email' ? 'This posting asks for email applications. Sending uses your SMTP mailbox and is recorded only after the mail server accepts it.' : 'This site needs you to submit. "Open form" launches a visible browser with basic fields pre-filled; the app never presses Submit or solves CAPTCHAs. After you submit, press Mark as applied.'}</p></div>
      <div class="card" style="margin-top:14px"><h2>Autonomous mode check</h2>${j.autonomous.ok ? '<div class="notice ok">Eligible for automatic sending in Mode 3.</div>' : `<div class="small muted">Mode 3 would not send this automatically because:</div><ul class="list small">${j.autonomous.blockers.map((b) => `<li>${esc(b)}</li>`).join('')}</ul>`}</div></div>
    <div data-p="research" hidden><div class="card">${res ? `<div class="kv">${['overview', 'products', 'businessModel', 'industry', 'size', 'mission', 'hiringManager', 'recentDevelopments'].filter((k) => res[k]).map((k) => `<div>${k.replace(/[A-Z]/g, (m) => ' ' + m.toLowerCase())}</div><div>${esc(res[k])}</div>`).join('')}</div>${res.likelyChallenges ? `<h3>Likely challenges</h3><ul class="list">${res.likelyChallenges.map((c) => `<li>${esc(c)}</li>`).join('')}</ul>` : ''}${res.howCandidateHelps ? `<h3>How you can help</h3><ul class="list">${res.howCandidateHelps.map((c) => `<li>${esc(c)}</li>`).join('')}</ul>` : ''}<p class="small muted">Sources: ${(res.sources || []).map((s) => `<a href="${esc(s)}" target="_blank" rel="noopener">${esc(s)}</a>`).join(', ') || 'posting only'} · ${esc(res.by || '')}${res.confidence ? ` · confidence ${esc(res.confidence)}` : ''}</p>` : '<div class="empty">Not researched yet. Press <b>Research company</b>. It reads the company\'s own site and the posting only.</div>'}</div></div>
    <div data-p="desc" hidden><div class="card"><div class="kv small" style="margin-bottom:12px"><div>Posted</div><div>${fmtDate(j.date_posted)} (discovered ${fmtDate(j.date_discovered)})</div><div>Apply URL</div><div><a href="${esc(j.apply_url)}" target="_blank" rel="noopener">${esc(j.apply_url)}</a></div>${j.apply_email ? `<div>Apply email</div><div>${esc(j.apply_email)}</div>` : ''}<div>Location text</div><div>${esc(j.location_restrictions || '—')}</div><div>Required skills</div><div>${esc((j.required_skills || []).join(', ') || '—')}</div><div>Category</div><div>${esc(j.category || '—')}</div></div><div class="desc">${esc(j.description || '')}</div></div></div>
    <div data-p="track" hidden><div class="grid two"><div class="card"><h2>Tracking</h2><div class="kv small"><div>Date applied</div><div>${fmtDate(j.date_applied)} ${j.applied_via ? `(${esc(j.applied_via)})` : ''}</div><div>Follow-up date</div><div>${fmtDate(j.follow_up_date)} ${j.follow_up_stage ? `· ${esc(j.follow_up_stage)}` : ''}</div><div>Follow-up sent</div><div>${j.follow_up_sent ? 'Yes' : 'No'}</div></div>
      <div class="field" style="margin-top:12px"><label>Contact information</label><input id="contactTxt" value="${esc(j.contact_info || '')}"></div><div class="field"><label>Notes</label><textarea id="notesTxt">${esc(j.notes || '')}</textarea></div><button id="saveNotes">Save</button></div>
      <div class="card"><h2>Follow-up</h2>${j.date_applied ? `${j.follow_up_sent ? '<div class="notice ok">Follow-up already sent. No more follow-ups will be suggested.</div>' : `<textarea id="fuTxt" placeholder="A draft appears on day 5 after applying.">${esc(j.follow_up_draft || '')}</textarea><div class="row" style="margin-top:8px"><button id="fuDraft">Draft now</button>${j.applied_via === 'email' ? '<button class="primary" id="fuSend">Send by email</button>' : ''}<button id="fuMark">Mark follow-up sent</button></div><p class="small muted">Send only one follow-up, through the channel the platform allows.</p>`}` : '<div class="muted">Available after you apply.</div>'}
      <h3>History</h3><ul class="list small">${j.events.map((e) => `<li>${fmtDate(e.created_at)} — ${esc(e.type)}: ${esc(e.detail || '')}</li>`).join('')}</ul></div></div></div></div>`;
  const D = $('.drawer');
  $('#closeD').onclick = () => closeDrawer(); $('#dov').onclick = () => closeDrawer();
  $$('#dtabs button').forEach((b) => (b.onclick = () => { $$('#dtabs button').forEach((x) => x.classList.toggle('active', x === b)); $$('[data-p]', D).forEach((p) => (p.hidden = p.dataset.p !== b.dataset.t)); }));
  const wc = () => { $('#wc').textContent = `${($('#propTxt').value.trim().match(/\S+/g) || []).length} words`; }; wc(); $('#propTxt').oninput = wc;
  const reopen = (tab) => openJob(id).then(() => { if (tab) $(`#dtabs [data-t="${tab}"]`).click(); refreshShell(); });
  const act = (btn, fn, tab, msg) => busy(btn, fn).then(() => { if (msg) toast(msg); reopen(tab); }).catch(() => {});
  const collect = () => ({ proposal: $('#propTxt').value, application_questions: (j.application_questions || []).map((q, i) => ({ ...q, answer: $(`[data-q="${i}"]`).value, needsInput: q.needsInput && /\[YOUR INPUT/i.test($(`[data-q="${i}"]`).value) })) });
  $('#aAnalyze').onclick = (e) => act(e.currentTarget, () => api(`/jobs/${id}/analyze`, { method: 'POST', body: {} }), 'match', 'Analysis updated');
  $('#aResearch').onclick = (e) => act(e.currentTarget, () => api(`/jobs/${id}/research`, { method: 'POST', body: {} }), 'research');
  $('#aProp').onclick = (e) => act(e.currentTarget, () => api(`/jobs/${id}/proposal`, { method: 'POST', body: { format: $('#aFmt').value } }), 'apply', 'Proposal ready. Review before approving.');
  $('#aSave').onclick = (e) => act(e.currentTarget, () => api(`/jobs/${id}`, { method: 'PATCH', body: { saved: !j.saved } }));
  $('#aStatus').onchange = (e) => { const st = e.target.value; if (st === 'Applied' && !j.date_applied && !confirm('Mark as applied? Only if you actually submitted it.')) { e.target.value = j.status; return; } act(null, () => api(`/jobs/${id}/status`, { method: 'POST', body: { status: st } }), null, `Status: ${st}`); };
  if ($('#aReject')) $('#aReject').onclick = (e) => act(e.currentTarget, () => api(`/jobs/${id}/reject`, { method: 'POST', body: {} }), null, 'Archived');
  $('#savePropBtn').onclick = (e) => act(e.currentTarget, () => api(`/jobs/${id}`, { method: 'PATCH', body: collect() }), 'apply', 'Saved');
  $('#approveBtn').onclick = (e) => act(e.currentTarget, async () => { await api(`/jobs/${id}`, { method: 'PATCH', body: collect() }); await api(`/jobs/${id}/approve`, { method: 'POST', body: {} }); }, 'apply', 'Approved. Nothing has been sent yet.');
  $('#copyBtn').onclick = async () => { await navigator.clipboard.writeText($('#propTxt').value); toast('Copied'); };
  $('#sendBtn').onclick = (e) => {
    if (method === 'manual-upwork') { navigator.clipboard.writeText($('#propTxt').value); window.open(j.url, '_blank', 'noopener'); toast('Proposal copied. Submit on Upwork, then Mark as applied.'); return; }
    if (method === 'email' && !confirm(`Send this application now to ${j.apply_email}?`)) return;
    act(e.currentTarget, () => api(`/jobs/${id}/apply`, { method: 'POST', body: { method } }), 'apply', method === 'email' ? 'Sent and recorded as Applied' : 'Browser opened with the form pre-filled. Review, submit there, then Mark as applied.');
  };
  if ($('#markBtn')) $('#markBtn').onclick = (e) => { if (confirm('Mark as applied? Only if you actually submitted the application.')) act(e.currentTarget, () => api(`/jobs/${id}/mark-applied`, { method: 'POST', body: {} }), 'track', 'Recorded. Follow-up reminders scheduled.'); };
  $('#saveNotes').onclick = (e) => act(e.currentTarget, () => api(`/jobs/${id}`, { method: 'PATCH', body: { notes: $('#notesTxt').value, contact_info: $('#contactTxt').value } }), 'track', 'Saved');
  if ($('#fuDraft')) $('#fuDraft').onclick = (e) => act(e.currentTarget, () => api(`/jobs/${id}/followup/draft`, { method: 'POST', body: {} }), 'track');
  if ($('#fuSend')) $('#fuSend').onclick = (e) => { if (confirm('Send this follow-up by email now?')) act(e.currentTarget, () => api(`/jobs/${id}/followup/send`, { method: 'POST', body: { text: $('#fuTxt').value } }), 'track', 'Follow-up sent'); };
  if ($('#fuMark')) $('#fuMark').onclick = (e) => act(e.currentTarget, () => api(`/jobs/${id}/followup/mark-sent`, { method: 'POST', body: {} }), 'track', 'Recorded');
}

// ---------------- settings ----------------
views.settings = async () => {
  const tok = routeTok;
  setTitle('Settings', 'Application mode, schedule, sources, integrations and your profile.');
  const s = await api('/settings'); state.settings = s; const st = s.settings;
  const tab = sessionStorage.getItem('stab') || 'mode';
  if (tok !== routeTok) return;
  $('#view').innerHTML = `<div class="tabs" id="stabs">${[['mode', 'Mode & schedule'], ['sources', 'Sources'], ['integrations', 'Integrations'], ['notifications', 'Notifications'], ['profile', 'Profile'], ['data', 'Data']].map(([k, l]) => `<button data-t="${k}" class="${tab === k ? 'active' : ''}">${l}</button>`).join('')}</div><div id="sbody"></div>`;
  $$('#stabs button').forEach((b) => (b.onclick = () => { try { sessionStorage.setItem('stab', b.dataset.t); } catch {} views.settings(); }));
  const body = $('#sbody'); const save = async (patch, msg = 'Saved') => { await api('/settings', { method: 'PUT', body: patch }); toast(msg); refreshShell(); views.settings(); };
  if (tab === 'mode') {
    body.innerHTML = `<div class="grid two"><div class="card"><h2>Application mode</h2>
      ${[['search_only', 'Mode 1 — Search only', 'Search, score and organize jobs. Proposals only when you ask.'], ['draft_approve', 'Mode 2 — Draft and approve (recommended)', 'Searches, scores, researches and drafts proposals and answers for 80+ jobs. Nothing is sent until you approve.'], ['autonomous', 'Mode 3 — Autonomous', 'Also sends applications automatically, but only by email, only for 85+ jobs that pass every safety rule. Everything else waits for you.']].map(([v, l, d]) => `<label class="check" style="align-items:start;margin-bottom:10px"><input type="radio" name="mode" value="${v}" ${st.mode === v ? 'checked' : ''}><span><b>${l}</b><br><span class="muted small">${d}</span></span></label>`).join('')}
      <div id="armBox" ${st.mode === 'autonomous' ? '' : 'hidden'} class="notice"><label class="check"><input type="checkbox" id="arm" ${st.autonomousArmed ? 'checked' : ''}> Arm automatic sending. I understand the app will email applications on my behalf when every rule passes.</label></div>
      <div class="grid two"><div class="field"><label>Auto-proposal min score</label><input type="number" id="apMin" value="${st.autoProposalMinScore}"></div><div class="field"><label>Autonomous min score (≥85)</label><input type="number" id="auMin" min="85" value="${st.autonomousMinScore}"></div></div>
      <button class="primary" id="saveMode">Save mode</button></div>
      <div class="card"><h2>Search schedule</h2><div class="field"><select id="sched">${[['every4h', 'Every 4 hours'], ['daily', 'Once daily'], ['custom', 'Custom cron'], ['off', 'Off (on-demand only)']].map(([v, l]) => `<option value="${v}" ${st.schedule === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
      <div class="field"><label>Daily time (Asia/Manila unless TZ is set)</label><input type="time" id="dtime" value="${esc(st.dailyTime)}"></div><div class="field"><label>Custom cron expression</label><input id="cron" value="${esc(st.scheduleCron)}"></div>
      <div class="grid two"><div class="field"><label>Ignore postings older than (days)</label><input type="number" id="maxAge" value="${st.maxAgeDays}"></div><div class="field"><label>Deprioritize below score</label><input type="number" id="rejB" value="${st.rejectBelow}"></div></div>
      <div class="field"><label>Search keywords (comma separated; empty = from profile)</label><input id="kw" value="${esc((st.keywords || []).join(', '))}"></div>
      <div class="field"><label>Exclude titles containing (comma separated)</label><input id="excl" value="${esc(st.excludeTitleWords.join(', '))}"></div>
      <p class="small muted">Active schedule: <code>${esc(s.schedule)}</code></p><button class="primary" id="saveSched">Save schedule</button></div></div>`;
    $$('input[name=mode]').forEach((r) => (r.onchange = () => { $('#armBox').hidden = r.value !== 'autonomous'; }));
    $('#saveMode').onclick = () => { const mode = $('input[name=mode]:checked').value; const armed = mode === 'autonomous' && $('#arm').checked; if (armed && !confirm('Arm autonomous sending? Applications that pass every rule will be emailed without asking you first.')) return; save({ mode, autonomousArmed: armed, confirmAutonomous: armed, autoProposalMinScore: +$('#apMin').value, autonomousMinScore: Math.max(85, +$('#auMin').value) }); };
    $('#saveSched').onclick = () => save({ schedule: $('#sched').value, dailyTime: $('#dtime').value, scheduleCron: $('#cron').value, maxAgeDays: +$('#maxAge').value, rejectBelow: +$('#rejB').value, keywords: $('#kw').value.trim() ? $('#kw').value.split(',').map((x) => x.trim()).filter(Boolean) : null, excludeTitleWords: $('#excl').value.split(',').map((x) => x.trim()).filter(Boolean) });
  }
  if (tab === 'sources') {
    const names = { remotive: 'Remotive (API)', remoteok: 'Remote OK (API)', wwr: 'We Work Remotely (RSS)', workingnomads: 'Working Nomads (API)', jobicy: 'Jobicy (API)', himalayas: 'Himalayas (API)', greenhouse: 'Company boards: Greenhouse', lever: 'Company boards: Lever', ashby: 'Company boards: Ashby' };
    body.innerHTML = `<div class="grid two"><div class="card"><h2>Automated sources</h2><p class="small muted">Official public APIs and feeds. No login, no scraping. Each source's terms ask for attribution, which the app keeps by linking every job to its original posting.</p>${Object.entries(names).map(([k, l]) => `<label class="check" style="margin-bottom:6px"><input type="checkbox" data-src="${k}" ${st.sources[k] ? 'checked' : ''}> ${l}</label>`).join('')}<button class="primary" id="saveSrc" style="margin-top:8px">Save</button></div>
      <div class="card"><h2>Company career pages (ATS boards)</h2><p class="small muted">Add remote-first companies you'd like to work for. Use the slug from their job board URL, e.g. <code>boards.greenhouse.io/<b>acme</b></code>, <code>jobs.lever.co/<b>acme</b></code>, <code>jobs.ashbyhq.com/<b>acme</b></code>. One per line.</p>
      ${['greenhouse', 'lever', 'ashby'].map((k) => `<div class="field"><label>${k}</label><textarea data-ats="${k}" style="min-height:70px">${esc((st.atsBoards[k] || []).join('\n'))}</textarea></div>`).join('')}<button class="primary" id="saveAts">Save boards</button></div></div>`;
    $('#saveSrc').onclick = () => save({ sources: Object.fromEntries($$('[data-src]').map((c) => [c.dataset.src, c.checked])) });
    $('#saveAts').onclick = () => save({ atsBoards: Object.fromEntries($$('[data-ats]').map((t) => [t.dataset.ats, t.value.split('\n').map((x) => x.trim()).filter(Boolean)])) });
  }
  if (tab === 'integrations') {
    body.innerHTML = `<div class="grid two"><div class="card"><h2>Claude API</h2><p class="small muted">Status: <b>${esc(s.secrets.anthropicApiKey)}</b>. Powers analysis, research, proposals, answers and follow-ups. Get a key at console.anthropic.com. Stored encrypted in your local database.</p>
      <div class="field"><label>Anthropic API key</label><input type="password" id="akey" placeholder="sk-ant-…" autocomplete="off"></div>
      <div class="grid two"><div class="field"><label>Model</label><input id="model" value="${esc(st.ai.model)}"></div><div class="field"><label>Effort</label><select id="effort">${['low', 'medium', 'high'].map((e) => `<option ${st.ai.effort === e ? 'selected' : ''}>${e}</option>`).join('')}</select></div></div>
      <div class="field"><label>Max jobs Claude analyzes per search (cost control)</label><input type="number" id="maxai" value="${st.ai.maxJobsPerRun}"></div>
      <div class="row"><button class="primary" id="saveAI">Save</button><button id="testAI">Test connection</button></div></div>
      <div class="card"><h2>Email (SMTP)</h2><p class="small muted">Used for email applications, follow-ups and notifications. With Gmail, turn on 2-step verification and create an App Password. Password status: <b>${esc(s.secrets.smtpPass)}</b>.</p>
      <div class="grid two"><div class="field"><label>Host</label><input id="sh" value="${esc(st.smtp.host)}" placeholder="smtp.gmail.com"></div><div class="field"><label>Port</label><input id="sp" type="number" value="${st.smtp.port}"></div></div>
      <div class="grid two"><div class="field"><label>Username</label><input id="su" value="${esc(st.smtp.user)}"></div><div class="field"><label>Password / app password</label><input id="spw" type="password" autocomplete="off"></div></div>
      <div class="field"><label>From (optional)</label><input id="sf" value="${esc(st.smtp.from)}" placeholder="Your Name &lt;you@gmail.com&gt;"></div><label class="check"><input type="checkbox" id="ss" ${st.smtp.secure ? 'checked' : ''}> Use SSL (port 465)</label>
      <div class="field" style="margin-top:10px"><label>CV file to attach / upload (absolute path to PDF on this computer)</label><input id="cv" value="${esc(st.cvPath || '')}"></div>
      <div class="row"><button class="primary" id="saveSmtp">Save</button><button id="testSmtp">Send test email</button></div></div>
      <div class="card"><h2>Needs keys or your account</h2><table><tr><th>Integration</th><th>What it needs</th></tr>
        <tr><td>Claude scoring, research, proposals</td><td>Anthropic API key (paid, usage-based)</td></tr><tr><td>Email applications & alerts</td><td>Your SMTP login (e.g. Gmail App Password)</td></tr>
        <tr><td>Assisted apply (pre-filled forms)</td><td>Playwright on this computer: <code>npm i playwright && npx playwright install chromium</code></td></tr>
        <tr><td>Upwork</td><td>Official API needs an approved Upwork developer key. Meanwhile: assisted search + import, or use Claude's Upwork connector in chat</td></tr>
        <tr><td>LinkedIn, Indeed, Glassdoor, OnlineJobs.ph, Wellfound, FlexJobs</td><td>No permitted automation. Assisted links + import</td></tr>
        <tr><td>Remotive, Remote OK, WWR, Working Nomads, Jobicy, Himalayas, Greenhouse/Lever/Ashby</td><td>Nothing. Public feeds</td></tr></table></div></div>`;
    $('#saveAI').onclick = async () => { if ($('#akey').value) await api('/secrets', { method: 'PUT', body: { anthropicApiKey: $('#akey').value.trim() } }); save({ ai: { model: $('#model').value.trim(), effort: $('#effort').value, maxJobsPerRun: +$('#maxai').value } }); };
    $('#testAI').onclick = (e) => busy(e.currentTarget, async () => { const r = await api('/test/ai', { method: 'POST', body: {} }); toast(`Claude replied: ${r.reply}`); });
    $('#saveSmtp').onclick = async () => { if ($('#spw').value) await api('/secrets', { method: 'PUT', body: { smtpPass: $('#spw').value } }); save({ smtp: { host: $('#sh').value.trim(), port: +$('#sp').value, user: $('#su').value.trim(), from: $('#sf').value.trim(), secure: $('#ss').checked }, cvPath: $('#cv').value.trim() }); };
    $('#testSmtp').onclick = (e) => busy(e.currentTarget, async () => { const r = await api('/test/smtp', { method: 'POST', body: {} }); toast(`Test email sent to ${r.sentTo}`); });
  }
  if (tab === 'notifications') {
    const n = st.notifications;
    body.innerHTML = `<div class="card" style="max-width:560px"><h2>Notifications</h2><p class="small muted">Always shown in the dashboard bell. Email copies need SMTP (Integrations).</p>
      <label class="check"><input type="checkbox" id="ne" ${n.email ? 'checked' : ''}> Also email me</label><div class="field" style="margin-top:8px"><label>Send to</label><input id="nto" value="${esc(n.emailTo)}"></div>
      <div class="field"><label>Alert for new jobs scoring at least</label><input type="number" id="nmin" value="${n.minScoreAlert}"></div><label class="check"><input type="checkbox" id="nd" ${n.dailyReport ? 'checked' : ''}> Report after each scheduled search</label>
      <label class="check"><input type="checkbox" id="fu" ${st.followUps.enabled ? 'checked' : ''}> Follow-up reminders (day 3, day 5–7 draft, day 14 inactive)</label><button class="primary" id="saveN" style="margin-top:10px">Save</button></div>`;
    $('#saveN').onclick = () => save({ notifications: { email: $('#ne').checked, emailTo: $('#nto').value.trim(), minScoreAlert: +$('#nmin').value, dailyReport: $('#nd').checked }, followUps: { enabled: $('#fu').checked } });
  }
  if (tab === 'profile') {
    const p = await api('/profile');
    body.innerHTML = `<div class="card"><h2>Your profile (source of truth)</h2><p class="small muted">Claude may only use facts in this profile. It was reconciled from your three CVs; see <code>reconciliationNotes</code>. Skills under <code>selfReportedNotOnCV</code> came from your brief but aren't on any CV.</p>
      ${(p.reconciliationNotes || []).length ? `<div class="notice info"><ul class="list">${p.reconciliationNotes.map((x) => `<li>${esc(x)}</li>`).join('')}</ul></div>` : ''}
      <textarea id="profTxt" style="min-height:520px;font-family:ui-monospace,monospace;font-size:12px">${esc(JSON.stringify(p, null, 2))}</textarea><div class="row" style="margin-top:8px"><button class="primary" id="saveProf">Save profile</button><span class="small muted">After saving, use Re-score on Job Search.</span></div></div>`;
    $('#saveProf').onclick = async (e) => busy(e.currentTarget, async () => { let obj; try { obj = JSON.parse($('#profTxt').value); } catch (err) { throw new Error(`Invalid JSON: ${err.message}`); } await api('/profile', { method: 'PUT', body: obj }); toast('Profile saved'); });
  }
  if (tab === 'data') {
    body.innerHTML = `<div class="card" style="max-width:640px"><h2>Your data</h2><p>Database file: <code>${esc(s.dbPath)}</code>. Back it up by copying this file.</p><div class="row"><a class="btn" href="/api/export.csv">Export all jobs (CSV)</a></div>
      <h3>Search history</h3><div id="runsBox"></div></div>`;
    const runs = await api('/search/runs');
    $('#runsBox').innerHTML = runs.length ? `<table><tr><th>Started</th><th>Trigger</th><th>Found</th><th>New</th><th>Details</th></tr>${runs.map((r) => `<tr><td>${esc(r.started_at)}</td><td>${esc(r.trigger)}</td><td>${r.found}</td><td>${r.new_jobs}</td><td class="small">${r.error ? esc(r.error) : esc(Object.entries(r.source_report?.counters || {}).map(([k, v]) => `${k} ${v}`).join(', '))}</td></tr>`).join('')}</table>` : '<div class="muted">No runs yet.</div>';
  }
};

renderAuth();
